Wgraj zawartość folderu server do głównego katalogu repozytorium GitHub.

Render:
Build Command: pip install -r requirements.txt
Start Command: python relay_server.py --host 0.0.0.0 --port $PORT

Serwer obsługuje jednocześnie:
- WebSocket CO-OP na / i /ws,
- status HTTP na / oraz /healthz,
- manifest aktualizacji na /api/update,
- pliki aktualizacji na /updates/nazwa.zip.

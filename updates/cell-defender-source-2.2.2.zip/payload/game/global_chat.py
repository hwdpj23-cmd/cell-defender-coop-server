from __future__ import annotations

import time
from typing import Any

import pygame

from .data import COLORS, HEIGHT, WIDTH
from .network import NetworkClient
from .online import TextField, normalize_ws_url
from .ui import Button
from .utils import draw_panel, draw_text
from .version import DEFAULT_WS_SERVER, GAME_VERSION


class GlobalChatScene:
    """Publiczny chat wszystkich graczy połączonych z serwerem Cell Defender."""

    MAX_CONNECT_ATTEMPTS = 5
    MAX_MESSAGES = 120

    def __init__(self, app: Any):
        self.app = app
        settings = app.save.data["settings"]
        self.nickname = str(settings.get("nickname", "Komórka")).strip() or "Komórka"
        self.server_url = normalize_ws_url(str(settings.get("server_url", DEFAULT_WS_SERVER)))
        self.input = TextField(pygame.Rect(70, 646, 860, 48), "", "Napisz wiadomość...", 180)
        self.network: NetworkClient | None = None
        self.messages: list[dict[str, Any]] = []
        self.online_count = 0
        self.status = "Łączenie z chatem globalnym..."
        self.connected = False
        self.connect_attempts = 0
        self.retry_timer = 0.0
        self.ping_timer = 0.0
        self.scroll = 0
        self.manual_close = False
        self.buttons = [
            Button(pygame.Rect(70, 70, 154, 42), "← MENU", self.back, secondary=True, small=True),
            Button(pygame.Rect(946, 646, 264, 48), "WYŚLIJ", self.send_message, accent=COLORS["teal"]),
            Button(pygame.Rect(1014, 70, 196, 42), "POŁĄCZ PONOWNIE", self.reconnect, secondary=True, small=True),
        ]
        self._begin_connection()

    def _begin_connection(self) -> None:
        if self.network:
            self.manual_close = True
            self.network.close()
        self.manual_close = False
        self.connect_attempts += 1
        self.connected = False
        self.status = f"Łączenie z chatem... próba {self.connect_attempts}/{self.MAX_CONNECT_ATTEMPTS}"
        self.network = NetworkClient(self.server_url)
        self.network.start()

    def reconnect(self) -> None:
        self.connect_attempts = 0
        self.retry_timer = 0.0
        self._begin_connection()

    def back(self) -> None:
        self.manual_close = True
        if self.network:
            self.network.send("global_leave")
            self.network.close()
        self.app.show_menu()

    def send_message(self) -> None:
        text = self.input.value.strip()
        if not text:
            return
        if not self.network or not self.connected:
            self.status = "Chat nie jest połączony. Kliknij POŁĄCZ PONOWNIE."
            return
        if self.network.send("global_chat", text=text):
            self.input.value = ""
            self.input.select_all = False
            self.scroll = 0
        else:
            self.status = "Nie udało się wysłać wiadomości."

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE and not self.input.active:
                self.back()
                return
            if event.key == pygame.K_RETURN and self.input.active:
                self.send_message()
                return
            if event.key == pygame.K_PAGEUP:
                self.scroll = min(max(0, len(self.messages) - 1), self.scroll + 5)
            elif event.key == pygame.K_PAGEDOWN:
                self.scroll = max(0, self.scroll - 5)
        if event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(max(0, len(self.messages) - 1), self.scroll + event.y * 3))
        if self.input.handle(event):
            return
        for button in self.buttons:
            if button.handle(event):
                self.app.audio.play("click")
                return

    def _schedule_retry(self) -> None:
        if self.manual_close:
            return
        if self.connect_attempts >= self.MAX_CONNECT_ATTEMPTS:
            self.status = "Nie udało się połączyć. Serwer może się budzić — spróbuj ponownie za minutę."
            return
        self.retry_timer = 3.0
        self.status = f"Serwer się uruchamia. Ponowna próba {self.connect_attempts + 1}/{self.MAX_CONNECT_ATTEMPTS}..."

    def update(self, dt: float) -> None:
        if self.retry_timer > 0:
            self.retry_timer -= dt
            if self.retry_timer <= 0:
                self._begin_connection()
        if not self.network:
            return
        self.ping_timer -= dt
        if self.connected and self.ping_timer <= 0:
            self.network.ping()
            self.ping_timer = 4.0
        for event in self.network.poll(250):
            data = event.data
            if event.type == "connected":
                self.connected = True
                self.status = "Połączono z chatem globalnym."
                self.network.send("global_join", nickname=self.nickname, version=GAME_VERSION)
            elif event.type == "global_history":
                history = data.get("messages", [])
                if isinstance(history, list):
                    self.messages = [item for item in history if isinstance(item, dict)][-self.MAX_MESSAGES:]
                    self.scroll = 0
            elif event.type == "global_chat":
                self.messages.append(data)
                self.messages = self.messages[-self.MAX_MESSAGES:]
                self.scroll = 0
            elif event.type == "global_status":
                self.online_count = max(0, int(data.get("online", 0) or 0))
            elif event.type == "error":
                self.status = str(data.get("message", "Błąd chatu"))
            elif event.type == "disconnected":
                if self.connected:
                    self.status = "Rozłączono z chatem."
                self.connected = False
                self._schedule_retry()

    def _visible_lines(self) -> list[tuple[str, str, tuple[int, int, int]]]:
        lines: list[tuple[str, str, tuple[int, int, int]]] = []
        for message in self.messages:
            nickname = str(message.get("nickname", "Gracz"))[:24]
            text = str(message.get("text", ""))[:180]
            system = bool(message.get("system", False))
            color = COLORS["yellow"] if system else COLORS["teal"]
            wrapped = self.app.wrap_text(text, self.app.fonts["small"], 790)
            if not wrapped:
                wrapped = [""]
            for index, line in enumerate(wrapped[:4]):
                lines.append((nickname if index == 0 else "", line, color))
        if self.scroll:
            end = max(0, len(lines) - self.scroll)
        else:
            end = len(lines)
        start = max(0, end - 15)
        return lines[start:end]

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["huge"], "CHAT GLOBALNY", COLORS["white"], (70, 22))
        draw_text(surface, self.app.fonts["tiny"], "Wspólny kanał wszystkich graczy Cell Defender — działa bez tworzenia pokoju.", COLORS["muted"], (70, 119))

        status_color = COLORS["green"] if self.connected else COLORS["orange"]
        status_panel = pygame.Rect(242, 70, 748, 42)
        draw_panel(surface, status_panel, COLORS["panel"], status_color, 12, 238)
        draw_text(surface, self.app.fonts["tiny_bold"], self.status, status_color, (status_panel.x + 14, status_panel.centery), "midleft")
        draw_text(surface, self.app.fonts["tiny_bold"], f"ONLINE: {self.online_count}", COLORS["teal"], (status_panel.right - 14, status_panel.centery), "midright")

        chat_panel = pygame.Rect(70, 148, 900, 474)
        draw_panel(surface, chat_panel, COLORS["panel"], COLORS["line"], 20, 244)
        visible = self._visible_lines()
        y = chat_panel.y + 22
        if not visible:
            draw_text(surface, self.app.fonts["small"], "Brak wiadomości. Napisz pierwszą wiadomość na globalnym kanale.", COLORS["muted"], (chat_panel.centerx, chat_panel.centery), "center")
        for nickname, line, color in visible:
            if nickname:
                draw_text(surface, self.app.fonts["tiny_bold"], nickname, color, (chat_panel.x + 20, y))
                draw_text(surface, self.app.fonts["small"], line, COLORS["text"], (chat_panel.x + 174, y - 2))
            else:
                draw_text(surface, self.app.fonts["small"], line, COLORS["text"], (chat_panel.x + 174, y - 2))
            y += 28

        side = pygame.Rect(990, 148, 220, 474)
        draw_panel(surface, side, COLORS["panel2"], COLORS["teal"], 20, 242)
        draw_text(surface, self.app.fonts["small_bold"], "SIEĆ KOMÓREK", COLORS["teal"], (side.centerx, side.y + 25), "midtop")
        draw_text(surface, self.app.fonts["huge"], str(self.online_count), COLORS["white"], (side.centerx, side.y + 80), "midtop")
        draw_text(surface, self.app.fonts["tiny"], "graczy online", COLORS["muted"], (side.centerx, side.y + 132), "midtop")
        pygame.draw.line(surface, COLORS["line"], (side.x + 20, side.y + 176), (side.right - 20, side.y + 176), 1)
        tips = [
            "ENTER — wyślij",
            "Ctrl+V — wklej",
            "Kółko myszy — przewijaj",
            "ESC — wróć do menu",
            "Limit: 180 znaków",
        ]
        for i, text in enumerate(tips):
            draw_text(surface, self.app.fonts["tiny"], text, COLORS["muted"], (side.x + 22, side.y + 205 + i * 34))
        draw_text(surface, self.app.fonts["tiny_bold"], f"Twój nick:\n{self.nickname}", COLORS["purple"], (side.x + 22, side.bottom - 72))

        self.input.draw(surface, self.app.fonts["small"], self.app.fonts["tiny_bold"], "WIADOMOŚĆ")
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"] if not button.small else self.app.fonts["tiny_bold"])

# Cell Defender 2.0.1 — poprawka serwera CO-OP

Najważniejsza poprawka: główny launcher serwera wcześniej przechodził do folderu nadrzędnego i przez to nie widział `.venv`. Wersja 2.0.1 uruchamia serwer z właściwego folderu i samodzielnie instaluje bibliotekę `websockets`, gdy jej brakuje.

## Najprostsze uruchomienie

1. Wypakuj cały ZIP.
2. Uruchom `URUCHOM_SERWER_LOKALNY.cmd`.
3. Zaczekaj na napis `Relay Cell Defender działa na ws://0.0.0.0:8765`.
4. W grze wpisz `ws://127.0.0.1:8765`.

Gdy biblioteka była wcześniej uszkodzona, uruchom `NAPRAW_I_URUCHOM_SERWER.cmd`.

---

# Cell Defender: Immunity Protocol 2.0 — CO-OP Evolution

Oryginalna gra survival-action na PC napisana w Pythonie i `pygame-ce`. Wersja 2.0 rozwija ekspedycje z wersji 1.1 o duży system zawartości data-driven oraz dwuosobowy tryb online.

## Szybkie uruchomienie

1. Wypakuj cały ZIP do zwykłego folderu.
2. Uruchom `START_GRY.cmd`.
3. Przy pierwszym uruchomieniu skrypt utworzy `.venv` i zainstaluje `pygame-ce` oraz `websockets`.
4. W menu wybierz `GRA SOLO` albo `ONLINE CO-OP`.

Nie uruchamiaj gry bezpośrednio wewnątrz archiwum ZIP.

## 432 nowe elementy zawartości

Pełny spis znajduje się w `CONTENT_MANIFEST.json`.

- 120 genów wybieranych podczas zdobywania poziomów,
- 80 reliktów znajdowanych podczas eksploracji,
- 48 automatycznych ewolucji i synergii,
- 40 kontraktów pobocznych,
- 32 anomalie mapy,
- 24 klasy komórek,
- 24 opcjonalne wyzwania zwiększające nagrody,
- 16 biomów mapy,
- 16 mutacji bossów,
- 32 osiągnięcia profilu.

W `Laboratorium → Klasy i wyzwania` możesz wybrać specjalizację startową oraz modyfikator następnej ekspedycji.

## Największe innowacje

- losowe relikty i anomalie rozmieszczone na dużej mapie,
- kontrakt poboczny w każdej ekspedycji,
- automatyczne synergie po połączeniu odpowiedniej broni i mutacji,
- biom zależny od obszaru mapy wpływający na wrogów oraz XP,
- bossowie otrzymują losowe mutacje, m.in. regenerację, teleportację, pancerz, rozszczepienie i odbijanie obrażeń,
- osiągnięcia i odkryte relikty zapisują się w profilu,
- dalszy wykładniczy rozwój broni, mutacji i laboratorium,
- pełna kompatybilność zapisu z wcześniejszą paczką dzięki scalaniu brakujących pól.

## Online CO-OP dla dwóch graczy

Tryb wykorzystuje model host-autorytatywny:

- host symuluje przeciwników, cele, bossów i nagrody,
- drugi gracz przesyła ruch i aktywną umiejętność,
- pozycje oraz stan świata są synchronizowane przez serwer relay,
- gracze mają wspólne XP, ulepszenia, cele i kontrakt,
- partner ma własne automatyczne strzelanie,
- `SPACJA` u gościa uruchamia falę wsparcia,
- pokonany gracz może zostać automatycznie odtworzony po 8 sekundach, jeżeli partner nadal żyje,
- w CO-OP wzrasta liczba oraz wytrzymałość przeciwników.

### Test na jednym komputerze lub w sieci domowej

1. Uruchom `START_GRY.cmd`, aby zainstalować biblioteki.
2. Uruchom `server\START_SERWER.cmd`.
3. W obu kopiach gry otwórz `ONLINE CO-OP`.
4. Wpisz `ws://127.0.0.1:8765` przy teście na jednym komputerze.
5. Host wybiera `UTWÓRZ POKÓJ` i przekazuje sześci znakowy kod.
6. Drugi gracz wpisuje kod i klika `DOŁĄCZ`.
7. Host rozpoczyna ekspedycję.

W sieci domowej drugi komputer powinien użyć lokalnego IP komputera-serwera, np. `ws://192.168.1.50:8765`.

### Gra przez Internet

Paczka nie zawiera stale działającego publicznego serwera. Żeby grać z osobą z innego miasta lub kraju, obaj gracze muszą połączyć się z tym samym osiągalnym serwerem relay.

Masz trzy warianty:

1. **VPS** — uruchom `server/relay_server.py` na serwerze z publicznym adresem IP i otwartym portem 8765.
2. **Docker** — skopiuj foldery `server` i `deploy` na VPS, przejdź do `deploy` i uruchom `docker compose up -d --build`.
3. **Wirtualna sieć prywatna** — obaj gracze mogą użyć tej samej sieci Tailscale/ZeroTier. Host uruchamia `server\START_SERWER.cmd`, a obie gry używają jego adresu VPN.

Przy publicznym wdrożeniu najlepiej wystawić relay jako `wss://` za reverse proxy z certyfikatem HTTPS.

## Serwer na VPS bez Dockera

W folderze projektu:

```bash
python3 -m venv server-venv
server-venv/bin/pip install "websockets>=16.1,<17"
server-venv/bin/python server/relay_server.py --host 0.0.0.0 --port 8765
```

W grze wpisz:

```text
ws://ADRES_IP_VPS:8765
```

Jeżeli skonfigurujesz HTTPS i reverse proxy, użyj `wss://twoja-domena`.

## Sterowanie

- `WASD` lub strzałki — ruch,
- `ESC` — pauza albo wyjście z trybu gościa,
- `1`, `2`, `3` — wybór mutacji przez hosta,
- `SPACJA` — fala wsparcia gracza-gościa w CO-OP,
- `F11` — pełny ekran.

## Budowanie plików EXE

Gra:

```text
ZBUDUJ_EXE.cmd
```

Serwer relay:

```text
server\ZBUDUJ_SERWER_EXE.cmd
```

## Testy

```text
TESTY.cmd
```

Testy sprawdzają składnię, manifest 432 elementów i protokół tworzenia pokoju, dołączania oraz przekazywania ruchu.

## Ważne ograniczenia wersji 2.0

- CO-OP obsługuje dokładnie dwóch graczy.
- Host wybiera ulepszenia po awansie; gość w tym czasie widzi ekran oczekiwania.
- Jakość połączenia zależy od opóźnienia do serwera relay.
- Gra nie ma usługi matchmakingu ani publicznego serwera utrzymywanego przez autora paczki.

---

## Wersja 2.1 — prostszy CO-OP i aktualizacje online

- Publiczny serwer Render jest wpisany domyślnie.
- Host tworzy pokój jednym przyciskiem, a kod automatycznie trafia do schowka.
- Drugi gracz wkleja wyłącznie sześcioliterowy kod przyciskiem **WKLEJ KOD**, `Ctrl+V` albo prawym przyciskiem myszy.
- Adres serwera został schowany w ustawieniach zaawansowanych, ale można go normalnie wkleić.
- Gra ponawia połączenie do pięciu razy, gdy darmowy serwer Render właśnie się uruchamia.
- Menu **AKTUALIZACJE** sprawdza, pobiera i instaluje nowe wydania z serwera.
- Instalator sprawdza SHA-256, zachowuje folder `data`, wykonuje kopię starej wersji i ponownie uruchamia grę.
- `OPUBLIKUJ_AKTUALIZACJE.cmd` tworzy manifest i paczki gotowe do wgrania na GitHub/Render.

Pełna instrukcja znajduje się w `INSTRUKCJA_AKTUALIZACJI_ONLINE.txt`.


## Aktualizacja 2.2.0 — Global Network Update

- Nowy wygląd menu i sześć rozdziałów kampanii.
- Chat globalny dostępny bez tworzenia pokoju.
- Rozwój broni do 8 poziomu i pasywów do 7 poziomu.
- Serwer Render musi zostać zaktualizowany plikiem `relay_server.py` z folderu `DO_WGRANIA_NA_GITHUB`.


## Aktualizacja 2.2.2 — płynniejszy CO-OP

- Ruch drugiego gracza jest przewidywany lokalnie i reaguje od razu na WASD.
- Pozycje świata są interpolowane między snapshotami.
- Stare snapshoty i inputy są automatycznie odrzucane zamiast gromadzić się w kolejce.
- Host wysyła tylko obiekty znajdujące się w pobliżu widoku gościa.
- HUD pokazuje ping oraz rzeczywistą częstotliwość odbieranych snapshotów.
- Aktualizacja wymaga podmiany zarówno plików gry, jak i `relay_server.py` na Renderze.

Do publikacji wersji EXE uruchom `ZBUDUJ_I_OPUBLIKUJ_2.2.2.cmd`. Duży ZIP Windows zostanie przygotowany osobno do GitHub Release, a małe pliki serwera w `DO_WGRANIA_NA_GITHUB`.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender 2.2 - Budowanie EXE
color 0D

echo ============================================================
echo          BUDOWANIE CELL DEFENDER 2.2 EXE
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Najpierw uruchom INSTALUJ.cmd albo START_GRY.cmd.
    goto :fail
)
".venv\Scripts\python.exe" -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name "Cell_Defender" --add-data "assets;assets" --add-data "CONTENT_MANIFEST.json;." --collect-submodules websockets --hidden-import websockets.asyncio.client --hidden-import game.online --hidden-import game.global_chat --hidden-import game.update_ui --hidden-import game.updater main.py
if errorlevel 1 goto :fail

echo.
echo [OK] Gotowa gra znajduje sie w:
echo dist\Cell_Defender\Cell_Defender.exe
echo.
echo Aby aktualizacje EXE dzialaly, po zbudowaniu uruchom
 echo OPUBLIKUJ_AKTUALIZACJE.cmd i wybierz budowanie pakietu EXE.
pause
exit /b 0

:fail
echo.
echo [BLAD] Nie udalo sie zbudowac EXE.
pause
exit /b 1

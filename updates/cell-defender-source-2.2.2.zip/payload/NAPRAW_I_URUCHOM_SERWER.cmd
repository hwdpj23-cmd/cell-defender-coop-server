@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    echo Ponowna instalacja aiohttp...
    ".venv\Scripts\python.exe" -m pip uninstall -y aiohttp >nul 2>nul
    ".venv\Scripts\python.exe" -m pip install --no-cache-dir -r "server\requirements.txt"
)
call "%~dp0URUCHOM_SERWER_LOKALNY.cmd"
exit /b %ERRORLEVEL%

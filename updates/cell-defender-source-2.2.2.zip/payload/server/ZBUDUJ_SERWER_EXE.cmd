@echo off
setlocal
cd /d "%~dp0\.."
title Cell Defender 2.1 - Budowanie serwera EXE
if not exist ".venv\Scripts\python.exe" (
  echo Najpierw uruchom START_GRY.cmd.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r "server\requirements.txt"
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --console --name "Cell_Defender_Server" --collect-submodules aiohttp --add-data "server\updates;updates" server\relay_server.py
if errorlevel 1 goto :fail
echo.
echo [OK] Serwer: dist\Cell_Defender_Server.exe
pause
exit /b 0
:fail
echo [BLAD] Nie udalo sie zbudowac serwera.
pause
exit /b 1

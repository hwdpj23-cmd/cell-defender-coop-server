from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any

import pygame

from .data import (
    BOSS_NAMES, CHAPTERS, COLORS, ENEMY_TYPES, HEIGHT, MAP_POWERS,
    OBJECTIVE_RULES, PASSIVES, WEAPONS, WIDTH, WORLD_HEIGHT, WORLD_WIDTH,
)
from .entities import Boss, Enemy, FloatingText, Mine, Particle, Pickup, Player, Projectile
from .ui import Button, draw_progress
from .world import AnomalyNode, ExtractionPortal, ObjectiveBeacon, ObjectiveCore, RelicPickup, WorldChest, WorldPower
from .utils import clamp, draw_panel, draw_text, format_number, glow_circle, vec_from_angle, weighted_choice
from .content_expansion import (ACHIEVEMENTS, ANOMALIES, BIOMES, BOSS_MUTATIONS, CELL_CLASSES, CHALLENGES, CONTRACTS, GENE_AUGMENTS, RELICS, SYNERGIES)


@dataclass
class UpgradeCard:
    kind: str
    key: str


@dataclass
class BeamEffect:
    points: list[pygame.Vector2]
    color: tuple[int, int, int]
    life: float = .18
    age: float = 0.0

    @property
    def dead(self) -> bool:
        return self.age >= self.life

    def update(self, dt: float) -> None:
        self.age += dt

    def draw(self, surface: pygame.Surface) -> None:
        alpha = int(255 * max(0, 1 - self.age / self.life))
        if len(self.points) < 2:
            return
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        pts = [(int(p.x), int(p.y)) for p in self.points]
        pygame.draw.lines(layer, (*self.color, alpha // 3), False, pts, 10)
        pygame.draw.lines(layer, (*self.color, alpha), False, pts, 3)
        surface.blit(layer, (0, 0))


class GameplayScene:
    def __init__(self, app: Any, chapter_id: int):
        self.app = app
        self.chapter = CHAPTERS[chapter_id - 1]
        self.world_w = WORLD_WIDTH
        self.world_h = WORLD_HEIGHT
        self.player = Player(self)
        self.camera = pygame.Vector2(
            self.player.pos.x - WIDTH / 2,
            self.player.pos.y - HEIGHT / 2,
        )
        self.enemies: list[Enemy] = []
        self.projectiles: list[Projectile] = []
        self.pickups: list[Pickup] = []
        self.particles: list[Particle] = []
        self.texts: list[FloatingText] = []
        self.mines: list[Mine] = []
        self.beams: list[BeamEffect] = []
        self.elapsed = 0.0
        self.spawn_timer = .8
        self.kills = 0
        self.bosses_killed = 0
        self.run_dna = 0
        self.run_coins = 0
        self.level = 1
        self.xp = 0
        self.xp_needed = self.xp_for_level(self.level)
        self.difficulty = self.chapter["enemy_mul"]
        self.wave = 1
        self.paused = False
        self.game_over = False
        self.victory = False
        self.result_timer = 0.0
        self.upgrade_open = False
        self.upgrade_cards: list[UpgradeCard] = []
        self.pending_levels = 0
        self.weapon_levels = {key: 0 for key in WEAPONS}
        self.passive_levels = {key: 0 for key in PASSIVES}
        self.selected_class_key = str(self.app.save.data.get("settings", {}).get("selected_class", "class_01"))
        if self.selected_class_key not in CELL_CLASSES:
            self.selected_class_key = "class_01"
        self.selected_challenge_key = str(self.app.save.data.get("settings", {}).get("selected_challenge", "none"))
        if self.selected_challenge_key not in CHALLENGES:
            self.selected_challenge_key = "none"
        starting_weapon = CELL_CLASSES[self.selected_class_key]["starting_weapon"]
        self.weapon_levels[starting_weapon] = 1
        self.cooldowns = {key: 0.0 for key in WEAPONS}
        self.drone_tick = 0.0
        self.camera_shake = 0.0
        self.flash = 0.0
        # Bossowie czasowi są pobocznym zagrożeniem. Ostatni boss pojawia się
        # dopiero po wykonaniu celów mapy.
        self.boss_schedule = [120, 255]
        self.spawned_boss_indices: set[int] = set()
        self.final_boss_dead = False
        self.final_boss_spawned = False
        self.extraction_time = float(OBJECTIVE_RULES["extraction_time"])
        self.objective_phase = "cores"
        self.objective_cores_collected = 0
        self.beacons_activated = 0
        self.objective_flash = 0.0
        self.lysosome_pulse_timer = 0.0
        self.map_power_keys: set[str] = set()
        self.xp_mul = 1.0
        self.crit_damage_mul = 2.0
        self.boss_damage_mul = 1.0
        self.elite_damage_mul = 1.0
        self.cooldown_mul = 1.0
        self.projectile_size_mul = 1.0
        self.extra_projectiles = 0
        self.lifesteal = 0.0
        self.time_scale = 1.0
        self.temporary_bonuses: list[dict[str, Any]] = []
        self.collected_augments: set[str] = set()
        self.collected_relics: set[str] = set()
        self.unlocked_synergies: set[str] = set()
        self.elite_kills = 0
        self.chests_opened = 0
        self.powers_collected = 0
        self.boss_damage_done = 0.0
        self.distance_traveled = 0.0
        self._last_distance_pos = self.player.pos.copy()
        self.contract_key = random.choice(list(CONTRACTS))
        self.contract_progress = 0.0
        self.contract_complete = False
        self.objective_cores, self.beacons, self.map_powers, self.world_chests, self.portal = self.build_world_content()
        content_rng = random.Random(20000 + self.chapter["id"] * 733)
        relic_keys = content_rng.sample(list(RELICS), k=min(10, len(RELICS)))
        anomaly_keys = content_rng.sample(list(ANOMALIES), k=min(6, len(ANOMALIES)))
        center = pygame.Vector2(self.world_w / 2, self.world_h / 2)
        self.world_relics = [
            RelicPickup(pygame.Vector2(content_rng.randint(350, self.world_w - 350), content_rng.randint(350, self.world_h - 350)), key)
            for key in relic_keys
        ]
        self.world_anomalies = [
            AnomalyNode(pygame.Vector2(content_rng.randint(450, self.world_w - 450), content_rng.randint(450, self.world_h - 450)), key)
            for key in anomaly_keys
        ]
        self.biome_keys = content_rng.sample(list(BIOMES), k=4)
        self.apply_effect(CELL_CLASSES[self.selected_class_key]["effect"], CELL_CLASSES[self.selected_class_key]["value"], CELL_CLASSES[self.selected_class_key]["name"])
        self.apply_challenge()
        self.show_damage = bool(self.app.save.data["settings"].get("show_damage", True))
        self.pause_buttons: list[Button] = []
        self.result_buttons: list[Button] = []
        rng = random.Random(8100 + self.chapter["id"] * 97)
        self._background_cells = [
            (rng.randint(0, self.world_w), rng.randint(0, self.world_h), rng.randint(10, 42), rng.random() * math.tau, rng.uniform(.08, .25))
            for _ in range(420)
        ]
        self._world_specks = [
            (rng.randint(0, self.world_w), rng.randint(0, self.world_h), rng.randint(1, 3), rng.choice((COLORS["cyan"], COLORS["purple"], COLORS["pink"])))
            for _ in range(620)
        ]
        self.play_sound("start")

    @staticmethod
    def xp_for_level(level: int) -> int:
        """Wykładniczy koszt kolejnego poziomu, z łagodnym początkiem."""
        return max(28, int(28 * (1.17 ** max(0, level - 1)) + level * 4))

    @staticmethod
    def exp_stat(base: float, level: int, growth: float) -> float:
        return base * (growth ** max(0, level - 1))

    def get_active_players(self) -> list[Player]:
        players: list[Player] = []
        if self.player.hp > 0:
            players.append(self.player)
        for extra in getattr(self, "coop_players", []):
            if extra.hp > 0:
                players.append(extra)
        return players or [self.player]

    def closest_player(self, pos: pygame.Vector2) -> Player:
        return min(self.get_active_players(), key=lambda p: p.pos.distance_squared_to(pos))

    def any_player_near(self, pos: pygame.Vector2, radius: float) -> bool:
        return any(p.pos.distance_squared_to(pos) <= radius * radius for p in self.get_active_players())

    def apply_effect(self, effect: str, value: float, source: str = "") -> None:
        if effect == "damage_mul":
            self.player.damage_mul *= value
            for p in getattr(self, "coop_players", []): p.damage_mul *= value
        elif effect == "fire_rate_mul":
            self.player.fire_rate_mul *= value
            for p in getattr(self, "coop_players", []): p.fire_rate_mul *= value
        elif effect == "speed_mul":
            for p in self.get_active_players(): p.speed *= value
        elif effect == "max_hp_mul":
            for p in self.get_active_players():
                old = p.max_hp; p.max_hp *= value; p.hp += p.max_hp - old
        elif effect == "pickup_mul":
            for p in self.get_active_players(): p.pickup_radius *= value
        elif effect == "xp_mul":
            self.xp_mul *= value
        elif effect == "regen_add":
            for p in self.get_active_players(): p.regen += value
        elif effect == "armor_add":
            for p in self.get_active_players(): p.armor = min(.78, p.armor + value)
        elif effect == "luck_add":
            for p in self.get_active_players(): p.luck = min(.82, p.luck + value)
        elif effect == "crit_damage_mul":
            self.crit_damage_mul *= value
        elif effect == "boss_damage_mul":
            self.boss_damage_mul *= value
        elif effect == "elite_damage_mul":
            self.elite_damage_mul *= value
        elif effect == "cooldown_mul":
            self.cooldown_mul *= value
        elif effect == "projectile_size_mul":
            self.projectile_size_mul *= value
        elif effect == "extra_projectiles":
            self.extra_projectiles += int(value)
        elif effect == "lifesteal":
            self.lifesteal = min(.08, self.lifesteal + value)

    def remove_effect(self, effect: str, value: float) -> None:
        if effect == "damage_mul":
            self.player.damage_mul /= value
            for p in getattr(self, "coop_players", []): p.damage_mul /= value
        elif effect == "fire_rate_mul":
            self.player.fire_rate_mul /= value
            for p in getattr(self, "coop_players", []): p.fire_rate_mul /= value
        elif effect == "speed_mul":
            for p in self.get_active_players(): p.speed /= value
        elif effect == "xp_mul":
            self.xp_mul /= value

    def add_temporary_effect(self, effect: str, value: float, duration: float, label: str) -> None:
        self.apply_effect(effect, value, label)
        self.temporary_bonuses.append({"effect": effect, "value": value, "remaining": duration, "label": label})

    def apply_challenge(self) -> None:
        self.enemy_count_mul = 1.0
        self.enemy_hp_mul = 1.0
        self.enemy_speed_mul = 1.0
        self.drop_mul = 1.0
        self.boss_hp_mul = 1.0
        self.reward_mul = 1.0
        self.enemy_time_scale = 1.0
        if self.selected_challenge_key == "none":
            return
        data = CHALLENGES[self.selected_challenge_key]
        effect, value = data["effect"], float(data["value"])
        self.reward_mul = float(data["reward_mul"])
        if effect == "player_hp_mul":
            self.apply_effect("max_hp_mul", value, data["name"])
        elif effect == "enemy_count_mul": self.enemy_count_mul = value
        elif effect == "enemy_hp_mul": self.enemy_hp_mul = value
        elif effect == "enemy_speed_mul": self.enemy_speed_mul = value
        elif effect == "drop_mul": self.drop_mul = value
        elif effect == "boss_hp_mul": self.boss_hp_mul = value

    def biome_at(self, pos: pygame.Vector2) -> dict[str, Any]:
        col = 0 if pos.x < self.world_w / 2 else 1
        row = 0 if pos.y < self.world_h / 2 else 1
        return BIOMES[self.biome_keys[row * 2 + col]]

    def damage_against(self, enemy: Enemy, amount: float) -> float:
        if isinstance(enemy, Boss):
            amount *= self.boss_damage_mul
        elif enemy.elite:
            amount *= self.elite_damage_mul
        return amount

    def on_damage_dealt(self, amount: float, enemy: Enemy) -> None:
        if isinstance(enemy, Boss):
            self.boss_damage_done += amount
        if self.lifesteal > 0 and random.random() < .35:
            self.player.heal(amount * self.lifesteal)

    def on_enemy_killed(self, enemy: Enemy) -> None:
        if enemy.elite:
            self.elite_kills += 1
        self.update_contract_progress("kill", 1)
        if enemy.elite:
            self.update_contract_progress("elite", 1)

    def on_pickup_collected(self, kind: str, value: int) -> None:
        if kind == "dna":
            self.update_contract_progress("dna", value)

    def update_contract_progress(self, metric: str, amount: float) -> None:
        if self.contract_complete:
            return
        contract = CONTRACTS[self.contract_key]
        if contract["type"] != metric:
            return
        self.contract_progress += amount
        if self.contract_progress >= contract["target"]:
            self.complete_contract()

    def complete_contract(self) -> None:
        if self.contract_complete:
            return
        self.contract_complete = True
        data = CONTRACTS[self.contract_key]
        self.run_dna += int(data["reward_dna"])
        self.add_xp(int(data["reward_xp"]))
        expansion = self.app.save.data.setdefault("expansion", {})
        expansion["completed_contracts"] = int(expansion.get("completed_contracts", 0)) + 1
        self.app.toast(f"KONTRAKT UKOŃCZONY: {data['name']}", COLORS["green"])
        self.play_sound("level")

    def collect_relic(self, relic: RelicPickup) -> None:
        data = RELICS[relic.key]
        self.collected_relics.add(relic.key)
        self.apply_effect(data["effect"], float(data["value"]), data["name"])
        discovered = self.app.save.data.setdefault("expansion", {}).setdefault("discovered_relics", [])
        if relic.key not in discovered:
            discovered.append(relic.key)
        self.spawn_burst(relic.pos, data["color"], 42)
        self.app.toast(f"RELIKT: {data['name']}", data["color"])
        self.check_synergies()

    def trigger_anomaly(self, anomaly: AnomalyNode) -> None:
        data = ANOMALIES[anomaly.key]
        power = int(data["power"])
        effect = data["effect"]
        if effect == "xp_burst":
            self.add_xp(40 * power + self.level * 8)
        elif effect == "heal":
            for p in self.get_active_players(): p.heal(p.max_hp * (.15 + power * .08))
        elif effect == "enemy_wave":
            self.spawn_objective_wave(anomaly.pos, 5 + power * 3)
            self.run_dna += power
        elif effect == "speed_boost":
            self.add_temporary_effect("speed_mul", 1.12 + power * .06, 18 + power * 4, data["name"])
        elif effect == "damage_boost":
            self.add_temporary_effect("damage_mul", 1.18 + power * .08, 18 + power * 4, data["name"])
        elif effect == "dna_burst":
            self.run_dna += 2 + power * 2
        elif effect == "time_slow":
            self.enemy_time_scale = max(.35, .75 - power * .08)
            self.temporary_bonuses.append({"effect": "enemy_time_scale", "value": 1.0, "remaining": 10 + power * 3, "label": data["name"]})
        elif effect == "relic":
            available = [k for k in RELICS if k not in self.collected_relics]
            if available:
                fake = RelicPickup(anomaly.pos.copy(), random.choice(available), True)
                self.collect_relic(fake)
        self.spawn_burst(anomaly.pos, data["color"], 50)
        self.app.toast(f"ANOMALIA: {data['name']}", data["color"])

    def apply_augment(self, key: str) -> None:
        data = GENE_AUGMENTS[key]
        self.collected_augments.add(key)
        self.apply_effect(data["effect"], float(data["value"]), data["name"])
        self.app.toast(f"GEN: {data['name']}", data["color"])
        self.check_synergies()

    def check_synergies(self) -> None:
        for key, data in SYNERGIES.items():
            if key in self.unlocked_synergies:
                continue
            if self.weapon_levels.get(data["weapon"], 0) >= data["required_weapon"] and self.passive_levels.get(data["passive"], 0) >= data["required_passive"]:
                self.unlocked_synergies.add(key)
                self.apply_effect(data["effect"], float(data["value"]), data["name"])
                self.app.toast(f"EWOLUCJA: {data['name']}", data["color"])

    def build_world_content(self) -> tuple[list[ObjectiveCore], list[ObjectiveBeacon], list[WorldPower], list[WorldChest], ExtractionPortal]:
        center = pygame.Vector2(self.world_w / 2, self.world_h / 2)
        cores = [
            ObjectiveCore(center + pygame.Vector2(-1150, -720), 1),
            ObjectiveCore(center + pygame.Vector2(1180, 760), 2),
        ]
        beacons = [
            ObjectiveBeacon(center + pygame.Vector2(-1780, 900), 1, float(OBJECTIVE_RULES["beacon_charge_time"])),
            ObjectiveBeacon(center + pygame.Vector2(1710, -850), 2, float(OBJECTIVE_RULES["beacon_charge_time"])),
            ObjectiveBeacon(center + pygame.Vector2(100, 1450), 3, float(OBJECTIVE_RULES["beacon_charge_time"])),
        ]
        power_positions = [
            ("mitochondrium", (-720, 520)),
            ("ribosome", (840, -520)),
            ("membrane", (-1480, -1120)),
            ("cilia", (1530, 1080)),
            ("lysosome", (70, -1320)),
            ("nucleus", (1380, 180)),
        ]
        powers = [WorldPower(center + pygame.Vector2(offset), key) for key, offset in power_positions]
        chest_offsets = [(-420, -880), (520, 920), (-1420, 250), (1460, -220), (60, 1180)]
        chests = [WorldChest(center + pygame.Vector2(offset), i + 1) for i, offset in enumerate(chest_offsets)]
        portal = ExtractionPortal(center + pygame.Vector2(80, -1650))
        return cores, beacons, powers, chests, portal

    def objective_text(self) -> str:
        if self.objective_phase == "cores":
            return f"Znajdź rdzenie organelli: {self.objective_cores_collected}/{OBJECTIVE_RULES['cores_required']}"
        if self.objective_phase == "beacons":
            return f"Aktywuj węzły odporności: {self.beacons_activated}/{OBJECTIVE_RULES['beacons_required']}"
        if self.objective_phase == "portal" and not self.portal.boss_started:
            return "Dotrzyj do Portalu Rdzenia"
        if self.objective_phase == "boss" and not self.final_boss_dead:
            return "Pokonaj Strażnika Infekcji"
        if self.final_boss_dead:
            return "Wróć do portalu i utrzymaj pozycję"
        return "Eksploruj mapę"

    def active_objective_positions(self) -> list[tuple[pygame.Vector2, tuple[int, int, int], str]]:
        if self.objective_phase == "cores":
            return [(core.pos, COLORS["cyan"], f"Rdzeń {core.index}") for core in self.objective_cores if not core.collected]
        if self.objective_phase == "beacons":
            return [(beacon.pos, COLORS["purple"], f"Węzeł {beacon.index}") for beacon in self.beacons if not beacon.activated]
        return [(self.portal.pos, COLORS["green"] if self.final_boss_dead else COLORS["red"], "Portal")]

    def collect_objective_core(self, core: ObjectiveCore) -> None:
        self.objective_cores_collected += 1
        self.run_dna += 2
        self.add_xp(35 + self.level * 3)
        self.spawn_burst(core.pos, COLORS["cyan"], 32)
        self.add_text(core.pos, "+ RDZEŃ ORGANELLI", COLORS["cyan"])
        self.app.toast(f"Rdzeń organelli {self.objective_cores_collected}/{OBJECTIVE_RULES['cores_required']}", COLORS["cyan"])
        self.objective_flash = 2.0
        if self.objective_cores_collected >= int(OBJECTIVE_RULES["cores_required"]):
            self.objective_phase = "beacons"
            self.app.toast("Węzły odporności zostały odblokowane!", COLORS["purple"])
            self.camera_shake += 10

    def activate_beacon(self, beacon: ObjectiveBeacon) -> None:
        self.beacons_activated += 1
        self.run_dna += 3
        self.add_xp(55 + self.level * 4)
        self.explode(beacon.pos, 180, self.damage_value(38), COLORS["green"], knockback=55)
        self.app.toast(f"Węzeł {beacon.index} aktywny — {self.beacons_activated}/{OBJECTIVE_RULES['beacons_required']}", COLORS["green"])
        self.objective_flash = 2.2
        if self.beacons_activated >= int(OBJECTIVE_RULES["beacons_required"]):
            self.objective_phase = "portal"
            self.portal.unlocked = True
            self.app.toast("Portal Rdzenia otwarty. Dotrzyj do niego!", COLORS["yellow"])
            self.camera_shake += 16

    def spawn_objective_wave(self, center: pygame.Vector2, count: int) -> None:
        for _ in range(count):
            angle = random.random() * math.tau
            distance = random.uniform(180, 330)
            pos = center + vec_from_angle(angle) * distance
            pos.x = clamp(pos.x, 80, self.world_w - 80)
            pos.y = clamp(pos.y, 80, self.world_h - 80)
            kind = random.choice(["virus", "bacteria", "spore", "parasite"])
            self.enemies.append(Enemy(kind, pos, self.difficulty * 1.12, elite=random.random() < .08))

    def collect_map_power(self, power: WorldPower) -> None:
        key = power.key
        self.map_power_keys.add(key)
        self.powers_collected += 1
        self.update_contract_progress("powers", 1)
        if key == "mitochondrium":
            self.apply_effect("fire_rate_mul", 1.35, MAP_POWERS[key]["name"])
            self.apply_effect("speed_mul", 1.10, MAP_POWERS[key]["name"])
        elif key == "ribosome":
            self.apply_effect("damage_mul", 1.45, MAP_POWERS[key]["name"])
        elif key == "membrane":
            self.apply_effect("max_hp_mul", 1.30, MAP_POWERS[key]["name"])
            for p in self.get_active_players(): p.heal(25)
        elif key == "cilia":
            self.apply_effect("speed_mul", 1.25, MAP_POWERS[key]["name"])
            self.apply_effect("pickup_mul", 1.20, MAP_POWERS[key]["name"])
        elif key == "lysosome":
            for p in self.get_active_players(): p.regen = p.regen * 1.25 + 1.10
            self.lysosome_pulse_timer = 2.0
        elif key == "nucleus":
            for p in self.get_active_players(): p.luck = min(.72, 1 - (1 - p.luck) * .80)
        data = MAP_POWERS[key]
        self.spawn_burst(power.pos, data["color"], 40)
        self.add_xp(45 + self.level * 4)
        self.app.toast(f"Moc mapy: {data['name']}", data["color"])

    def open_world_chest(self, chest: WorldChest) -> None:
        self.chests_opened += 1
        self.update_contract_progress("chests", 1)
        self.run_dna += 1 + int(random.random() < self.player.luck)
        self.player.heal(max(12, self.player.max_hp * .12))
        candidates: list[tuple[str, str]] = []
        for key, data in WEAPONS.items():
            if self.weapon_levels[key] < data["max"]:
                candidates.extend([("weapon", key)] * (3 if self.weapon_levels[key] > 0 else 1))
        for key, data in PASSIVES.items():
            if self.passive_levels[key] < data["max"]:
                candidates.extend([("passive", key)] * 2)
        if candidates:
            kind, key = random.choice(candidates)
            if kind == "weapon":
                self.weapon_levels[key] += 1
                label = f"{WEAPONS[key]['name']} Lv.{self.weapon_levels[key]}"
                color = WEAPONS[key]["color"]
            else:
                self.passive_levels[key] += 1
                self.apply_passive(key)
                label = f"{PASSIVES[key]['name']} Lv.{self.passive_levels[key]}"
                color = PASSIVES[key]["color"]
            self.app.toast(f"Skrzynia: {label}", color)
        self.spawn_burst(chest.pos, COLORS["yellow"], 46)
        self.play_sound("level")

    def configure_boss_mutation(self, boss: Boss, mutation_key: str) -> None:
        data = BOSS_MUTATIONS[mutation_key]
        effect = data["effect"]
        boss.mutation_key = mutation_key
        boss.name = f"{data['name']} {boss.name}"
        boss.damage_reduction = .0
        boss.regen_rate = 0.0
        boss.teleport_cd = 999.0
        boss.reflect_chance = 0.0
        boss.death_explosion = False
        boss.split_on_death = False
        if effect in ("hp", "all"):
            boss.max_hp *= 1.55; boss.hp = boss.max_hp
        if effect in ("speed", "all"):
            boss.speed *= 1.35
        if effect in ("armor", "all"):
            boss.damage_reduction = .28
        if effect in ("regen", "all"):
            boss.regen_rate = boss.max_hp * .006
        if effect in ("teleport", "phase", "all"):
            boss.teleport_cd = 2.8
        if effect in ("reflect", "all"):
            boss.reflect_chance = .12
        if effect in ("explode", "all"):
            boss.death_explosion = True
        if effect in ("split", "clone", "all"):
            boss.split_on_death = True
        if effect in ("summon", "all"):
            boss.summon_cd *= .55
        if effect in ("poison", "chain", "slow", "lifesteal", "all"):
            boss.special_attack = effect

    def start_final_boss(self, portal_pos: pygame.Vector2) -> None:
        if self.final_boss_spawned:
            return
        self.final_boss_spawned = True
        self.objective_phase = "boss"
        name = "Strażnik Rdzenia Omega"
        scale = self.chapter["enemy_mul"] * (2.15 + self.elapsed / 360)
        spawn = portal_pos + pygame.Vector2(0, 250)
        boss = Boss(spawn, scale, name, phase_count=4)
        boss.max_hp *= self.boss_hp_mul
        boss.hp = boss.max_hp
        mutation_key = random.choice(list(BOSS_MUTATIONS))
        self.configure_boss_mutation(boss, mutation_key)
        boss.final_boss = True
        self.enemies.append(boss)
        self.app.toast(f"CEL GŁÓWNY — {name}", COLORS["red"])
        self.camera_shake += 22
        self.play_sound("boss")

    def update_world_content(self, dt: float) -> None:
        for core in self.objective_cores:
            core.update(dt, self)
        for beacon in self.beacons:
            beacon.update(dt, self)
        for power in self.map_powers:
            power.update(dt, self)
        for chest in self.world_chests:
            chest.update(dt, self)
        for relic in self.world_relics:
            relic.update(dt, self)
        for anomaly in self.world_anomalies:
            anomaly.update(dt, self)
        self.portal.update(dt, self)
        if "lysosome" in self.map_power_keys:
            self.lysosome_pulse_timer -= dt
            if self.lysosome_pulse_timer <= 0:
                self.explode(self.player.pos, 145, self.damage_value(22 + self.level * .55), MAP_POWERS["lysosome"]["color"], knockback=20)
                self.lysosome_pulse_timer = 8.0

    def update_camera(self, dt: float) -> None:
        target = self.player.pos - pygame.Vector2(WIDTH / 2, HEIGHT / 2)
        target.x = clamp(target.x, 0, self.world_w - WIDTH)
        target.y = clamp(target.y, 0, self.world_h - HEIGHT)
        follow = 1.0 - math.exp(-8.5 * dt)
        self.camera += (target - self.camera) * follow

    def camera_transform_objects(self, offset: pygame.Vector2) -> tuple[list[tuple[Any, pygame.Vector2]], list[tuple[BeamEffect, list[pygame.Vector2]]]]:
        objects: list[Any] = [self.player]
        objects.extend(self.enemies)
        objects.extend(self.projectiles)
        objects.extend(self.pickups)
        objects.extend(self.particles)
        objects.extend(self.texts)
        objects.extend(self.mines)
        objects.extend(self.objective_cores)
        objects.extend(self.beacons)
        objects.extend(self.map_powers)
        objects.extend(self.world_chests)
        objects.extend(self.world_relics)
        objects.extend(self.world_anomalies)
        objects.extend(getattr(self, "coop_players", []))
        objects.append(self.portal)
        states: list[tuple[Any, pygame.Vector2]] = []
        for obj in objects:
            states.append((obj, obj.pos.copy()))
            obj.pos -= offset
        beam_states: list[tuple[BeamEffect, list[pygame.Vector2]]] = []
        for beam in self.beams:
            original = [point.copy() for point in beam.points]
            beam_states.append((beam, original))
            beam.points = [point - offset for point in beam.points]
        return states, beam_states

    @staticmethod
    def restore_camera_objects(states: list[tuple[Any, pygame.Vector2]], beam_states: list[tuple[BeamEffect, list[pygame.Vector2]]]) -> None:
        for obj, pos in states:
            obj.pos = pos
        for beam, points in beam_states:
            beam.points = points

    def play_sound(self, key: str) -> None:
        self.app.audio.play(key)

    def add_text(self, pos: pygame.Vector2, text: str, color: tuple[int, int, int]) -> None:
        if len(self.texts) < 80:
            self.texts.append(FloatingText(pos.copy(), text, color))

    def spawn_burst(self, pos: pygame.Vector2, color: tuple[int, int, int], count: int) -> None:
        particles_setting = int(self.app.save.data["settings"].get("particles", 2))
        actual = int(count * (.45 if particles_setting == 1 else 1 if particles_setting == 2 else 1.5))
        if particles_setting == 0:
            return
        room = max(0, 450 - len(self.particles))
        for _ in range(min(actual, room)):
            angle = random.random() * math.tau
            speed = random.uniform(40, 210)
            self.particles.append(Particle(pos.copy(), vec_from_angle(angle) * speed, color, random.uniform(2, 5), random.uniform(.35, .9)))

    def enemy_shoot(self, pos: pygame.Vector2, direction: pygame.Vector2, damage: float, speed: float = 230, radius: float = 5) -> None:
        if direction.length_squared() == 0:
            direction = pygame.Vector2(1, 0)
        self.projectiles.append(Projectile(pos.copy(), direction.normalize() * speed, damage, radius, COLORS["red"], 4, 1, "enemy"))

    def add_xp(self, amount: int) -> None:
        if self.game_over:
            return
        self.xp += max(1, int(amount * self.xp_mul))
        while self.xp >= self.xp_needed:
            self.xp -= self.xp_needed
            self.level += 1
            self.xp_needed = self.xp_for_level(self.level)
            self.pending_levels += 1
        if self.pending_levels > 0 and not self.upgrade_open:
            self.open_upgrade()

    def open_upgrade(self) -> None:
        self.upgrade_open = True
        self.upgrade_cards = self.generate_upgrades(3)
        self.play_sound("level")

    def generate_upgrades(self, count: int) -> list[UpgradeCard]:
        pool: list[UpgradeCard] = []
        owned_weapons = sum(1 for level in self.weapon_levels.values() if level > 0)
        for key, data in WEAPONS.items():
            level = self.weapon_levels[key]
            if level > 0 and level < data["max"]:
                pool.extend([UpgradeCard("weapon", key)] * 4)
            elif level == 0 and owned_weapons < 6:
                pool.extend([UpgradeCard("weapon", key)] * 2)
        for key, data in PASSIVES.items():
            level = self.passive_levels[key]
            if level < data["max"]:
                pool.extend([UpgradeCard("passive", key)] * (3 if level > 0 else 2))
        available_genes = [key for key in GENE_AUGMENTS if key not in self.collected_augments]
        if available_genes:
            for key in random.sample(available_genes, k=min(8, len(available_genes))):
                pool.extend([UpgradeCard("augment", key)] * 2)
        random.shuffle(pool)
        result: list[UpgradeCard] = []
        used: set[tuple[str, str]] = set()
        for card in pool:
            token = (card.kind, card.key)
            if token not in used:
                result.append(card)
                used.add(token)
            if len(result) >= count:
                break
        while len(result) < count:
            key = random.choice(list(PASSIVES))
            token = ("passive", key)
            if token not in used:
                result.append(UpgradeCard("passive", key))
                used.add(token)
        return result

    def choose_upgrade(self, index: int) -> None:
        if not self.upgrade_open or index < 0 or index >= len(self.upgrade_cards):
            return
        card = self.upgrade_cards[index]
        if card.kind == "weapon":
            self.weapon_levels[card.key] += 1
            level = self.weapon_levels[card.key]
            self.app.toast(f"{WEAPONS[card.key]['name']} — poziom {level}", WEAPONS[card.key]["color"])
        elif card.kind == "passive":
            self.passive_levels[card.key] += 1
            self.apply_passive(card.key)
            level = self.passive_levels[card.key]
            self.app.toast(f"{PASSIVES[card.key]['name']} — poziom {level}", PASSIVES[card.key]["color"])
        else:
            self.apply_augment(card.key)
        self.check_synergies()
        self.pending_levels = max(0, self.pending_levels - 1)
        if self.pending_levels > 0:
            self.upgrade_cards = self.generate_upgrades(3)
        else:
            self.upgrade_open = False
            self.upgrade_cards = []

    def apply_passive(self, key: str) -> None:
        if key == "power":
            self.apply_effect("damage_mul", 1.18, PASSIVES[key]["name"])
        elif key == "haste":
            self.apply_effect("fire_rate_mul", 1.15, PASSIVES[key]["name"])
        elif key == "vitality":
            self.apply_effect("max_hp_mul", 1.20, PASSIVES[key]["name"])
        elif key == "speed":
            self.apply_effect("speed_mul", 1.11, PASSIVES[key]["name"])
        elif key == "magnet":
            self.apply_effect("pickup_mul", 1.18, PASSIVES[key]["name"])
        elif key == "armor":
            for p in self.get_active_players():
                p.armor = min(.68, 1.0 - (1.0 - p.armor) * .92)
        elif key == "regen":
            for p in self.get_active_players():
                p.regen = p.regen * 1.35 + .25
        elif key == "luck":
            for p in self.get_active_players():
                p.luck = min(.65, 1.0 - (1.0 - p.luck) * .94)
        self.check_synergies()

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if self.upgrade_open:
                if event.key in (pygame.K_1, pygame.K_KP1):
                    self.choose_upgrade(0)
                elif event.key in (pygame.K_2, pygame.K_KP2):
                    self.choose_upgrade(1)
                elif event.key in (pygame.K_3, pygame.K_KP3):
                    self.choose_upgrade(2)
                return
            if self.game_over:
                if event.key == pygame.K_RETURN:
                    self.app.start_run(self.chapter["id"])
                elif event.key == pygame.K_ESCAPE:
                    self.app.show_menu()
                return
            if event.key == pygame.K_ESCAPE:
                self.paused = not self.paused
                if self.paused:
                    self.build_pause_buttons()
                return
        if self.upgrade_open and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self.upgrade_card_rects()):
                if rect.collidepoint(event.pos):
                    self.choose_upgrade(i)
                    return
        if self.paused:
            for button in self.pause_buttons:
                if button.handle(event):
                    return
        if self.game_over:
            for button in self.result_buttons:
                if button.handle(event):
                    return

    def build_pause_buttons(self) -> None:
        self.pause_buttons = [
            Button(pygame.Rect(500, 340, 280, 52), "WZNÓW", lambda: setattr(self, "paused", False)),
            Button(pygame.Rect(500, 406, 280, 52), "RESTART", lambda: self.app.start_run(self.chapter["id"]), secondary=True),
            Button(pygame.Rect(500, 472, 280, 52), "MENU GŁÓWNE", self.app.show_menu, secondary=True),
        ]

    def build_result_buttons(self) -> None:
        self.result_buttons = [
            Button(pygame.Rect(420, 548, 210, 52), "ZAGRAJ PONOWNIE", lambda: self.app.start_run(self.chapter["id"])),
            Button(pygame.Rect(650, 548, 210, 52), "MENU", self.app.show_menu, secondary=True),
        ]

    def update(self, dt: float) -> None:
        if self.paused or self.upgrade_open:
            return
        if self.game_over:
            self.result_timer += dt
            self.update_effects(dt)
            return
        dt = min(dt, .05)
        self.elapsed += dt
        self.wave = 1 + int(self.elapsed // 30)
        # Przeciwnicy również rosną geometrycznie, więc eksploracja ma coraz
        # większą presję i nie opłaca się ignorować celu głównego bez końca.
        self.difficulty = self.chapter["enemy_mul"] * (1.085 ** (self.elapsed / 30.0))
        if self.elapsed > self.chapter["duration"]:
            self.difficulty *= 1.0 + (self.elapsed - self.chapter["duration"]) / 180.0
        self.player.update(dt)
        for coop_player in getattr(self, "coop_players", []):
            coop_player.update(dt)
        moved = self.player.pos.distance_to(self._last_distance_pos)
        self.distance_traveled += moved
        self._last_distance_pos = self.player.pos.copy()
        self.update_contract_progress("travel", moved)
        self.update_contract_progress("survive", dt)
        self.update_contract_progress("boss_damage", max(0.0, self.boss_damage_done - getattr(self, "_last_boss_damage", 0.0)))
        self._last_boss_damage = self.boss_damage_done
        self.update_temporary_bonuses(dt)
        self.update_camera(dt)
        self.update_world_content(dt)
        self.update_spawning(dt)
        self.update_weapons(dt)
        for enemy in list(self.enemies):
            enemy.update(dt * self.enemy_time_scale, self)
        for projectile in list(self.projectiles):
            projectile.update(dt, self)
        for mine in list(self.mines):
            mine.update(dt, self)
        for pickup in list(self.pickups):
            pickup.update(dt, self.closest_player(pickup.pos))
        self.resolve_enemy_separation()
        self.enemies = [e for e in self.enemies if not e.dead]
        self.projectiles = [p for p in self.projectiles if not p.dead]
        self.pickups = [p for p in self.pickups if not p.dead]
        self.mines = [m for m in self.mines if not m.dead]
        self.update_effects(dt)
        self.camera_shake = max(0, self.camera_shake - 30 * dt)
        self.flash = max(0, self.flash - dt)
        self.objective_flash = max(0.0, self.objective_flash - dt)

    def update_temporary_bonuses(self, dt: float) -> None:
        keep: list[dict[str, Any]] = []
        for bonus in self.temporary_bonuses:
            bonus["remaining"] -= dt
            if bonus["remaining"] > 0:
                keep.append(bonus)
                continue
            if bonus["effect"] == "enemy_time_scale":
                self.enemy_time_scale = 1.0
            else:
                self.remove_effect(str(bonus["effect"]), float(bonus["value"]))
            self.app.toast(f"Wygasł efekt: {bonus['label']}", COLORS["muted"])
        self.temporary_bonuses = keep

    def update_effects(self, dt: float) -> None:
        for p in self.particles:
            p.update(dt)
        for t in self.texts:
            t.update(dt)
        for b in self.beams:
            b.update(dt)
        self.particles = [p for p in self.particles if not p.dead]
        self.texts = [t for t in self.texts if not t.dead]
        self.beams = [b for b in self.beams if not b.dead]

    def update_spawning(self, dt: float) -> None:
        for index, moment in enumerate(self.boss_schedule):
            if self.elapsed >= moment and index not in self.spawned_boss_indices:
                self.spawned_boss_indices.add(index)
                self.spawn_boss(index)
        active_boss = any(isinstance(e, Boss) for e in self.enemies)
        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            pressure = 1 + self.elapsed / 85
            count = 1 + int(pressure // 2.1)
            if active_boss:
                count = max(1, count - 1)
            count = max(1, int(math.ceil(count * self.enemy_count_mul)))
            for _ in range(min(10, count)):
                self.spawn_enemy()
            interval = max(.17, 1.05 / (1 + self.elapsed / 105))
            self.spawn_timer = interval * random.uniform(.75, 1.18)

    def spawn_position(self, margin: int = 45) -> pygame.Vector2:
        # Wrogowie pojawiają się tuż poza kamerą, a nie na krawędzi całej mapy.
        angle = random.random() * math.tau
        distance = random.uniform(max(WIDTH, HEIGHT) * .58 + margin, max(WIDTH, HEIGHT) * .78 + margin)
        pos = self.player.pos + vec_from_angle(angle) * distance
        pos.x = clamp(pos.x, margin, self.world_w - margin)
        pos.y = clamp(pos.y, margin, self.world_h - margin)
        return pos

    def spawn_enemy(self) -> None:
        if len(self.enemies) >= 340:
            return
        t = self.elapsed
        options: list[tuple[str, float]] = [("virus", 5), ("bacteria", 3.5)]
        if t > 35:
            options.append(("spore", 1.5))
        if t > 65:
            options.append(("parasite", 1.7))
        if t > 105:
            options.append(("splitter", 1.7))
        kind = weighted_choice(options)
        elite_chance = min(.12, .012 + t / 5000 + self.player.luck * .015)
        spawn = self.spawn_position()
        enemy = Enemy(str(kind), spawn, self.difficulty, random.random() < elite_chance)
        biome = self.biome_at(spawn)
        enemy.max_hp *= self.enemy_hp_mul * float(biome["enemy_hp_mul"])
        enemy.hp = enemy.max_hp
        enemy.speed *= self.enemy_speed_mul * float(biome["enemy_speed_mul"])
        enemy.xp = max(1, int(enemy.xp * float(biome["xp_mul"]) * self.drop_mul))
        self.enemies.append(enemy)

    def spawn_boss(self, index: int) -> None:
        name = BOSS_NAMES[min(len(BOSS_NAMES) - 1, (self.chapter["id"] - 1) * 2 + index)]
        scale = self.chapter["enemy_mul"] * (1.0 + index * .55 + self.elapsed / 400)
        boss = Boss(self.spawn_position(100), scale, name, phase_count=2 + min(2, index))
        boss.max_hp *= self.boss_hp_mul
        boss.hp = boss.max_hp
        mutation_key = random.choice(list(BOSS_MUTATIONS))
        self.configure_boss_mutation(boss, mutation_key)
        boss.final_boss = False
        self.enemies.append(boss)
        self.app.toast(f"BOSS: {name}", COLORS["red"])
        self.camera_shake += 15
        self.play_sound("boss")

    def resolve_enemy_separation(self) -> None:
        if len(self.enemies) > 260:
            return
        for i in range(len(self.enemies)):
            a = self.enemies[i]
            if a.dead:
                continue
            for j in range(i + 1, min(len(self.enemies), i + 9)):
                b = self.enemies[j]
                if b.dead:
                    continue
                delta = b.pos - a.pos
                min_dist = (a.radius + b.radius) * .7
                dist_sq = delta.length_squared()
                if 0 < dist_sq < min_dist * min_dist:
                    dist = math.sqrt(dist_sq)
                    push = delta / dist * (min_dist - dist) * .13
                    b.pos += push
                    a.pos -= push

    def nearest_enemies(self, pos: pygame.Vector2, count: int, exclude: set[int] | None = None) -> list[Enemy]:
        exclude = exclude or set()
        live = [e for e in self.enemies if not e.dead and id(e) not in exclude]
        live.sort(key=lambda e: pos.distance_squared_to(e.pos))
        return live[:count]

    def update_weapons(self, dt: float) -> None:
        for key in self.cooldowns:
            self.cooldowns[key] = max(0, self.cooldowns[key] - dt)
        if self.weapon_levels["capsule"] > 0 and self.cooldowns["capsule"] <= 0:
            self.fire_capsule()
        if self.weapon_levels["needles"] > 0 and self.cooldowns["needles"] <= 0:
            self.fire_needles()
        if self.weapon_levels["bubble"] > 0 and self.cooldowns["bubble"] <= 0:
            self.fire_bubble()
        if self.weapon_levels["enzyme"] > 0 and self.cooldowns["enzyme"] <= 0:
            self.fire_enzyme()
        if self.weapon_levels["pulse"] > 0 and self.cooldowns["pulse"] <= 0:
            self.fire_pulse()
        if self.weapon_levels["chain"] > 0 and self.cooldowns["chain"] <= 0:
            self.fire_chain()
        if self.weapon_levels["mine"] > 0 and self.cooldowns["mine"] <= 0:
            self.place_mine()
        if self.weapon_levels["drone"] > 0:
            self.update_drones(dt)

    def damage_value(self, base: float) -> float:
        return base * self.player.damage_mul

    def fire_capsule(self) -> None:
        level = self.weapon_levels["capsule"]
        targets = self.nearest_enemies(self.player.pos, 1)
        if not targets:
            self.cooldowns["capsule"] = .16
            return
        direction = (targets[0].pos - self.player.pos).normalize()
        shots = 1 + (1 if level >= 4 else 0) + (1 if level >= 6 else 0) + self.extra_projectiles
        for i in range(shots):
            offset = (i - (shots - 1) / 2) * .12
            d = direction.rotate_rad(offset)
            self.projectiles.append(Projectile(
                self.player.pos + d * 28,
                d * self.exp_stat(530, level, 1.035),
                self.damage_value(self.exp_stat(10, level, 1.42)),
                self.exp_stat(5, level, 1.06) * self.projectile_size_mul,
                WEAPONS["capsule"]["color"],
                2.2,
                1 + level // 3,
                "player",
                "bullet",
                0,
                min(.55, .04 + self.player.luck),
            ))
        self.cooldowns["capsule"] = max(.10, (.72 * (.91 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("shoot")

    def fire_needles(self) -> None:
        level = self.weapon_levels["needles"]
        count = 6 + (level - 1) * 2 + self.extra_projectiles * 2
        offset = random.random() * math.tau
        for i in range(count):
            d = vec_from_angle(offset + i * math.tau / count)
            self.projectiles.append(Projectile(
                self.player.pos + d * 25, d * self.exp_stat(370, level, 1.03), self.damage_value(self.exp_stat(7, level, 1.40)), 3 * self.projectile_size_mul,
                WEAPONS["needles"]["color"], 2.2, 1 + level // 3, "player", "needle", 0,
                min(.55, .03 + self.player.luck),
            ))
        self.cooldowns["needles"] = max(.55, (3.4 * (.90 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("needle")

    def fire_bubble(self) -> None:
        level = self.weapon_levels["bubble"]
        targets = self.nearest_enemies(self.player.pos, 1)
        d = (targets[0].pos - self.player.pos).normalize() if targets else vec_from_angle(random.random() * math.tau)
        self.projectiles.append(Projectile(
            self.player.pos + d * 30, d * self.exp_stat(165, level, 1.05), self.damage_value(self.exp_stat(11, level, 1.48)), self.exp_stat(14, level, 1.11) * self.projectile_size_mul,
            WEAPONS["bubble"]["color"], 7.5, 5 + level * 2, "player", "bubble", 3 + level // 2,
            min(.45, .02 + self.player.luck * .7),
        ))
        self.cooldowns["bubble"] = max(.9, (4.5 * (.89 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("bubble")

    def fire_enzyme(self) -> None:
        level = self.weapon_levels["enzyme"]
        targets = self.nearest_enemies(self.player.pos, 1 + level // 2)
        if not targets:
            self.cooldowns["enzyme"] = .2
            return
        points = [self.player.pos.copy()]
        for enemy in targets:
            crit = random.random() < min(.5, .02 + self.player.luck)
            dealt = self.damage_value(self.exp_stat(16, level, 1.45)) * (self.crit_damage_mul if crit else 1)
            dealt = self.damage_against(enemy, dealt)
            enemy.take_damage(dealt, self, crit=crit)
            self.on_damage_dealt(dealt, enemy)
            points.append(enemy.pos.copy())
        self.beams.append(BeamEffect(points, WEAPONS["enzyme"]["color"], .22))
        self.cooldowns["enzyme"] = max(.30, (1.8 * (.90 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("laser")

    def fire_pulse(self) -> None:
        level = self.weapon_levels["pulse"]
        self.explode(self.player.pos, self.exp_stat(95, level, 1.10), self.damage_value(self.exp_stat(14, level, 1.48)), WEAPONS["pulse"]["color"], knockback=26)
        self.cooldowns["pulse"] = max(1.0, (5.4 * (.89 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("pulse")

    def fire_chain(self) -> None:
        level = self.weapon_levels["chain"]
        first = self.nearest_enemies(self.player.pos, 1)
        if not first:
            self.cooldowns["chain"] = .2
            return
        points = [self.player.pos.copy()]
        current = first[0]
        used: set[int] = set()
        jumps = 2 + level
        damage = self.damage_value(self.exp_stat(13, level, 1.43))
        for jump in range(jumps):
            if current is None:
                break
            dealt = self.damage_against(current, damage * (1 - jump * .06))
            current.take_damage(dealt, self, crit=random.random() < self.player.luck)
            self.on_damage_dealt(dealt, current)
            points.append(current.pos.copy())
            used.add(id(current))
            candidates = [e for e in self.enemies if not e.dead and id(e) not in used and e.pos.distance_to(current.pos) < self.exp_stat(190, level, 1.045)]
            current = min(candidates, key=lambda e: e.pos.distance_squared_to(points[-1]), default=None)
        self.beams.append(BeamEffect(points, WEAPONS["chain"]["color"], .26))
        self.cooldowns["chain"] = max(.48, (2.8 * (.90 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)
        self.play_sound("chain")

    def place_mine(self) -> None:
        level = self.weapon_levels["mine"]
        angle = random.random() * math.tau
        pos = self.player.pos + vec_from_angle(angle) * random.uniform(35, 75)
        pos.x = clamp(pos.x, 20, self.world_w - 20)
        pos.y = clamp(pos.y, 20, self.world_h - 20)
        self.mines.append(Mine(pos, self.damage_value(self.exp_stat(24, level, 1.50)), self.exp_stat(62, level, 1.09), self.exp_stat(42, level, 1.055)))
        self.cooldowns["mine"] = max(.85, (5.0 * (.89 ** (level - 1)) * self.cooldown_mul) / self.player.fire_rate_mul)

    def drone_positions(self) -> list[pygame.Vector2]:
        level = self.weapon_levels["drone"]
        count = 1 + (level - 1) // 2
        radius = self.exp_stat(62, level, 1.045)
        angle = self.elapsed * (1.8 + level * .06)
        return [self.player.pos + vec_from_angle(angle + i * math.tau / count) * radius for i in range(count)]

    def update_drones(self, dt: float) -> None:
        self.drone_tick -= dt
        if self.drone_tick > 0:
            return
        level = self.weapon_levels["drone"]
        damage = self.damage_value(self.exp_stat(7, level, 1.40))
        for pos in self.drone_positions():
            for enemy in self.enemies:
                if not enemy.dead and pos.distance_squared_to(enemy.pos) < (15 + enemy.radius) ** 2:
                    dealt = self.damage_against(enemy, damage)
                    enemy.take_damage(dealt, self, crit=random.random() < self.player.luck * .5)
                    self.on_damage_dealt(dealt, enemy)
                    direction = enemy.pos - pos
                    if direction.length_squared() > 0:
                        enemy.pos += direction.normalize() * 6
        self.drone_tick = max(.08, .32 * (.90 ** (level - 1)))

    def explode(self, pos: pygame.Vector2, radius: float, damage: float, color: tuple[int, int, int], knockback: float = 15) -> None:
        self.spawn_burst(pos, color, 28)
        self.beams.append(BeamEffect([pos + vec_from_angle(i * math.tau / 16) * radius for i in range(17)], color, .25))
        for enemy in self.enemies:
            if enemy.dead:
                continue
            dist = enemy.pos.distance_to(pos)
            if dist <= radius + enemy.radius:
                scale = 1 - min(.65, dist / max(1, radius) * .45)
                dealt = self.damage_against(enemy, damage * scale)
                enemy.take_damage(dealt, self, crit=random.random() < self.player.luck * .5)
                self.on_damage_dealt(dealt, enemy)
                delta = enemy.pos - pos
                if delta.length_squared() > 0:
                    enemy.pos += delta.normalize() * knockback

    def end_run(self, victory: bool) -> None:
        if self.game_over:
            return
        self.game_over = True
        self.victory = victory
        if any(isinstance(e, Boss) and getattr(e, "final_boss", False) and e.dead for e in self.enemies):
            self.final_boss_dead = True
        time_ratio = min(1.0, self.elapsed / self.chapter["duration"])
        objective_bonus = self.objective_cores_collected * 2 + self.beacons_activated * 4 + len(self.map_power_keys) * 2 + len(self.collected_relics)
        opened_chests = sum(1 for chest in self.world_chests if chest.opened)
        dna_reward = self.run_dna + objective_bonus + int(self.level * .55 + self.bosses_killed * 4 + time_ratio * 10)
        coin_reward = int(self.kills * .16 + self.level * 3 + opened_chests * 12 + (110 if victory else 0))
        if victory:
            dna_reward += self.chapter["reward"]
        dna_reward = int(dna_reward * self.reward_mul)
        coin_reward = int(coin_reward * self.reward_mul)
        save = self.app.save.data
        expansion = save.setdefault("expansion", {})
        unlocked = expansion.setdefault("unlocked_achievements", [])
        metrics = {
            "kills": self.kills, "dna": self.run_dna, "seconds": self.elapsed,
            "relics": len(self.collected_relics),
        }
        achievement_reward = 0
        for achievement_key, achievement in ACHIEVEMENTS.items():
            if achievement_key in unlocked:
                continue
            if metrics.get(str(achievement["metric"]), 0) >= float(achievement["threshold"]):
                unlocked.append(achievement_key)
                achievement_reward += int(achievement["reward_dna"])
        dna_reward += achievement_reward
        save["dna"] += dna_reward
        save["coins"] += coin_reward
        save["runs"] += 1
        save["wins"] += int(victory)
        save["total_kills"] += self.kills
        save["best_time"] = max(float(save["best_time"]), self.elapsed)
        save["highest_level"] = max(int(save["highest_level"]), self.level)
        if victory and self.chapter["id"] < len(CHAPTERS):
            save["unlocked_chapter"] = max(int(save["unlocked_chapter"]), self.chapter["id"] + 1)
        self.result_dna = dna_reward
        self.result_coins = coin_reward
        self.app.save.save()
        self.build_result_buttons()
        self.play_sound("victory" if victory else "defeat")

    def on_boss_removed(self, boss: Boss) -> None:
        if getattr(boss, "final_boss", False):
            self.final_boss_dead = True

    def draw(self, surface: pygame.Surface) -> None:
        shake = pygame.Vector2(0, 0)
        if self.camera_shake > 0 and self.app.save.data["settings"].get("screenshake", True):
            shake.xy = random.uniform(-self.camera_shake, self.camera_shake), random.uniform(-self.camera_shake, self.camera_shake)
        render_camera = self.camera - shake
        world = pygame.Surface((WIDTH, HEIGHT))
        self.draw_background(world, render_camera)
        states, beam_states = self.camera_transform_objects(render_camera)
        try:
            # Elementy mapy leżą pod przeciwnikami i efektami walki.
            self.portal.draw(world, self.app.fonts["small_bold"], self.app.fonts["tiny"], self.extraction_time)
            for beacon in self.beacons:
                beacon.draw(world, self.app.fonts["small_bold"], self.app.fonts["tiny"])
            for core in self.objective_cores:
                core.draw(world, self.app.fonts["tiny_bold"])
            for power in self.map_powers:
                power.draw(world, self.app.fonts["tiny_bold"], self.app.fonts["tiny"])
            for chest in self.world_chests:
                chest.draw(world, self.app.fonts["tiny_bold"])
            for relic in self.world_relics:
                relic.draw(world, self.app.fonts["tiny_bold"], self.app.fonts["tiny"])
            for anomaly in self.world_anomalies:
                anomaly.draw(world, self.app.fonts["tiny_bold"], self.app.fonts["tiny"])
            for pickup in self.pickups:
                pickup.draw(world)
            for mine in self.mines:
                mine.draw(world)
            for enemy in self.enemies:
                enemy.draw(world)
            for projectile in self.projectiles:
                projectile.draw(world)
            if self.weapon_levels["drone"] > 0:
                self.draw_drones(world)
            self.player.draw(world)
            for coop_player in getattr(self, "coop_players", []):
                coop_player.draw(world)
            for beam in self.beams:
                beam.draw(world)
            for particle in self.particles:
                particle.draw(world)
            for text in self.texts:
                text.draw(world, self.app.fonts["tiny"])
        finally:
            self.restore_camera_objects(states, beam_states)
        surface.fill(COLORS["black"])
        surface.blit(world, (0, 0))
        self.draw_directional_markers(surface, render_camera)
        self.draw_hud(surface)
        if self.paused:
            self.draw_pause(surface)
        if self.upgrade_open:
            self.draw_upgrade_overlay(surface)
        if self.game_over:
            self.draw_result(surface)

    def draw_background(self, surface: pygame.Surface, camera: pygame.Vector2) -> None:
        c1, c2 = self.chapter["colors"]
        for y in range(0, HEIGHT, 8):
            world_y = camera.y + y
            t = (world_y % self.world_h) / self.world_h
            color = tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3))
            pygame.draw.rect(surface, color, (0, y, WIDTH, 8))

        # Powtarzalna siatka tkanki daje wrażenie przesuwania się po dużej mapie.
        grid = 112
        start_x = -int(camera.x) % grid
        start_y = -int(camera.y) % grid
        for x in range(start_x - grid, WIDTH + grid, grid):
            pygame.draw.line(surface, (18, 35, 60), (x, 0), (x - 70, HEIGHT), 1)
        for y in range(start_y - grid, HEIGHT + grid, grid):
            pygame.draw.line(surface, (15, 29, 52), (0, y), (WIDTH, y + 42), 1)

        # Duże strefy biologiczne oraz drobne elementy są osadzone w świecie.
        zones = [
            (pygame.Vector2(self.world_w * .27, self.world_h * .32), 430, COLORS["purple"]),
            (pygame.Vector2(self.world_w * .70, self.world_h * .68), 520, COLORS["blue"]),
            (pygame.Vector2(self.world_w * .56, self.world_h * .22), 360, COLORS["pink"]),
        ]
        zone_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for pos, radius, color in zones:
            screen = pos - camera
            if -radius < screen.x < WIDTH + radius and -radius < screen.y < HEIGHT + radius:
                pygame.draw.circle(zone_layer, (*color, 16), screen, radius)
                pygame.draw.circle(zone_layer, (*color, 30), screen, radius, width=3)
        surface.blit(zone_layer, (0, 0))

        for x, y, radius, phase, drift in self._background_cells:
            if camera.x - 90 <= x <= camera.x + WIDTH + 90 and camera.y - 90 <= y <= camera.y + HEIGHT + 90:
                xx = x - camera.x + math.sin(self.elapsed * drift + phase) * 18
                yy = y - camera.y + math.cos(self.elapsed * drift + phase) * 10
                layer = pygame.Surface((radius * 4, radius * 4), pygame.SRCALPHA)
                pygame.draw.circle(layer, (90, 120, 170, 14), (radius * 2, radius * 2), radius)
                pygame.draw.circle(layer, (100, 170, 210, 22), (radius * 2, radius * 2), radius, width=2)
                surface.blit(layer, (xx - radius * 2, yy - radius * 2))
        for x, y, radius, color in self._world_specks:
            if camera.x <= x <= camera.x + WIDTH and camera.y <= y <= camera.y + HEIGHT:
                pygame.draw.circle(surface, color, (int(x - camera.x), int(y - camera.y)), radius)

        # Błona na obrzeżach mapy jest widoczna, ale mapa jest wielokrotnie
        # większa od ekranu i zachowuje się jak arena survivalowa.
        left = int(-camera.x)
        top = int(-camera.y)
        right = int(self.world_w - camera.x)
        bottom = int(self.world_h - camera.y)
        if -8 <= left <= WIDTH + 8:
            pygame.draw.line(surface, COLORS["cyan"], (left, max(0, top)), (left, min(HEIGHT, bottom)), 5)
        if -8 <= right <= WIDTH + 8:
            pygame.draw.line(surface, COLORS["cyan"], (right, max(0, top)), (right, min(HEIGHT, bottom)), 5)
        if -8 <= top <= HEIGHT + 8:
            pygame.draw.line(surface, COLORS["cyan"], (max(0, left), top), (min(WIDTH, right), top), 5)
        if -8 <= bottom <= HEIGHT + 8:
            pygame.draw.line(surface, COLORS["cyan"], (max(0, left), bottom), (min(WIDTH, right), bottom), 5)

    def draw_directional_markers(self, surface: pygame.Surface, camera: pygame.Vector2) -> None:
        center = pygame.Vector2(WIDTH / 2, HEIGHT / 2)
        safe_x = WIDTH / 2 - 58
        safe_y = HEIGHT / 2 - 112
        for target, color, label in self.active_objective_positions():
            screen = target - camera
            if 50 <= screen.x <= WIDTH - 50 and 105 <= screen.y <= HEIGHT - 45:
                continue
            direction = screen - center
            if direction.length_squared() < 1:
                continue
            factors = []
            if abs(direction.x) > .001:
                factors.append(safe_x / abs(direction.x))
            if abs(direction.y) > .001:
                factors.append(safe_y / abs(direction.y))
            scale = min(factors) if factors else 1.0
            edge = center + direction * scale
            angle = math.atan2(direction.y, direction.x)
            tip = edge + vec_from_angle(angle) * 12
            left = edge + vec_from_angle(angle + 2.5) * 12
            right = edge + vec_from_angle(angle - 2.5) * 12
            pygame.draw.polygon(surface, color, [tip, left, right])
            distance = int(self.player.pos.distance_to(target) / 10)
            draw_text(surface, self.app.fonts["tiny_bold"], f"{label} {distance}m", color, (int(edge.x), int(edge.y + 16)), "midtop")

    def draw_minimap(self, surface: pygame.Surface) -> None:
        rect = pygame.Rect(WIDTH - 224, 98, 206, 126)
        draw_panel(surface, rect, COLORS["panel"], COLORS["line"], 13, 220)
        inner = rect.inflate(-16, -24)
        pygame.draw.rect(surface, (6, 12, 25), inner, border_radius=7)

        def point(world: pygame.Vector2) -> tuple[int, int]:
            px = inner.x + int((world.x / self.world_w) * inner.width)
            py = inner.y + int((world.y / self.world_h) * inner.height)
            return px, py

        for core in self.objective_cores:
            if not core.collected:
                pygame.draw.circle(surface, COLORS["cyan"], point(core.pos), 3)
        for beacon in self.beacons:
            color = COLORS["green"] if beacon.activated else COLORS["purple"]
            pygame.draw.circle(surface, color, point(beacon.pos), 3)
        if self.portal.unlocked or self.objective_phase in ("portal", "boss"):
            pygame.draw.circle(surface, COLORS["red"] if not self.final_boss_dead else COLORS["green"], point(self.portal.pos), 4)
        for power in self.map_powers:
            if not power.collected:
                pygame.draw.circle(surface, MAP_POWERS[power.key]["color"], point(power.pos), 2)
        for relic in self.world_relics:
            if not relic.collected:
                pygame.draw.circle(surface, COLORS["yellow"], point(relic.pos), 2)
        for anomaly in self.world_anomalies:
            if not anomaly.activated:
                pygame.draw.circle(surface, COLORS["pink"], point(anomaly.pos), 2)
        pygame.draw.circle(surface, COLORS["white"], point(self.player.pos), 4)
        for coop_player in getattr(self, "coop_players", []):
            pygame.draw.circle(surface, COLORS["green"], point(coop_player.pos), 4)
        draw_text(surface, self.app.fonts["tiny_bold"], "MAPA", COLORS["muted"], (rect.x + 10, rect.y + 5))

    def draw_drones(self, surface: pygame.Surface) -> None:
        for pos in self.drone_positions():
            glow_circle(surface, pos, 10, WEAPONS["drone"]["color"], 3)
            pygame.draw.circle(surface, COLORS["white"], pos, 4)
            pygame.draw.line(surface, (*WEAPONS["drone"]["color"],), self.player.pos, pos, 1)

    def draw_hud(self, surface: pygame.Surface) -> None:
        top = pygame.Rect(18, 16, WIDTH - 36, 72)
        draw_panel(surface, top, COLORS["panel"], COLORS["line"], 16, 224)
        draw_text(surface, self.app.fonts["small_bold"], f"HP {int(self.player.hp)}/{int(self.player.max_hp)}", COLORS["text"], (38, 30))
        if getattr(self, "coop_players", []):
            partner = self.coop_players[0]
            draw_text(surface, self.app.fonts["tiny_bold"], f"PARTNER {int(partner.hp)}/{int(partner.max_hp)}", COLORS["green"], (340, 30))
        hp_rect = pygame.Rect(38, 57, 290, 14)
        hp_color = COLORS["green"] if self.player.hp / max(1, self.player.max_hp) > .35 else COLORS["red"]
        draw_progress(surface, hp_rect, self.player.hp, self.player.max_hp, hp_color)
        minutes = int(self.elapsed) // 60
        seconds = int(self.elapsed) % 60
        pressure = self.difficulty / max(.01, self.chapter["enemy_mul"])
        draw_text(surface, self.app.fonts["large"], f"{minutes:02d}:{seconds:02d}", COLORS["white"], (WIDTH // 2, 28), "midtop")
        draw_text(surface, self.app.fonts["tiny"], f"Fala {self.wave}  •  presja x{pressure:.2f}", COLORS["muted"], (WIDTH // 2, 65), "midbottom")
        draw_text(surface, self.app.fonts["small_bold"], f"Poziom {self.level}", COLORS["yellow"], (WIDTH - 302, 27))
        draw_text(surface, self.app.fonts["small"], f"Eliminacje: {self.kills}   DNA: {self.run_dna}", COLORS["muted"], (WIDTH - 302, 55))

        objective_color = COLORS["yellow"] if self.objective_flash > 0 else COLORS["cyan"]
        objective_rect = pygame.Rect(350, 98, 570, 52)
        draw_panel(surface, objective_rect, COLORS["panel"], objective_color, 13, 225)
        draw_text(surface, self.app.fonts["tiny_bold"], "CEL GŁÓWNY", objective_color, (objective_rect.x + 16, objective_rect.y + 8))
        draw_text(surface, self.app.fonts["small_bold"], self.objective_text(), COLORS["text"], (objective_rect.x + 16, objective_rect.y + 25))
        contract = CONTRACTS[self.contract_key]
        contract_rect = pygame.Rect(350, 156, 570, 48)
        contract_color = COLORS["green"] if self.contract_complete else COLORS["purple"]
        draw_panel(surface, contract_rect, COLORS["panel"], contract_color, 12, 218)
        status = "UKOŃCZONY" if self.contract_complete else f"{int(self.contract_progress)}/{int(contract['target'])}"
        draw_text(surface, self.app.fonts["tiny_bold"], f"KONTRAKT: {contract['name']}", contract_color, (contract_rect.x + 14, contract_rect.y + 7))
        draw_text(surface, self.app.fonts["tiny"], status, COLORS["text"], (contract_rect.right - 14, contract_rect.y + 15), "topright")
        self.draw_minimap(surface)

        xp_rect = pygame.Rect(20, HEIGHT - 18, WIDTH - 40, 8)
        draw_progress(surface, xp_rect, self.xp, self.xp_needed, COLORS["purple"])
        draw_text(surface, self.app.fonts["tiny"], f"XP {self.xp}/{self.xp_needed}", COLORS["text"], (WIDTH // 2, HEIGHT - 25), "midbottom")

        # Bronie i zdobyte moce mapy są widoczne po lewej stronie.
        y = 104
        for key, level in self.weapon_levels.items():
            if level <= 0:
                continue
            color = WEAPONS[key]["color"]
            rect = pygame.Rect(18, y, 154, 34)
            draw_panel(surface, rect, COLORS["panel"], color, 10, 190)
            draw_text(surface, self.app.fonts["tiny_bold"], WEAPONS[key]["icon"], color, (28, y + 9))
            draw_text(surface, self.app.fonts["tiny"], f"Lv.{level}", COLORS["text"], (145, y + 9), "topright")
            y += 39
        for key in sorted(self.map_power_keys):
            data = MAP_POWERS[key]
            rect = pygame.Rect(18, y, 154, 28)
            draw_panel(surface, rect, COLORS["panel"], data["color"], 8, 180)
            draw_text(surface, self.app.fonts["tiny_bold"], data["icon"], data["color"], (28, y + 7))
            draw_text(surface, self.app.fonts["tiny"], "MOC MAPY", COLORS["muted"], (145, y + 7), "topright")
            y += 32

        bosses = [e for e in self.enemies if isinstance(e, Boss) and not e.dead]
        if bosses:
            boss = bosses[0]
            rect = pygame.Rect(350, 158, 570, 48)
            draw_panel(surface, rect, (38, 12, 29), COLORS["red"], 13, 230)
            draw_text(surface, self.app.fonts["small_bold"], boss.name, COLORS["red"], (rect.centerx, rect.y + 5), "midtop")
            draw_progress(surface, pygame.Rect(rect.x + 22, rect.y + 31, rect.width - 44, 9), boss.hp, boss.max_hp, COLORS["red"])

    def upgrade_card_rects(self) -> list[pygame.Rect]:
        w, h, gap = 310, 350, 28
        total = w * 3 + gap * 2
        start = (WIDTH - total) // 2
        return [pygame.Rect(start + i * (w + gap), 210, w, h) for i in range(3)]

    def card_data(self, card: UpgradeCard) -> tuple[str, str, tuple[int, int, int], int, int]:
        if card.kind == "weapon":
            data = WEAPONS[card.key]
            old = self.weapon_levels[card.key]
            title = data["name"]
            desc = data["description"] if old == 0 else self.weapon_upgrade_description(card.key, old + 1)
            return title, desc, data["color"], old, data["max"]
        if card.kind == "passive":
            data = PASSIVES[card.key]
            old = self.passive_levels[card.key]
            return data["name"], data["description"], data["color"], old, data["max"]
        data = GENE_AUGMENTS[card.key]
        return data["name"], data["description"], data["color"], 0, 1

    def weapon_upgrade_description(self, key: str, next_level: int) -> str:
        descriptions = {
            "capsule": f"Wykładniczo rosną obrażenia i szybkość ostrzału; rośnie przebicie. Poziom {next_level}.",
            "needles": f"Wykładniczo rośnie siła serii oraz liczba igieł. Poziom {next_level}.",
            "bubble": f"Wykładniczo rośnie rozmiar i siła bańki oraz przebicie. Poziom {next_level}.",
            "enzyme": f"Wykładniczo silniejszy promień trafia dodatkowe cele. Poziom {next_level}.",
            "drone": f"Wykładniczo rosną obrażenia dronów i częstotliwość ataku. Poziom {next_level}.",
            "pulse": f"Wykładniczo rośnie zasięg, siła i częstotliwość fali. Poziom {next_level}.",
            "chain": f"Wykładniczo rosną obrażenia, zasięg i liczba przeskoków. Poziom {next_level}.",
            "mine": f"Wykładniczo rośnie siła i obszar min, a czas odnowienia maleje. Poziom {next_level}.",
        }
        return descriptions[key]

    def wrap_text(self, text: str, font: pygame.font.Font, max_width: int) -> list[str]:
        words = text.split()
        lines: list[str] = []
        current = ""
        for word in words:
            test = word if not current else f"{current} {word}"
            if font.size(test)[0] <= max_width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines

    def draw_upgrade_overlay(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 5, 15, 218))
        surface.blit(overlay, (0, 0))
        draw_text(surface, self.app.fonts["huge"], "ADAPTACJA KOMÓRKI", COLORS["white"], (WIDTH // 2, 72), "midtop")
        draw_text(surface, self.app.fonts["small"], "Wybierz jedną mutację  •  klawisze 1, 2 lub 3", COLORS["muted"], (WIDTH // 2, 132), "midtop")
        for index, (card, rect) in enumerate(zip(self.upgrade_cards, self.upgrade_card_rects())):
            title, desc, color, old, maximum = self.card_data(card)
            hovered = rect.collidepoint(self.app.mouse_pos())
            draw_panel(surface, rect, COLORS["panel2"] if hovered else COLORS["panel"], color, 22, 250)
            pygame.draw.circle(surface, color, (rect.centerx, rect.y + 78), 38)
            label = WEAPONS[card.key]["icon"] if card.kind == "weapon" else "GEN" if card.kind == "augment" else "DNA"
            draw_text(surface, self.app.fonts["small_bold"], label, COLORS["white"], (rect.centerx, rect.y + 78), "center")
            draw_text(surface, self.app.fonts["tiny_bold"], str(index + 1), COLORS["white"], (rect.x + 20, rect.y + 17))
            draw_text(surface, self.app.fonts["medium"], title, COLORS["text"], (rect.centerx, rect.y + 134), "midtop")
            subtitle = "NOWA BROŃ" if card.kind == "weapon" and old == 0 else "NOWY GEN" if card.kind == "augment" else f"POZIOM {old + 1}/{maximum}"
            draw_text(surface, self.app.fonts["tiny_bold"], subtitle, color, (rect.centerx, rect.y + 174), "midtop")
            y = rect.y + 216
            for line in self.wrap_text(desc, self.app.fonts["small"], rect.width - 42):
                draw_text(surface, self.app.fonts["small"], line, COLORS["muted"], (rect.centerx, y), "midtop")
                y += 25
            draw_progress(surface, pygame.Rect(rect.x + 28, rect.bottom - 38, rect.width - 56, 8), old + 1, maximum, color)

    def draw_pause(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        surface.blit(overlay, (0, 0))
        panel = pygame.Rect(440, 180, 400, 390)
        draw_panel(surface, panel, COLORS["panel"], COLORS["purple"], 24, 250)
        draw_text(surface, self.app.fonts["huge"], "PAUZA", COLORS["white"], (WIDTH // 2, 218), "midtop")
        draw_text(surface, self.app.fonts["small"], "ESC — powrót do walki", COLORS["muted"], (WIDTH // 2, 286), "midtop")
        for button in self.pause_buttons:
            button.draw(surface, self.app.fonts["small_bold"])

    def draw_result(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((1, 3, 10, 210))
        surface.blit(overlay, (0, 0))
        panel = pygame.Rect(310, 90, 660, 550)
        color = COLORS["green"] if self.victory else COLORS["red"]
        draw_panel(surface, panel, COLORS["panel"], color, 26, 250)
        title = "PROTOKÓŁ ZAKOŃCZONY" if self.victory else "KOMÓRKA ZNISZCZONA"
        draw_text(surface, self.app.fonts["huge"], title, color, (WIDTH // 2, 126), "midtop")
        draw_text(surface, self.app.fonts["medium"], self.chapter["name"], COLORS["text"], (WIDTH // 2, 198), "midtop")
        minutes = int(self.elapsed) // 60
        seconds = int(self.elapsed) % 60
        stats = [
            ("Czas przetrwania", f"{minutes:02d}:{seconds:02d}"),
            ("Poziom komórki", str(self.level)),
            ("Wyeliminowane zarazki", format_number(self.kills)),
            ("Cele mapy", f"{self.objective_cores_collected + self.beacons_activated}/5"),
            ("Zdobyte DNA", f"+{self.result_dna}"),
            ("Monety laboratorium", f"+{self.result_coins}"),
        ]
        for i, (label, value) in enumerate(stats):
            col = i % 2
            row = i // 2
            rect = pygame.Rect(350 + col * 295, 255 + row * 82, 275, 66)
            draw_panel(surface, rect, COLORS["panel2"], COLORS["line"], 13, 245)
            draw_text(surface, self.app.fonts["tiny"], label, COLORS["muted"], (rect.x + 14, rect.y + 10))
            draw_text(surface, self.app.fonts["medium"], value, COLORS["text"], (rect.x + 14, rect.y + 31))
        for button in self.result_buttons:
            button.draw(surface, self.app.fonts["small_bold"])

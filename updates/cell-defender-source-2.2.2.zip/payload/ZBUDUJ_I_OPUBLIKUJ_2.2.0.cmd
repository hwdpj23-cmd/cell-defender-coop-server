@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender 2.2.0 - Budowanie aktualizacji
color 0B

echo ============================================================
echo   CELL DEFENDER 2.2.0 - GLOBAL NETWORK UPDATE
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Najpierw uruchom START_GRY.cmd, aby zainstalowac biblioteki.
    pause
    exit /b 1
)

echo [1/3] Budowanie nowego EXE...
call "%~dp0ZBUDUJ_EXE.cmd"
if errorlevel 1 goto :fail

echo [2/3] Tworzenie pakietow SOURCE i WINDOWS...
".venv\Scripts\python.exe" "release_tools\build_update.py" --version "2.2.0" --notes "Globalny chat, calkowicie nowy wyglad menu, 3 nowe rozdzialy oraz wyzsze poziomy broni i mutacji."
if errorlevel 1 goto :fail

echo [3/3] Gotowe pliki do GitHuba.
echo Wgraj CALA zawartosc folderu DO_WGRANIA_NA_GITHUB.
start "" "%CD%\DO_WGRANIA_NA_GITHUB"
pause
exit /b 0

:fail
echo.
echo [BLAD] Budowanie aktualizacji nie powiodlo sie.
pause
exit /b 1

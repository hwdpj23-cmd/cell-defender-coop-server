from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .version import GAME_VERSION, UPDATE_API_PATH


class UpdateError(RuntimeError):
    pass


def _version_tuple(value: str) -> tuple[int, ...]:
    parts: list[int] = []
    for chunk in value.strip().split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def normalize_http_server(value: str) -> str:
    url = value.strip().rstrip("/")
    if url.startswith("wss://"):
        return "https://" + url[6:]
    if url.startswith("ws://"):
        return "http://" + url[5:]
    if not url.startswith(("http://", "https://")):
        return "https://" + url
    return url


@dataclass
class UpdatePackage:
    kind: str
    url: str
    sha256: str
    size: int


class UpdateManager:
    """Sprawdza, pobiera i bezpiecznie instaluje aktualizacje gry.

    Operacje sieciowe odbywają się w wątku roboczym, dzięki czemu Pygame nie
    przestaje odpowiadać. Instalacja następuje dopiero po zamknięciu gry.
    """

    def __init__(self, root: Path, server_url: str):
        self.root = root.resolve()
        self.server_url = normalize_http_server(server_url)
        self.current_version = GAME_VERSION
        self.latest_version = GAME_VERSION
        self.notes = ""
        self.mandatory = False
        self.manifest: dict[str, Any] = {}
        self.package: UpdatePackage | None = None
        self.status = "Gotowy"
        self.error = ""
        self.progress = 0.0
        self.downloaded_bytes = 0
        self.total_bytes = 0
        self.busy = False
        self.update_available = False
        self.downloaded_path: Path | None = None
        self.cancel_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.last_checked = 0.0
        self._lock = threading.Lock()

    @property
    def package_kind(self) -> str:
        return "windows" if getattr(sys, "frozen", False) else "source"

    def set_server_url(self, value: str) -> None:
        self.server_url = normalize_http_server(value)

    def _start(self, target: Any, *args: Any) -> bool:
        if self.busy:
            return False
        self.cancel_event.clear()
        self.error = ""
        self.busy = True
        self.thread = threading.Thread(target=self._run_guarded, args=(target, *args), daemon=True)
        self.thread.start()
        return True

    def _run_guarded(self, target: Any, *args: Any) -> None:
        try:
            target(*args)
        except Exception as exc:  # pragma: no cover - zależy od sieci/systemu
            with self._lock:
                self.error = str(exc)
                self.status = f"Błąd: {exc}"
        finally:
            self.busy = False

    def check_async(self, silent: bool = False) -> bool:
        return self._start(self._check, silent)

    def _check(self, silent: bool = False) -> None:
        if not silent:
            self.status = "Sprawdzanie aktualizacji..."
        api_url = urllib.parse.urljoin(self.server_url + "/", UPDATE_API_PATH.lstrip("/"))
        request = urllib.request.Request(
            api_url,
            headers={
                "User-Agent": f"CellDefender/{self.current_version}",
                "Accept": "application/json",
                "Cache-Control": "no-cache",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=18) as response:
                raw = response.read(1_000_000)
        except urllib.error.HTTPError as exc:
            raise UpdateError(f"Serwer aktualizacji zwrócił HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise UpdateError(f"Nie można połączyć z serwerem: {exc.reason}") from exc

        try:
            manifest = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise UpdateError("Serwer zwrócił nieprawidłowy manifest aktualizacji") from exc

        latest = str(manifest.get("version", self.current_version)).strip()
        packages = manifest.get("packages", {})
        if not isinstance(packages, dict):
            packages = {}
        kind = self.package_kind
        package_data = packages.get(kind)
        if not isinstance(package_data, dict):
            package_data = None

        package: UpdatePackage | None = None
        if package_data:
            relative_url = str(package_data.get("url", "")).strip()
            if relative_url:
                package = UpdatePackage(
                    kind=kind,
                    url=urllib.parse.urljoin(self.server_url + "/", relative_url),
                    sha256=str(package_data.get("sha256", "")).lower().strip(),
                    size=max(0, int(package_data.get("size", 0) or 0)),
                )

        with self._lock:
            self.manifest = manifest
            self.latest_version = latest
            self.notes = str(manifest.get("notes", "Brak opisu zmian."))
            self.mandatory = bool(manifest.get("mandatory", False))
            self.package = package
            self.update_available = _version_tuple(latest) > _version_tuple(self.current_version)
            self.last_checked = time.time()
            if self.update_available and package:
                self.status = f"Dostępna wersja {latest}"
            elif self.update_available:
                self.status = f"Wersja {latest} istnieje, ale brak pakietu {kind}."
            else:
                self.status = "Masz najnowszą wersję."

    def download_async(self) -> bool:
        if not self.package:
            self.error = "Najpierw sprawdź aktualizacje. Brak pakietu dla tej wersji gry."
            self.status = self.error
            return False
        return self._start(self._download, self.package)

    def cancel(self) -> None:
        self.cancel_event.set()
        if self.busy:
            self.status = "Anulowanie..."

    def _download(self, package: UpdatePackage) -> None:
        cache = self.root / "update_cache"
        cache.mkdir(parents=True, exist_ok=True)
        filename = Path(urllib.parse.urlparse(package.url).path).name or f"cell-defender-{self.latest_version}.zip"
        target = cache / filename
        temp = target.with_suffix(target.suffix + ".part")
        self.progress = 0.0
        self.downloaded_bytes = 0
        self.total_bytes = package.size
        self.status = "Pobieranie aktualizacji..."

        request = urllib.request.Request(
            package.url,
            headers={"User-Agent": f"CellDefender/{self.current_version}", "Accept": "application/zip"},
        )
        digest = hashlib.sha256()
        try:
            with urllib.request.urlopen(request, timeout=45) as response, temp.open("wb") as output:
                header_size = int(response.headers.get("Content-Length", "0") or 0)
                if header_size:
                    self.total_bytes = header_size
                if self.total_bytes > 2_000_000_000:
                    raise UpdateError("Pakiet aktualizacji jest zbyt duży")
                while True:
                    if self.cancel_event.is_set():
                        raise UpdateError("Pobieranie anulowane")
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    digest.update(chunk)
                    self.downloaded_bytes += len(chunk)
                    if self.total_bytes:
                        self.progress = min(1.0, self.downloaded_bytes / self.total_bytes)
        except Exception:
            temp.unlink(missing_ok=True)
            raise

        if package.size and self.downloaded_bytes != package.size:
            temp.unlink(missing_ok=True)
            raise UpdateError(
                f"Niepełny plik: pobrano {self.downloaded_bytes} B zamiast {package.size} B"
            )
        file_hash = digest.hexdigest().lower()
        if package.sha256 and file_hash != package.sha256:
            temp.unlink(missing_ok=True)
            raise UpdateError("Suma SHA-256 pakietu nie zgadza się. Instalacja została zatrzymana.")

        try:
            with zipfile.ZipFile(temp) as archive:
                names = archive.namelist()
                if not names or not any(name.startswith("payload/") for name in names):
                    raise UpdateError("Pakiet nie zawiera katalogu payload/")
                for info in archive.infolist():
                    normalized = Path(info.filename.replace("\\", "/"))
                    if normalized.is_absolute() or ".." in normalized.parts:
                        raise UpdateError("Pakiet zawiera niebezpieczną ścieżkę")
        except zipfile.BadZipFile as exc:
            temp.unlink(missing_ok=True)
            raise UpdateError("Pobrany pakiet ZIP jest uszkodzony") from exc

        temp.replace(target)
        self.downloaded_path = target
        self.progress = 1.0
        self.status = "Aktualizacja pobrana. Kliknij ZAINSTALUJ I URUCHOM."

    def install_and_restart(self) -> None:
        package = self.downloaded_path
        if not package or not package.exists():
            raise UpdateError("Najpierw pobierz aktualizację")
        if os.name != "nt":
            raise UpdateError("Automatyczny instalator jest przygotowany dla Windows")

        cache = self.root / "update_cache"
        cache.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup_dir = self.root / "backups" / f"przed-{self.latest_version}-{stamp}"
        staging_dir = cache / f"staging-{self.latest_version}"
        log_path = cache / "update_install.log"
        script_path = cache / "install_update.ps1"

        frozen = bool(getattr(sys, "frozen", False))
        restart_target = Path(sys.executable).resolve() if frozen else self.root / "START_GRY.cmd"
        restart_kind = "exe" if frozen else "cmd"

        def ps(value: Path | str) -> str:
            return str(value).replace("'", "''")

        script = f"""
$ErrorActionPreference = 'Stop'
$pidToWait = {os.getpid()}
$installDir = '{ps(self.root)}'
$package = '{ps(package)}'
$staging = '{ps(staging_dir)}'
$backup = '{ps(backup_dir)}'
$log = '{ps(log_path)}'
$restartTarget = '{ps(restart_target)}'
$restartKind = '{restart_kind}'

function Log([string]$message) {{
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $message"
    Add-Content -LiteralPath $log -Value $line -Encoding UTF8
}}

try {{
    Log 'Oczekiwanie na zamknięcie gry.'
    for ($i = 0; $i -lt 120; $i++) {{
        if (-not (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue)) {{ break }}
        Start-Sleep -Milliseconds 250
    }}
    if (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue) {{
        throw 'Gra nie zamknęła się w wymaganym czasie.'
    }}

    Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $staging -Force | Out-Null
    New-Item -ItemType Directory -Path $backup -Force | Out-Null

    Log 'Tworzenie kopii bezpieczeństwa.'
    $excludeDirs = @('data', '.venv', 'update_cache', 'backups', 'build', 'dist', '__pycache__')
    $xd = @()
    foreach ($name in $excludeDirs) {{ $xd += Join-Path $installDir $name }}
    & robocopy $installDir $backup /E /R:1 /W:1 /XD $xd /XF '*.pyc' | Out-Null
    if ($LASTEXITCODE -ge 8) {{ throw "Nie udało się utworzyć kopii zapasowej. Kod robocopy: $LASTEXITCODE" }}

    Log 'Rozpakowywanie aktualizacji.'
    Expand-Archive -LiteralPath $package -DestinationPath $staging -Force
    $payload = Join-Path $staging 'payload'
    if (-not (Test-Path -LiteralPath $payload)) {{ throw 'Brak katalogu payload w paczce.' }}

    Log 'Instalowanie nowych plików.'
    & robocopy $payload $installDir /E /R:2 /W:1 /XD 'data' '.venv' 'update_cache' 'backups' | Out-Null
    if ($LASTEXITCODE -ge 8) {{ throw "Nie udało się skopiować aktualizacji. Kod robocopy: $LASTEXITCODE" }}

    Log 'Aktualizacja zakończona.'
    Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
    if ($restartKind -eq 'exe') {{
        Start-Process -FilePath $restartTarget -WorkingDirectory $installDir
    }} else {{
        Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + $restartTarget + '"') -WorkingDirectory $installDir
    }}
}} catch {{
    Log ("BŁĄD: " + $_.Exception.Message)
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show("Aktualizacja nie powiodła się.`n`n$($_.Exception.Message)`n`nLog: $log", 'Cell Defender - aktualizacja') | Out-Null
    if (Test-Path -LiteralPath $restartTarget) {{
        if ($restartKind -eq 'exe') {{ Start-Process -FilePath $restartTarget -WorkingDirectory $installDir }}
        else {{ Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + $restartTarget + '"') -WorkingDirectory $installDir }}
    }}
}}
""".strip()
        script_path.write_text(script, encoding="utf-8-sig")

        creation_flags = 0
        if hasattr(subprocess, "CREATE_NEW_PROCESS_GROUP"):
            creation_flags |= subprocess.CREATE_NEW_PROCESS_GROUP
        if hasattr(subprocess, "DETACHED_PROCESS"):
            creation_flags |= subprocess.DETACHED_PROCESS
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
            ],
            cwd=str(self.root),
            creationflags=creation_flags,
            close_fds=True,
        )

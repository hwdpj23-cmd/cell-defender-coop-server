@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender - Publikowanie aktualizacji
color 0D

echo ============================================================
echo        KREATOR AKTUALIZACJI ONLINE CELL DEFENDER
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Najpierw uruchom START_GRY.cmd, aby utworzyc srodowisko.
    pause
    exit /b 1
)

set /p "VERSION=Podaj nowa wersje, np. 2.2.0: "
if not defined VERSION goto :fail
set /p "NOTES=Krotki opis zmian: "
if not defined NOTES set "NOTES=Nowa aktualizacja Cell Defender."

echo.
choice /C TN /M "Czy najpierw zbudowac nowy pakiet EXE dla graczy korzystajacych z EXE"
if errorlevel 2 goto :build
call "%~dp0ZBUDUJ_EXE.cmd"
if errorlevel 1 goto :fail

:build
".venv\Scripts\python.exe" "release_tools\build_update.py" --version "%VERSION%" --notes "%NOTES%"
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo GOTOWE. Wgraj CALA zawartosc folderu:
echo DO_WGRANIA_NA_GITHUB
echo do repozytorium cell-defender-coop-server na GitHubie.
echo Render sam uruchomi ponowne wdrozenie.
echo ============================================================
start "" "%CD%\DO_WGRANIA_NA_GITHUB"
pause
exit /b 0

:fail
echo.
echo [BLAD] Nie udalo sie przygotowac aktualizacji.
pause
exit /b 1

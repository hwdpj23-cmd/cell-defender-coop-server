from __future__ import annotations

from typing import Any

import pygame

from .data import COLORS, HEIGHT, WIDTH
from .ui import Button, draw_progress
from .utils import draw_panel, draw_text


class UpdateScene:
    def __init__(self, app: Any):
        self.app = app
        self.buttons: list[Button] = []
        self.rebuild_buttons()
        if not self.app.updater.busy and self.app.updater.last_checked == 0:
            self.app.updater.check_async()

    def rebuild_buttons(self) -> None:
        u = self.app.updater
        can_download = u.update_available and u.package is not None and not u.busy
        can_install = u.downloaded_path is not None and u.downloaded_path.exists() and not u.busy
        self.buttons = [
            Button(pygame.Rect(72, 646, 180, 46), "← MENU", self.app.show_menu, secondary=True),
            Button(pygame.Rect(276, 646, 230, 46), "SPRAWDŹ PONOWNIE", self.check, secondary=True, enabled=not u.busy),
            Button(pygame.Rect(530, 646, 300, 46), "POBIERZ AKTUALIZACJĘ", self.download, enabled=can_download),
            Button(pygame.Rect(854, 646, 354, 46), "ZAINSTALUJ I URUCHOM", self.install, accent=COLORS["green"], enabled=can_install),
        ]
        if u.busy:
            self.buttons[2] = Button(pygame.Rect(530, 646, 300, 46), "ANULUJ", u.cancel, secondary=True, accent=COLORS["red"])

    def check(self) -> None:
        self.app.updater.set_server_url(self.app.save.data["settings"].get("update_server_url", ""))
        self.app.updater.check_async()
        self.rebuild_buttons()

    def download(self) -> None:
        self.app.updater.download_async()
        self.rebuild_buttons()

    def install(self) -> None:
        try:
            self.app.save.save()
            self.app.updater.install_and_restart()
            self.app.running = False
        except Exception as exc:
            self.app.toast(str(exc), COLORS["red"])

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and not self.app.updater.busy:
            self.app.show_menu()
            return
        for button in self.buttons:
            if button.handle(event):
                self.app.audio.play("click")
                return

    def update(self, dt: float) -> None:
        del dt
        self.rebuild_buttons()

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        u = self.app.updater
        draw_text(surface, self.app.fonts["huge"], "AKTUALIZACJE ONLINE", COLORS["white"], (72, 48))
        draw_text(
            surface,
            self.app.fonts["small"],
            "Nowe wersje pobierają się z Twojego serwera. Zapis gry i ustawienia pozostają bez zmian.",
            COLORS["muted"],
            (74, 108),
        )

        current = pygame.Rect(72, 152, 344, 128)
        latest = pygame.Rect(438, 152, 344, 128)
        server = pygame.Rect(804, 152, 404, 128)
        for rect in (current, latest, server):
            draw_panel(surface, rect, COLORS["panel"], COLORS["line"], 18, 245)
        draw_text(surface, self.app.fonts["tiny_bold"], "TWOJA WERSJA", COLORS["muted"], (current.x + 22, current.y + 18))
        draw_text(surface, self.app.fonts["large"], u.current_version, COLORS["cyan"], (current.x + 22, current.y + 54))
        draw_text(surface, self.app.fonts["tiny_bold"], "WERSJA NA SERWERZE", COLORS["muted"], (latest.x + 22, latest.y + 18))
        latest_color = COLORS["green"] if not u.update_available else COLORS["yellow"]
        draw_text(surface, self.app.fonts["large"], u.latest_version, latest_color, (latest.x + 22, latest.y + 54))
        draw_text(surface, self.app.fonts["tiny_bold"], "SERWER AKTUALIZACJI", COLORS["muted"], (server.x + 22, server.y + 18))
        address = u.server_url
        for i, line in enumerate(self.app.wrap_text(address, self.app.fonts["small"], server.width - 44)):
            draw_text(surface, self.app.fonts["small"], line, COLORS["purple"], (server.x + 22, server.y + 54 + i * 24))

        status = pygame.Rect(72, 304, 1136, 82)
        status_color = COLORS["red"] if u.error else COLORS["yellow"] if u.update_available else COLORS["green"]
        draw_panel(surface, status, COLORS["panel2"], status_color, 16, 245)
        draw_text(surface, self.app.fonts["small_bold"], u.status, status_color, (status.x + 22, status.y + 18))
        if u.busy or u.progress > 0:
            bar = pygame.Rect(status.x + 22, status.y + 53, status.width - 44, 12)
            draw_progress(surface, bar, u.progress, 1.0, COLORS["purple"])
            if u.total_bytes:
                mb_done = u.downloaded_bytes / 1024 / 1024
                mb_total = u.total_bytes / 1024 / 1024
                draw_text(surface, self.app.fonts["tiny"], f"{mb_done:.1f} / {mb_total:.1f} MB", COLORS["muted"], (bar.right, bar.y - 21), "topright")

        notes = pygame.Rect(72, 410, 1136, 208)
        draw_panel(surface, notes, COLORS["panel"], COLORS["line"], 18, 245)
        draw_text(surface, self.app.fonts["medium"], "CO NOWEGO", COLORS["text"], (notes.x + 22, notes.y + 18))
        note_text = u.notes or "Kliknij SPRAWDŹ PONOWNIE, aby pobrać informacje o najnowszej wersji."
        y = notes.y + 62
        for line in self.app.wrap_text(note_text, self.app.fonts["small"], notes.width - 44)[:6]:
            draw_text(surface, self.app.fonts["small"], line, COLORS["muted"], (notes.x + 22, y))
            y += 28
        if u.mandatory:
            draw_text(surface, self.app.fonts["tiny_bold"], "AKTUALIZACJA WYMAGANA", COLORS["red"], (notes.right - 22, notes.y + 22), "topright")
        elif u.update_available:
            draw_text(surface, self.app.fonts["tiny_bold"], "NOWA WERSJA DOSTĘPNA", COLORS["yellow"], (notes.right - 22, notes.y + 22), "topright")
        else:
            draw_text(surface, self.app.fonts["tiny_bold"], "GRA AKTUALNA", COLORS["green"], (notes.right - 22, notes.y + 22), "topright")

        for button in self.buttons:
            font = self.app.fonts["tiny_bold"] if button.small else self.app.fonts["small_bold"]
            button.draw(surface, font)

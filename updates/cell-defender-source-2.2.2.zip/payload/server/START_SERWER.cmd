@echo off
setlocal
call "%~dp0..\URUCHOM_SERWER_LOKALNY.cmd"
exit /b %ERRORLEVEL%

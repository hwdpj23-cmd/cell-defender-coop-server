@echo off
setlocal
cd /d "%~dp0"
title Cell Defender 2.1 - Testy
set "PYTHON_CMD="
if exist ".venv\Scripts\python.exe" set "PYTHON_CMD=.venv\Scripts\python.exe"
if not defined PYTHON_CMD where py >nul 2>nul && set "PYTHON_CMD=py"
if not defined PYTHON_CMD where python >nul 2>nul && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    echo Brak Pythona.
    pause
    exit /b 1
)
%PYTHON_CMD% -m compileall -q main.py game server release_tools
if errorlevel 1 goto :fail
%PYTHON_CMD% TEST_LOGIKI.py
if errorlevel 1 goto :fail
%PYTHON_CMD% TEST_AKTUALIZACJI.py
if errorlevel 1 goto :fail
%PYTHON_CMD% -c "import pygame, websockets, aiohttp; print('[OK] pygame, websockets i aiohttp sa zainstalowane.')"
if errorlevel 1 (
    echo [UWAGA] Brakuje bibliotek. Uruchom START_GRY.cmd i ponow test.
    goto :fail
)
%PYTHON_CMD% TEST_SIECI.py
if errorlevel 1 goto :fail
echo.
echo [OK] Wszystkie testy przeszly pomyslnie.
pause
exit /b 0
:fail
echo.
echo [BLAD] Test nie przeszedl.
pause
exit /b 1

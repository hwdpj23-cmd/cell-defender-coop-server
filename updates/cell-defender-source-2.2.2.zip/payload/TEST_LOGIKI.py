from __future__ import annotations

import json
from pathlib import Path

from game.content_expansion import (
    ACHIEVEMENTS, ANOMALIES, BIOMES, BOSS_MUTATIONS, CELL_CLASSES, CHALLENGES,
    CONTRACTS, GENE_AUGMENTS, RELICS, SYNERGIES, content_counts,
)
from game.data import MAP_POWERS, OBJECTIVE_RULES, WORLD_HEIGHT, WORLD_WIDTH


def xp_for_level(level: int) -> int:
    return max(28, int(28 * (1.17 ** max(0, level - 1)) + level * 4))


def main() -> None:
    assert WORLD_WIDTH >= 6000 and WORLD_HEIGHT >= 3600
    assert len(MAP_POWERS) >= 6
    assert OBJECTIVE_RULES["cores_required"] == 2
    assert OBJECTIVE_RULES["beacons_required"] == 3
    costs = [xp_for_level(level) for level in range(1, 31)]
    assert all(b > a for a, b in zip(costs, costs[1:]))
    assert costs[20] > costs[10] * 3
    weapon_growth = [10 * (1.42 ** (level - 1)) for level in range(1, 7)]
    assert weapon_growth[-1] > weapon_growth[0] * 5

    counts = content_counts()
    assert counts["total"] >= 400, counts
    assert len(GENE_AUGMENTS) == 120
    assert len(RELICS) == 80
    assert len(SYNERGIES) == 48
    assert len(CONTRACTS) == 40
    assert len(ANOMALIES) == 32
    assert len(CELL_CLASSES) == 24
    assert len(CHALLENGES) == 24
    assert len(BIOMES) == 16
    assert len(BOSS_MUTATIONS) == 16
    assert len(ACHIEVEMENTS) == 32

    manifest = json.loads(Path("CONTENT_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["counts"]["total"] == counts["total"]
    print(f"[OK] Mapa, balans i {counts['total']} elementy rozszerzenia przeszły testy.")


if __name__ == "__main__":
    main()

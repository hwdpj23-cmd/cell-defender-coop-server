from __future__ import annotations

from .version import DEFAULT_HTTP_SERVER, DEFAULT_WS_SERVER, GAME_VERSION

WIDTH = 1280
HEIGHT = 720
FPS = 60
WORLD_WIDTH = 6400
WORLD_HEIGHT = 4000
CAMERA_MARGIN = 130

TITLE = f"Cell Defender: Immunity Protocol {GAME_VERSION} — CO-OP & Auto Update"
SAVE_VERSION = 3

COLORS = {
    "bg": (4, 8, 20),
    "panel": (12, 20, 38),
    "panel2": (18, 30, 52),
    "line": (47, 78, 116),
    "text": (239, 248, 255),
    "muted": (137, 161, 194),
    "cyan": (57, 225, 255),
    "blue": (65, 126, 255),
    "purple": (164, 92, 255),
    "pink": (255, 76, 182),
    "green": (65, 238, 158),
    "yellow": (255, 218, 91),
    "orange": (255, 145, 67),
    "red": (255, 76, 105),
    "teal": (34, 205, 190),
    "navy": (9, 16, 33),
    "white": (255, 255, 255),
    "black": (0, 0, 0),
}

CHAPTERS = [
    {
        "id": 1,
        "name": "Krwiobieg",
        "subtitle": "Pierwszy kontakt",
        "duration": 300,
        "enemy_mul": 1.0,
        "reward": 20,
        "accent": (57, 225, 255),
        "colors": ((5, 17, 35), (26, 8, 47)),
        "description": "Uruchom obronę krwiobiegu i zamknij pierwszy portal infekcji.",
    },
    {
        "id": 2,
        "name": "Węzeł limfatyczny",
        "subtitle": "Fala mutacji",
        "duration": 360,
        "enemy_mul": 1.35,
        "reward": 38,
        "accent": (65, 238, 158),
        "colors": ((4, 28, 31), (20, 8, 45)),
        "description": "Broń węzłów odporności przed gwałtowną falą mutantów.",
    },
    {
        "id": 3,
        "name": "Rdzeń infekcji",
        "subtitle": "Protokół Omega",
        "duration": 420,
        "enemy_mul": 1.8,
        "reward": 65,
        "accent": (255, 76, 105),
        "colors": ((32, 6, 20), (6, 14, 36)),
        "description": "Przebij się do rdzenia i pokonaj wielofazowego mutanta Omega.",
    },
    {
        "id": 4,
        "name": "Płuco skażenia",
        "subtitle": "Toksyczny oddech",
        "duration": 480,
        "enemy_mul": 2.35,
        "reward": 100,
        "accent": (255, 145, 67),
        "colors": ((34, 18, 4), (20, 7, 31)),
        "description": "Przemierzaj toksyczne komory i niszcz źródła zarodników.",
    },
    {
        "id": 5,
        "name": "Synapsa burzy",
        "subtitle": "Impuls chaosu",
        "duration": 540,
        "enemy_mul": 3.0,
        "reward": 150,
        "accent": (164, 92, 255),
        "colors": ((12, 8, 42), (4, 27, 42)),
        "description": "Walcz w niestabilnej sieci neuronowej pełnej anomalii i elit.",
    },
    {
        "id": 6,
        "name": "Serce patogenu",
        "subtitle": "Ostatni protokół",
        "duration": 600,
        "enemy_mul": 3.9,
        "reward": 240,
        "accent": (255, 218, 91),
        "colors": ((38, 7, 16), (19, 4, 35)),
        "description": "Najdłuższa ekspedycja: przełam obronę serca i zakończ epidemię.",
    },
]

LAB_UPGRADES = {
    "max_hp": {
        "name": "Wzmocniona błona",
        "description": "Każdy poziom mnoży maksymalne zdrowie przez 1,055.",
        "base_cost": 12,
        "max": 20,
    },
    "damage": {
        "name": "Agresywne przeciwciała",
        "description": "Każdy poziom mnoży obrażenia przez 1,055.",
        "base_cost": 16,
        "max": 20,
    },
    "fire_rate": {
        "name": "Szybka synteza",
        "description": "Każdy poziom mnoży szybkość ataku przez 1,045.",
        "base_cost": 18,
        "max": 18,
    },
    "move_speed": {
        "name": "Elastyczna cytoplazma",
        "description": "Każdy poziom mnoży szybkość ruchu przez 1,025.",
        "base_cost": 10,
        "max": 15,
    },
    "magnet": {
        "name": "Pole chemotaksji",
        "description": "Każdy poziom mnoży zasięg zbierania przez 1,08.",
        "base_cost": 9,
        "max": 20,
    },
    "armor": {
        "name": "Warstwa ochronna",
        "description": "Geometrycznie wzmacnia pancerz, maksymalnie do 42%.",
        "base_cost": 22,
        "max": 15,
    },
    "regen": {
        "name": "Regeneracja błony",
        "description": "Regeneracja rośnie wykładniczo z każdym poziomem.",
        "base_cost": 25,
        "max": 15,
    },
    "luck": {
        "name": "Mutacja adaptacyjna",
        "description": "Szczęście rośnie geometrycznie, z bezpiecznym limitem.",
        "base_cost": 20,
        "max": 15,
    },
}

WEAPONS = {
    "capsule": {
        "name": "Kapsuła antywirusowa",
        "icon": "CAP",
        "color": (67, 226, 255),
        "max": 8,
        "description": "Automatycznie ostrzeliwuje najbliższy cel.",
    },
    "needles": {
        "name": "Igły przeciwciał",
        "icon": "IGŁ",
        "color": (255, 214, 91),
        "max": 8,
        "description": "Wystrzeliwuje serię igieł we wszystkich kierunkach.",
    },
    "bubble": {
        "name": "Bańka dezynfekująca",
        "icon": "BAŃ",
        "color": (174, 85, 255),
        "max": 8,
        "description": "Duża bańka odbija się i przebija wielu przeciwników.",
    },
    "enzyme": {
        "name": "Promień enzymatyczny",
        "icon": "ENZ",
        "color": (79, 235, 143),
        "max": 8,
        "description": "Błyskawiczny promień uszkadza najbliższe zarazki.",
    },
    "drone": {
        "name": "Leukocyt-dron",
        "icon": "DRO",
        "color": (255, 80, 190),
        "max": 8,
        "description": "Krąży wokół komórki i niszczy wszystko na swojej drodze.",
    },
    "pulse": {
        "name": "Impuls odporności",
        "icon": "IMP",
        "color": (67, 123, 255),
        "max": 8,
        "description": "Okresowo uwalnia falę uderzeniową wokół komórki.",
    },
    "chain": {
        "name": "Łańcuch jonowy",
        "icon": "JON",
        "color": (126, 255, 245),
        "max": 8,
        "description": "Wyładowanie przeskakuje między kilkoma celami.",
    },
    "mine": {
        "name": "Szczepionkowa mina",
        "icon": "MIN",
        "color": (255, 142, 66),
        "max": 8,
        "description": "Rozstawia ładunki eksplodujące pod nadchodzącymi wrogami.",
    },
}

PASSIVES = {
    "power": {
        "name": "Białko bojowe",
        "description": "Mnoży obecne obrażenia przez 1,18.",
        "max": 7,
        "color": (255, 82, 103),
    },
    "haste": {
        "name": "Przyspieszony metabolizm",
        "description": "Mnoży obecną szybkość ataku przez 1,15.",
        "max": 7,
        "color": (255, 214, 91),
    },
    "vitality": {
        "name": "Podwójna błona",
        "description": "Mnoży maksymalne HP przez 1,20 i leczy różnicę.",
        "max": 7,
        "color": (79, 235, 143),
    },
    "speed": {
        "name": "Rzęski napędowe",
        "description": "Mnoży obecną szybkość ruchu przez 1,11.",
        "max": 7,
        "color": (67, 226, 255),
    },
    "magnet": {
        "name": "Receptor magnetyczny",
        "description": "Mnoży zasięg zbierania przez 1,18.",
        "max": 7,
        "color": (174, 85, 255),
    },
    "armor": {
        "name": "Pancerz lipidowy",
        "description": "Zmniejsza pozostałe obrażenia o kolejne 8%.",
        "max": 7,
        "color": (67, 123, 255),
    },
    "regen": {
        "name": "Autofagia naprawcza",
        "description": "Mnoży regenerację przez 1,35 i dodaje 0,25 HP/s.",
        "max": 7,
        "color": (255, 80, 190),
    },
    "luck": {
        "name": "Losowa mutacja",
        "description": "Geometrycznie zwiększa szczęście, maksymalnie do 65%.",
        "max": 7,
        "color": (255, 142, 66),
    },
}

MAP_POWERS = {
    "mitochondrium": {
        "name": "Serce Mitochondrium",
        "description": "+35% szybkości ataku i +10% ruchu.",
        "color": (255, 214, 91),
        "icon": "MIT",
    },
    "ribosome": {
        "name": "Matryca Rybosomu",
        "description": "+45% obrażeń wszystkich broni.",
        "color": (255, 82, 103),
        "icon": "RYB",
    },
    "membrane": {
        "name": "Pancerz Błonowy",
        "description": "+30% maksymalnego HP i natychmiastowe leczenie.",
        "color": (67, 123, 255),
        "icon": "BŁO",
    },
    "cilia": {
        "name": "Napęd Rzęskowy",
        "description": "+25% prędkości ruchu i +20% zasięgu zbierania.",
        "color": (67, 226, 255),
        "icon": "RZĘ",
    },
    "lysosome": {
        "name": "Rdzeń Lizosomalny",
        "description": "Okresowe wyładowanie i +1.1 HP regeneracji/s.",
        "color": (174, 85, 255),
        "icon": "LIZ",
    },
    "nucleus": {
        "name": "Fragment Jądra",
        "description": "+20% szczęścia, krytyków i jakości nagród.",
        "color": (255, 80, 190),
        "icon": "JĄD",
    },
}

OBJECTIVE_RULES = {
    "cores_required": 2,
    "beacons_required": 3,
    "beacon_charge_time": 5.0,
    "extraction_time": 4.0,
}

ENEMY_TYPES = {
    "virus": {"hp": 18, "speed": 72, "damage": 8, "radius": 16, "xp": 5, "color": (255, 82, 103)},
    "bacteria": {"hp": 11, "speed": 118, "damage": 6, "radius": 12, "xp": 4, "color": (255, 142, 66)},
    "spore": {"hp": 55, "speed": 48, "damage": 14, "radius": 23, "xp": 11, "color": (174, 85, 255)},
    "parasite": {"hp": 34, "speed": 62, "damage": 9, "radius": 18, "xp": 8, "color": (79, 235, 143)},
    "splitter": {"hp": 32, "speed": 76, "damage": 8, "radius": 19, "xp": 8, "color": (67, 123, 255)},
    "elite": {"hp": 120, "speed": 65, "damage": 18, "radius": 27, "xp": 25, "color": (255, 214, 91)},
}

BOSS_NAMES = [
    "Koronawirus Alfa",
    "Bakteriofag Niszczyciel",
    "Pasożyt Helix",
    "Mutant Omega",
    "Nekroza Prime",
    "Zarodnik Leviathan",
    "Synapsa Widmo",
    "Patogen Apex",
]

DEFAULT_SAVE = {
    "version": SAVE_VERSION,
    "dna": 0,
    "coins": 0,
    "unlocked_chapter": 1,
    "best_time": 0.0,
    "highest_level": 1,
    "total_kills": 0,
    "runs": 0,
    "wins": 0,
    "lab": {key: 0 for key in LAB_UPGRADES},
    "settings": {
        "music": 0.35,
        "sfx": 0.55,
        "fullscreen": False,
        "particles": 2,
        "screenshake": True,
        "show_damage": True,
        "nickname": "Komórka",
        "server_url": DEFAULT_WS_SERVER,
        "update_server_url": DEFAULT_HTTP_SERVER,
        "auto_check_updates": True,
        "selected_class": "class_01",
        "selected_challenge": "none",
    },
    "expansion": {
        "discovered_relics": [],
        "unlocked_achievements": [],
        "completed_contracts": 0,
        "online_runs": 0,
        "online_wins": 0,
    },
}

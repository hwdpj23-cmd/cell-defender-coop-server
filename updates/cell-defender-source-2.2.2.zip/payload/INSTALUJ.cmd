@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender - Instalacja
color 0A

echo ============================================================
echo             CELL DEFENDER 2.0 - INSTALACJA
echo ============================================================
echo.
set "PYTHON_CMD="
where py >nul 2>nul && set "PYTHON_CMD=py"
if not defined PYTHON_CMD where python >nul 2>nul && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    echo [BLAD] Nie znaleziono Pythona 3.11 lub nowszego.
    echo Zainstaluj go z https://www.python.org/downloads/windows/
    goto :fail
)

%PYTHON_CMD% -m venv .venv
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :fail
.venv\Scripts\python.exe -c "import pygame, websockets; print('Pygame:', pygame.version.ver, 'WebSockets:', websockets.__version__)"
if errorlevel 1 goto :fail

echo.
echo [OK] Gra jest gotowa. Uruchom START_GRY.cmd
pause
exit /b 0

:fail
echo.
echo [BLAD] Instalacja nie powiodla sie.
pause
exit /b 1

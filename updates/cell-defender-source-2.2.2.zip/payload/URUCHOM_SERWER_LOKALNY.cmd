@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Cell Defender 2.1 - Serwer CO-OP i aktualizacji
color 0B
set "PYTHONUTF8=1"
set "LOG=%CD%\server_start_log.txt"

>"%LOG%" echo Cell Defender 2.1 - log serwera %DATE% %TIME%

echo ============================================================
echo    CELL DEFENDER 2.1 - SERWER CO-OP + AKTUALIZACJE
echo ============================================================
echo.

if not exist "server\relay_server.py" (
    echo [BLAD] Brak server\relay_server.py. Wypakuj cala paczke.
    goto :fail
)

set "VPY=%CD%\.venv\Scripts\python.exe"
if not exist "%VPY%" (
    set "PYTHON_CMD="
    where py >nul 2>nul && set "PYTHON_CMD=py"
    if not defined PYTHON_CMD where python >nul 2>nul && set "PYTHON_CMD=python"
    if not defined PYTHON_CMD (
        echo [BLAD] Nie znaleziono Pythona.
        goto :fail
    )
    echo [1/3] Tworzenie .venv...
    !PYTHON_CMD! -m venv ".venv" >>"%LOG%" 2>&1
    if errorlevel 1 goto :fail
)

echo [2/3] Sprawdzanie aiohttp...
"%VPY%" -c "import aiohttp" >nul 2>nul
if errorlevel 1 (
    echo Instalowanie biblioteki serwera...
    "%VPY%" -m pip install --upgrade pip >>"%LOG%" 2>&1
    "%VPY%" -m pip install -r "server\requirements.txt" >>"%LOG%" 2>&1
    if errorlevel 1 goto :fail
)

netstat -ano | findstr ":8765" | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
    echo [BLAD] Port 8765 jest juz zajety. Zamknij poprzednie okno serwera.
    goto :fail
)

echo [3/3] Start serwera...
echo.
echo CO-OP lokalnie: ws://127.0.0.1:8765
echo Panel statusu: http://127.0.0.1:8765
echo Aktualizacje: http://127.0.0.1:8765/api/update
echo.
echo NIE ZAMYKAJ TEGO OKNA PODCZAS GRY LOKALNEJ.
echo ============================================================
"%VPY%" -u "server\relay_server.py" --host 0.0.0.0 --port 8765
set "EXITCODE=%ERRORLEVEL%"
echo.
echo Serwer zakonczyl dzialanie z kodem %EXITCODE%.
pause
exit /b %EXITCODE%

:fail
echo.
echo Nie udalo sie uruchomic serwera. Szczegoly: server_start_log.txt
pause
exit /b 1

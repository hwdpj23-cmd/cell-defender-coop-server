from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any

import pygame

from .content_expansion import CONTRACTS
from .data import CHAPTERS, COLORS, HEIGHT, MAP_POWERS, WIDTH
from .entities import Player, Projectile
from .gameplay import GameplayScene
from .network import NetworkClient
from .ui import Button, draw_progress
from .utils import clamp, draw_panel, draw_text, glow_circle
from .version import DEFAULT_WS_SERVER


def normalize_ws_url(value: str) -> str:
    url = value.strip().rstrip("/")
    if not url:
        return DEFAULT_WS_SERVER
    if url.startswith("https://"):
        url = "wss://" + url[8:]
    elif url.startswith("http://"):
        url = "ws://" + url[7:]
    elif not url.startswith(("ws://", "wss://")):
        url = "wss://" + url
    if "onrender.com" in url and url.startswith("ws://"):
        url = "wss://" + url[5:]
    return url


def _clipboard_get() -> str:
    try:
        if not pygame.scrap.get_init():
            pygame.scrap.init()
        raw = pygame.scrap.get(pygame.SCRAP_TEXT)
        if raw:
            return raw.decode("utf-8", errors="ignore").replace("\x00", "").strip()
    except pygame.error:
        pass
    return ""


def _clipboard_set(value: str) -> bool:
    try:
        if not pygame.scrap.get_init():
            pygame.scrap.init()
        pygame.scrap.put(pygame.SCRAP_TEXT, value.encode("utf-8") + b"\x00")
        return True
    except pygame.error:
        return False


@dataclass
class TextField:
    rect: pygame.Rect
    value: str
    placeholder: str
    max_length: int = 80
    active: bool = False
    password: bool = False
    select_all: bool = False

    def _insert(self, text: str) -> None:
        clean = text.replace("\n", "").replace("\r", "")
        if self.select_all:
            self.value = ""
            self.select_all = False
        if clean and len(self.value) < self.max_length:
            self.value += clean[: self.max_length - len(self.value)]

    def paste(self) -> bool:
        text = _clipboard_get()
        if not text:
            return False
        self._insert(text)
        return True

    def handle(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                self.active = self.rect.collidepoint(event.pos)
                self.select_all = False
                if self.active:
                    pygame.key.start_text_input()
                return self.active
            if event.button == 3 and self.rect.collidepoint(event.pos):
                self.active = True
                pygame.key.start_text_input()
                self.paste()
                return True
        if not self.active:
            return False
        if event.type == pygame.KEYDOWN:
            ctrl = bool(event.mod & pygame.KMOD_CTRL)
            if ctrl and event.key == pygame.K_a:
                self.select_all = True
                return True
            if ctrl and event.key == pygame.K_c:
                _clipboard_set(self.value)
                return True
            if ctrl and event.key == pygame.K_v:
                self.paste()
                return True
            if event.key == pygame.K_BACKSPACE:
                if self.select_all:
                    self.value = ""
                    self.select_all = False
                else:
                    self.value = self.value[:-1]
                return True
            if event.key in (pygame.K_RETURN, pygame.K_TAB, pygame.K_ESCAPE):
                self.active = False
                self.select_all = False
                pygame.key.stop_text_input()
                return True
        if event.type == pygame.TEXTINPUT:
            self._insert(event.text)
            return True
        return False

    def draw(self, surface: pygame.Surface, font: pygame.font.Font, label_font: pygame.font.Font, label: str) -> None:
        draw_text(surface, label_font, label, COLORS["muted"], (self.rect.x, self.rect.y - 24))
        border = COLORS["cyan"] if self.active else COLORS["line"]
        draw_panel(surface, self.rect, COLORS["panel2"], border, 11, 245)
        text = ("•" * len(self.value)) if self.password else self.value
        color = COLORS["text"] if text else COLORS["muted"]
        if self.select_all and text:
            highlight = pygame.Rect(self.rect.x + 8, self.rect.y + 7, min(self.rect.width - 16, font.size(text)[0] + 10), self.rect.height - 14)
            pygame.draw.rect(surface, (*COLORS["purple"],), highlight, border_radius=6)
        draw_text(surface, font, text or self.placeholder, color, (self.rect.x + 12, self.rect.centery), "midleft")
        if self.active and not self.select_all and int(time.monotonic() * 2) % 2 == 0:
            width = min(self.rect.width - 28, font.size(text)[0])
            pygame.draw.line(surface, COLORS["cyan"], (self.rect.x + 13 + width, self.rect.y + 11), (self.rect.x + 13 + width, self.rect.bottom - 11), 2)


class MultiplayerScene:
    MAX_CONNECT_ATTEMPTS = 5

    def __init__(self, app: Any):
        self.app = app
        settings = app.save.data["settings"]
        saved_url = normalize_ws_url(str(settings.get("server_url", DEFAULT_WS_SERVER)))
        self.server = TextField(pygame.Rect(396, 560, 500, 46), saved_url, DEFAULT_WS_SERVER, 160)
        self.nickname = TextField(pygame.Rect(390, 202, 500, 48), str(settings.get("nickname", "Komórka")), "Twój nick", 24)
        self.room_input = TextField(pygame.Rect(390, 296, 282, 50), "", "NP. AB12CD", 6)
        self.network: NetworkClient | None = None
        self.room = ""
        self.role = ""
        self.peer_name = ""
        self.status = "Serwer online jest już ustawiony. Utwórz pokój albo wklej kod znajomego."
        self.state = "idle"
        self.pending_action = ""
        self.chapter_id = 1
        self.advanced = False
        self.buttons: list[Button] = []
        self.ping_timer = 0.0
        self.retry_timer = 0.0
        self.connect_attempts = 0
        self.manual_close = False
        self.rebuild_buttons()

    @property
    def fields(self) -> list[TextField]:
        result = [self.nickname, self.room_input]
        if self.advanced:
            result.append(self.server)
        return result

    def rebuild_buttons(self) -> None:
        buttons: list[Button] = [Button(pygame.Rect(72, 650, 176, 44), "← MENU", self.back, secondary=True)]
        if not self.room:
            buttons.extend([
                Button(pygame.Rect(390, 374, 500, 56), "UTWÓRZ POKÓJ — 1 KLIK", self.create_room),
                Button(pygame.Rect(690, 296, 200, 50), "WKLEJ KOD", self.paste_room_code, secondary=True),
                Button(pygame.Rect(390, 446, 500, 54), "DOŁĄCZ KODEM", self.join_room, secondary=True),
                Button(pygame.Rect(1014, 650, 194, 44), "USTAWIENIA SERWERA", self.toggle_advanced, secondary=True, small=True),
            ])
            if self.advanced:
                buttons.extend([
                    Button(pygame.Rect(914, 560, 132, 46), "WKLEJ", self.paste_server, secondary=True, small=True),
                    Button(pygame.Rect(1058, 560, 150, 46), "DOMYŚLNY", self.reset_server, secondary=True, small=True),
                ])
        else:
            buttons.append(Button(pygame.Rect(390, 468, 238, 50), "KOPIUJ KOD", self.copy_room, secondary=True))
            if self.role == "host" and self.peer_name:
                buttons.append(Button(pygame.Rect(650, 468, 240, 50), "START CO-OP", self.start_as_host, accent=COLORS["green"]))
        self.buttons = buttons

    def toggle_advanced(self) -> None:
        self.advanced = not self.advanced
        self.rebuild_buttons()

    def paste_room_code(self) -> None:
        self.room_input.select_all = True
        if self.room_input.paste():
            self.room_input.value = self.room_input.value.upper().replace("-", "").replace(" ", "")[:6]
            self.status = "Kod wklejony. Kliknij DOŁĄCZ KODEM."
        else:
            self.status = "Schowek jest pusty. Możesz użyć Ctrl+V albo prawego przycisku myszy."

    def paste_server(self) -> None:
        self.server.select_all = True
        if self.server.paste():
            self.server.value = normalize_ws_url(self.server.value)
            self.status = "Adres serwera został wklejony."
        else:
            self.status = "Schowek jest pusty."

    def reset_server(self) -> None:
        self.server.value = DEFAULT_WS_SERVER
        self.status = "Przywrócono publiczny serwer Cell Defender."

    def copy_room(self) -> None:
        if self.room and _clipboard_set(self.room):
            self.status = f"Kod {self.room} skopiowany. Wyślij go znajomemu."
        elif self.room:
            self.status = f"Kod pokoju: {self.room}"

    def save_settings(self) -> None:
        url = normalize_ws_url(self.server.value)
        self.server.value = url
        settings = self.app.save.data["settings"]
        settings["server_url"] = url
        settings["update_server_url"] = url.replace("wss://", "https://").replace("ws://", "http://")
        settings["nickname"] = self.nickname.value.strip() or "Komórka"
        self.app.updater.set_server_url(settings["update_server_url"])
        self.app.save.save()

    def _begin_connection(self) -> None:
        url = normalize_ws_url(self.server.value)
        self.server.value = url
        if not url.startswith(("ws://", "wss://")):
            self.status = "Nieprawidłowy adres serwera."
            return
        self.save_settings()
        if self.network:
            self.manual_close = True
            self.network.close()
        self.manual_close = False
        self.network = NetworkClient(url)
        self.network.start()
        self.connect_attempts += 1
        self.state = f"connecting_{self.pending_action}"
        self.status = f"Łączenie z serwerem... próba {self.connect_attempts}/{self.MAX_CONNECT_ATTEMPTS}"

    def connect(self, action: str) -> None:
        self.pending_action = action
        self.connect_attempts = 0
        self.retry_timer = 0.0
        self.room = ""
        self.role = ""
        self.peer_name = ""
        self._begin_connection()
        self.rebuild_buttons()

    def create_room(self) -> None:
        self.connect("create")

    def join_room(self) -> None:
        code = self.room_input.value.upper().replace("-", "").replace(" ", "").strip()
        self.room_input.value = code
        if len(code) != 6:
            self.status = "Wklej sześcioliterowy kod pokoju."
            return
        self.connect("join")

    def start_as_host(self) -> None:
        if not self.network or not self.peer_name:
            return
        self.network.send("start", chapter=self.chapter_id)
        self.app.start_coop_host(self.chapter_id, self.network, self.room, self.peer_name)

    def back(self) -> None:
        self.manual_close = True
        if self.network:
            self.network.close()
        self.app.show_menu()

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE and not any(f.active for f in self.fields):
                self.back(); return
            if event.key == pygame.K_LEFT:
                self.chapter_id = max(1, self.chapter_id - 1)
            elif event.key == pygame.K_RIGHT:
                self.chapter_id = min(int(self.app.save.data["unlocked_chapter"]), self.chapter_id + 1)
            elif event.key == pygame.K_RETURN and self.room_input.active:
                self.join_room(); return
        for field in self.fields:
            if field.handle(event):
                return
        for button in self.buttons:
            if button.handle(event):
                self.app.audio.play("click")
                return

    def _schedule_retry(self) -> None:
        if self.room or self.manual_close or not self.pending_action:
            return
        if self.connect_attempts >= self.MAX_CONNECT_ATTEMPTS:
            self.status = "Nie udało się połączyć. Serwer może się uruchamiać — odczekaj chwilę i spróbuj ponownie."
            self.state = "idle"
            return
        self.retry_timer = 2.5
        self.status = f"Serwer się budzi. Ponowna próba za chwilę ({self.connect_attempts + 1}/{self.MAX_CONNECT_ATTEMPTS})..."

    def update(self, dt: float) -> None:
        if self.retry_timer > 0:
            self.retry_timer -= dt
            if self.retry_timer <= 0:
                self._begin_connection()
        if not self.network:
            return
        self.ping_timer -= dt
        if self.network.connected and self.ping_timer <= 0:
            self.network.ping(); self.ping_timer = 3.0
        for event in self.network.poll():
            data = event.data
            if event.type == "connected":
                nick = self.nickname.value.strip() or "Komórka"
                if self.pending_action == "create":
                    self.network.send("create", nickname=nick)
                    self.state = "awaiting_create"
                elif self.pending_action == "join":
                    self.network.send("join", nickname=nick, room=self.room_input.value.upper().strip())
                    self.state = "awaiting_join"
                self.status = "Połączono. Serwer przygotowuje pokój..."
            elif event.type == "room_created":
                self.role = "host"; self.room = str(data["room"]); self.state = "waiting"
                self.pending_action = ""
                self.status = f"Pokój {self.room} gotowy. Kod został skopiowany — wyślij go znajomemu."
                _clipboard_set(self.room)
                self.rebuild_buttons()
            elif event.type == "room_joined":
                self.role = "guest"; self.room = str(data["room"]); self.peer_name = str(data.get("host_nickname", "Host")); self.state = "waiting"
                self.pending_action = ""
                self.status = f"Dołączono do {self.peer_name}. Czekaj, aż host rozpocznie grę."
                self.rebuild_buttons()
            elif event.type == "peer_joined":
                self.peer_name = str(data.get("nickname", "Gracz 2"))
                self.status = f"{self.peer_name} dołączył. Kliknij START CO-OP."
                self.rebuild_buttons()
            elif event.type == "start" and self.role == "guest":
                self.app.start_coop_guest(int(data.get("chapter", 1)), self.network, self.room, self.peer_name)
                return
            elif event.type == "peer_left":
                self.peer_name = ""; self.status = "Drugi gracz opuścił pokój."; self.rebuild_buttons()
            elif event.type == "error":
                self.status = str(data.get("message", "Błąd połączenia"))
                if not self.room:
                    self._schedule_retry()
            elif event.type == "disconnected" and self.state != "idle":
                if not self.room:
                    self._schedule_retry()
                else:
                    self.status = "Rozłączono z serwerem. Wróć do menu i utwórz nowy pokój."

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["huge"], "ONLINE CO-OP", COLORS["white"], (WIDTH // 2, 48), "midtop")
        draw_text(surface, self.app.fonts["small"], "Adres serwera jest gotowy. Host tworzy pokój, a znajomy wkleja tylko kod.", COLORS["muted"], (WIDTH // 2, 102), "midtop")
        panel = pygame.Rect(320, 150, 640, 486 if not self.advanced else 500)
        draw_panel(surface, panel, COLORS["panel"], COLORS["line"], 22, 242)

        self.nickname.draw(surface, self.app.fonts["small"], self.app.fonts["tiny_bold"], "TWÓJ NICK")
        chapter = CHAPTERS[self.chapter_id - 1]
        draw_text(surface, self.app.fonts["tiny_bold"], "ROZDZIAŁ HOSTA", COLORS["muted"], (910, 202), "topright")
        draw_text(surface, self.app.fonts["small_bold"], f"←  {self.chapter_id}. {chapter['name']}  →", COLORS["cyan"], (910, 232), "topright")

        if not self.room:
            self.room_input.draw(surface, self.app.fonts["small_bold"], self.app.fonts["tiny_bold"], "KOD OD ZNAJOMEGO — TYLKO PRZY DOŁĄCZANIU")
            draw_text(surface, self.app.fonts["tiny"], "Ctrl+V i prawy przycisk myszy również działają.", COLORS["muted"], (390, 350))
        else:
            code_box = pygame.Rect(390, 292, 500, 138)
            draw_panel(surface, code_box, COLORS["panel2"], COLORS["yellow"], 18, 245)
            draw_text(surface, self.app.fonts["tiny_bold"], "KOD TWOJEGO POKOJU", COLORS["muted"], (code_box.centerx, code_box.y + 17), "midtop")
            draw_text(surface, self.app.fonts["huge"], self.room, COLORS["yellow"], (code_box.centerx, code_box.y + 50), "midtop")
            waiting = f"W pokoju: Ty + {self.peer_name}" if self.peer_name else "Oczekiwanie na drugiego gracza..."
            draw_text(surface, self.app.fonts["tiny"], waiting, COLORS["muted"], (code_box.centerx, code_box.bottom - 24), "midbottom")

        status_rect = pygame.Rect(390, 518 if not self.advanced else 500, 500, 54)
        draw_panel(surface, status_rect, COLORS["panel2"], COLORS["purple"], 11, 235)
        for i, line in enumerate(self.app.wrap_text(self.status, self.app.fonts["tiny"], status_rect.width - 24)[:2]):
            draw_text(surface, self.app.fonts["tiny"], line, COLORS["text"], (status_rect.x + 12, status_rect.y + 10 + i * 19))

        if self.advanced and not self.room:
            self.server.draw(surface, self.app.fonts["tiny"], self.app.fonts["tiny_bold"], "ADRES SERWERA — można wkleić Ctrl+V")

        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"] if not button.small else self.app.fonts["tiny_bold"])
        if self.network and self.network.connected:
            draw_text(surface, self.app.fonts["tiny"], f"Połączono • ping {self.network.latency_ms:.0f} ms", COLORS["green"], (WIDTH - 72, 694), "bottomright")


class CoopHostGameplayScene(GameplayScene):
    def __init__(self, app: Any, chapter_id: int, network: NetworkClient, room: str, peer_name: str):
        super().__init__(app, chapter_id)
        self.network = network
        self.room = room
        self.peer_name = peer_name
        partner = Player(self, "guest", remote=True)
        partner.pos = self.player.pos + pygame.Vector2(70, 0)
        partner.display_name = peer_name
        # Kopia aktualnych parametrów hosta, aby wszystkie bonusy startowe działały na obu graczy.
        for attr in ("max_hp", "base_max_hp", "hp", "speed", "base_speed", "damage_mul", "fire_rate_mul", "pickup_radius", "armor", "regen", "luck"):
            setattr(partner, attr, getattr(self.player, attr))
        self.coop_players = [partner]
        self.enemy_hp_mul *= 1.55
        self.enemy_count_mul *= 1.25
        self.remote_shot_cd = 0.0
        self.remote_ability_cd = 0.0
        self.snapshot_timer = 0.0
        self.ping_timer = 0.0
        self._sent_result = False
        self.revive_timers = {"host": 0.0, "guest": 0.0}
        expansion = self.app.save.data.setdefault("expansion", {})
        expansion["online_runs"] = int(expansion.get("online_runs", 0)) + 1

    def leave_to_menu(self) -> None:
        self.network.close()
        self.app.show_menu()

    def build_pause_buttons(self) -> None:
        self.pause_buttons = [
            Button(pygame.Rect(500, 340, 280, 52), "WZNÓW", lambda: setattr(self, "paused", False)),
            Button(pygame.Rect(500, 406, 280, 52), "MENU I ROZŁĄCZ", self.leave_to_menu, secondary=True),
        ]

    def build_result_buttons(self) -> None:
        self.result_buttons = [Button(pygame.Rect(535, 548, 210, 52), "MENU", self.leave_to_menu, secondary=True)]

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)

    def update_remote_support(self, dt: float) -> None:
        if not self.coop_players:
            return
        partner = self.coop_players[0]
        self.remote_shot_cd -= dt
        self.remote_ability_cd = max(0.0, self.remote_ability_cd - dt)
        if partner.hp <= 0 or self.remote_shot_cd > 0:
            return
        targets = self.nearest_enemies(partner.pos, 1)
        if not targets:
            return
        direction = targets[0].pos - partner.pos
        if direction.length_squared() <= 0:
            return
        direction = direction.normalize()
        level = max(1, self.weapon_levels.get("capsule", 1))
        self.projectiles.append(Projectile(
            partner.pos + direction * 28, direction * (500 + level * 18),
            8.0 * (1.34 ** (level - 1)) * partner.damage_mul,
            6 * self.projectile_size_mul, COLORS["green"], 2.2,
            1 + level // 3, "player", "bullet", 0, min(.55, .04 + partner.luck),
        ))
        self.remote_shot_cd = max(.12, .65 * self.cooldown_mul / partner.fire_rate_mul)

    def remote_ability(self) -> None:
        if self.remote_ability_cd > 0 or not self.coop_players:
            return
        partner = self.coop_players[0]
        if partner.hp <= 0:
            return
        self.explode(partner.pos, 155, 28 * partner.damage_mul, COLORS["green"], knockback=45)
        for p in self.get_active_players():
            p.heal(p.max_hp * .05)
        self.remote_ability_cd = 12.0
        self.app.toast(f"{partner.display_name}: Fala wsparcia", COLORS["green"])

    def update_revives(self, dt: float) -> None:
        players = [self.player, *self.coop_players]
        for player in players:
            if player.hp > 0:
                self.revive_timers[player.player_id] = 0.0
                continue
            living = [p for p in players if p.hp > 0]
            if not living:
                continue
            self.revive_timers[player.player_id] = self.revive_timers.get(player.player_id, 0.0) + dt
            if self.revive_timers[player.player_id] >= 8.0:
                anchor = living[0]
                player.pos = anchor.pos + pygame.Vector2(55 if player.player_id == "guest" else -55, 0)
                player.hp = player.max_hp * .4
                player.invuln = 2.0
                self.revive_timers[player.player_id] = 0.0
                self.app.toast(f"{player.display_name} został odtworzony przez partnera!", COLORS["green"])

    def update(self, dt: float) -> None:
        for event in self.network.poll(250):
            if event.type == "input":
                move = event.data.get("move", [0, 0])
                try:
                    self.coop_players[0].input_vector.xy = clamp(float(move[0]), -1, 1), clamp(float(move[1]), -1, 1)
                except (TypeError, ValueError, IndexError):
                    self.coop_players[0].input_vector.xy = 0, 0
            elif event.type == "ability":
                self.remote_ability()
            elif event.type in {"peer_left", "disconnected"}:
                self.app.toast("Partner rozłączył się. Gra trwa w pojedynkę.", COLORS["red"])
                self.coop_players = []
        super().update(dt)
        self.update_revives(dt)
        if not self.game_over:
            self.update_remote_support(dt)
        self.snapshot_timer -= dt
        self.ping_timer -= dt
        if self.ping_timer <= 0:
            self.network.ping(); self.ping_timer = 3.0
        if self.snapshot_timer <= 0:
            self.network.send("snapshot", state=self.make_snapshot())
            self.snapshot_timer = 1 / 14
        if self.game_over and not self._sent_result:
            self.network.send("snapshot", state=self.make_snapshot())
            self._sent_result = True
            if self.victory:
                expansion = self.app.save.data.setdefault("expansion", {})
                expansion["online_wins"] = int(expansion.get("online_wins", 0)) + 1

    def make_snapshot(self) -> dict[str, Any]:
        players = [{
            "id": p.player_id, "x": round(p.pos.x, 2), "y": round(p.pos.y, 2),
            "hp": round(p.hp, 2), "max_hp": round(p.max_hp, 2), "name": p.display_name,
        } for p in [self.player, *self.coop_players]]
        enemies = []
        for e in self.enemies[:360]:
            enemies.append({
                "x": round(e.pos.x, 1), "y": round(e.pos.y, 1), "r": round(e.radius, 1),
                "hp": round(e.hp, 1), "max": round(e.max_hp, 1), "kind": e.kind,
                "elite": e.elite, "boss": hasattr(e, "name"), "name": getattr(e, "name", ""),
            })
        projectiles = [{"x": round(p.pos.x, 1), "y": round(p.pos.y, 1), "r": round(p.radius, 1), "owner": p.owner, "kind": p.kind} for p in self.projectiles[:500]]
        return {
            "version": 1, "room": self.room, "world": [self.world_w, self.world_h],
            "elapsed": round(self.elapsed, 2), "level": self.level, "xp": self.xp, "xp_needed": self.xp_needed,
            "kills": self.kills, "dna": self.run_dna, "objective": self.objective_text(),
            "players": players, "enemies": enemies, "projectiles": projectiles,
            "pickups": [{"x": round(p.pos.x, 1), "y": round(p.pos.y, 1), "kind": p.kind} for p in self.pickups[:300]],
            "cores": [{"x": c.pos.x, "y": c.pos.y, "done": c.collected} for c in self.objective_cores],
            "beacons": [{"x": b.pos.x, "y": b.pos.y, "done": b.activated} for b in self.beacons],
            "powers": [{"x": p.pos.x, "y": p.pos.y, "done": p.collected} for p in self.map_powers],
            "relics": [{"x": r.pos.x, "y": r.pos.y, "done": r.collected} for r in self.world_relics],
            "anomalies": [{"x": a.pos.x, "y": a.pos.y, "done": a.activated} for a in self.world_anomalies],
            "portal": {"x": self.portal.pos.x, "y": self.portal.pos.y, "unlocked": self.portal.unlocked},
            "contract": CONTRACTS[self.contract_key]["name"], "contract_progress": self.contract_progress,
            "contract_target": CONTRACTS[self.contract_key]["target"], "upgrade_open": self.upgrade_open,
            "game_over": self.game_over, "victory": self.victory,
        }

    def draw_hud(self, surface: pygame.Surface) -> None:
        super().draw_hud(surface)
        draw_text(surface, self.app.fonts["tiny_bold"], f"CO-OP HOST • {self.room} • {self.network.latency_ms:.0f} ms", COLORS["green"], (WIDTH - 20, HEIGHT - 42), "bottomright")


class CoopGuestGameplayScene:
    def __init__(self, app: Any, chapter_id: int, network: NetworkClient, room: str, host_name: str):
        self.app = app
        self.chapter = CHAPTERS[chapter_id - 1]
        self.network = network
        self.room = room
        self.host_name = host_name
        self.snapshot: dict[str, Any] | None = None
        self.camera = pygame.Vector2()
        self.send_timer = 0.0
        self.ping_timer = 0.0
        self.status = "Oczekiwanie na pierwszy stan hosta..."
        self.disconnected = False
        self.ability_flash = 0.0
        self.elapsed_local = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.network.close(); self.app.show_menu()
            elif event.key == pygame.K_SPACE:
                self.network.send("ability"); self.ability_flash = .25

    def update(self, dt: float) -> None:
        self.elapsed_local += dt
        self.ability_flash = max(0.0, self.ability_flash - dt)
        for event in self.network.poll(300):
            if event.type == "snapshot":
                state = event.data.get("state")
                if isinstance(state, dict):
                    self.snapshot = state; self.status = ""
            elif event.type in {"peer_left", "disconnected"}:
                self.disconnected = True; self.status = "Utracono połączenie z hostem. ESC — menu."
            elif event.type == "error":
                self.status = str(event.data.get("message", "Błąd sieci"))
        keys = pygame.key.get_pressed()
        move = [
            float(keys[pygame.K_d] or keys[pygame.K_RIGHT]) - float(keys[pygame.K_a] or keys[pygame.K_LEFT]),
            float(keys[pygame.K_s] or keys[pygame.K_DOWN]) - float(keys[pygame.K_w] or keys[pygame.K_UP]),
        ]
        length = math.hypot(move[0], move[1])
        if length > 1:
            move[0] /= length; move[1] /= length
        self.send_timer -= dt; self.ping_timer -= dt
        if self.send_timer <= 0 and not self.disconnected:
            self.network.send("input", move=move); self.send_timer = 1 / 25
        if self.ping_timer <= 0:
            self.network.ping(); self.ping_timer = 3.0
        if self.snapshot:
            me = next((p for p in self.snapshot.get("players", []) if p.get("id") == "guest"), None)
            if me:
                target = pygame.Vector2(float(me["x"]) - WIDTH / 2, float(me["y"]) - HEIGHT / 2)
                world = self.snapshot.get("world", [6400, 4000])
                target.x = clamp(target.x, 0, max(0, float(world[0]) - WIDTH))
                target.y = clamp(target.y, 0, max(0, float(world[1]) - HEIGHT))
                self.camera += (target - self.camera) * (1 - math.exp(-10 * dt))

    def world_pos(self, item: dict[str, Any]) -> tuple[int, int]:
        return int(float(item.get("x", 0)) - self.camera.x), int(float(item.get("y", 0)) - self.camera.y)

    def draw_background(self, surface: pygame.Surface) -> None:
        c1, c2 = self.chapter["colors"]
        for y in range(0, HEIGHT, 8):
            t = ((self.camera.y + y) % 4000) / 4000
            color = tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3))
            pygame.draw.rect(surface, color, (0, y, WIDTH, 8))
        grid = 112
        for x in range(-int(self.camera.x) % grid - grid, WIDTH + grid, grid):
            pygame.draw.line(surface, (18, 35, 60), (x, 0), (x - 70, HEIGHT), 1)
        for y in range(-int(self.camera.y) % grid - grid, HEIGHT + grid, grid):
            pygame.draw.line(surface, (15, 29, 52), (0, y), (WIDTH, y + 42), 1)

    def draw(self, surface: pygame.Surface) -> None:
        self.draw_background(surface)
        state = self.snapshot
        if not state:
            draw_text(surface, self.app.fonts["large"], self.status, COLORS["text"], (WIDTH // 2, HEIGHT // 2), "center")
            return
        # Punkty świata.
        for key, color, radius in (("cores", COLORS["cyan"], 12), ("beacons", COLORS["purple"], 18), ("powers", COLORS["yellow"], 10), ("relics", COLORS["green"], 10), ("anomalies", COLORS["pink"], 20)):
            for item in state.get(key, []):
                if item.get("done"):
                    continue
                pos = self.world_pos(item)
                if -40 < pos[0] < WIDTH + 40 and -40 < pos[1] < HEIGHT + 40:
                    glow_circle(surface, pos, radius, color, 2)
        portal = state.get("portal", {})
        if portal:
            pos = self.world_pos(portal); color = COLORS["green"] if portal.get("unlocked") else COLORS["red"]
            pygame.draw.circle(surface, color, pos, 58, width=4)
        for pickup in state.get("pickups", []):
            pos = self.world_pos(pickup); color = COLORS["cyan"] if pickup.get("kind") == "xp" else COLORS["purple"]
            pygame.draw.circle(surface, color, pos, 5)
        for enemy in state.get("enemies", []):
            pos = self.world_pos(enemy); r = max(5, int(enemy.get("r", 12)))
            color = COLORS["red"] if enemy.get("boss") else COLORS["yellow"] if enemy.get("elite") else COLORS["pink"]
            pygame.draw.circle(surface, color, pos, r)
            if enemy.get("hp", 0) < enemy.get("max", 1):
                rect = pygame.Rect(pos[0] - r, pos[1] - r - 7, r * 2, 3)
                pygame.draw.rect(surface, (45, 15, 25), rect)
                fill = rect.copy(); fill.width = int(rect.width * max(0, enemy.get("hp", 0) / max(1, enemy.get("max", 1))))
                pygame.draw.rect(surface, COLORS["red"], fill)
        for projectile in state.get("projectiles", []):
            pos = self.world_pos(projectile); color = COLORS["red"] if projectile.get("owner") == "enemy" else COLORS["cyan"]
            pygame.draw.circle(surface, color, pos, max(2, int(projectile.get("r", 3))))
        for p in state.get("players", []):
            pos = self.world_pos(p); color = COLORS["green"] if p.get("id") == "guest" else COLORS["cyan"]
            glow_circle(surface, pos, 24, color, 3)
            pygame.draw.circle(surface, (18, 65, 70), pos, 20)
            pygame.draw.circle(surface, color, pos, 20, width=3)
            draw_text(surface, self.app.fonts["tiny_bold"], str(p.get("name", "Gracz")), color, (pos[0], pos[1] - 34), "midbottom")
        self.draw_hud(surface, state)
        if state.get("upgrade_open"):
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); overlay.fill((3, 5, 15, 170)); surface.blit(overlay, (0, 0))
            draw_text(surface, self.app.fonts["large"], "HOST WYBIERA MUTACJĘ", COLORS["yellow"], (WIDTH // 2, HEIGHT // 2), "center")
        if state.get("game_over"):
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); overlay.fill((3, 5, 15, 205)); surface.blit(overlay, (0, 0))
            label = "WSPÓLNE ZWYCIĘSTWO" if state.get("victory") else "EKSPEDYCJA ZAKOŃCZONA"
            draw_text(surface, self.app.fonts["huge"], label, COLORS["green"] if state.get("victory") else COLORS["red"], (WIDTH // 2, 280), "center")
            draw_text(surface, self.app.fonts["small"], "ESC — wróć do menu", COLORS["muted"], (WIDTH // 2, 350), "center")
        if self.status:
            draw_text(surface, self.app.fonts["small_bold"], self.status, COLORS["red"], (WIDTH // 2, HEIGHT - 52), "center")

    def draw_hud(self, surface: pygame.Surface, state: dict[str, Any]) -> None:
        top = pygame.Rect(18, 16, WIDTH - 36, 72); draw_panel(surface, top, COLORS["panel"], COLORS["line"], 16, 224)
        guest = next((p for p in state.get("players", []) if p.get("id") == "guest"), {"hp": 0, "max_hp": 1})
        host = next((p for p in state.get("players", []) if p.get("id") == "host"), {"hp": 0, "max_hp": 1})
        draw_text(surface, self.app.fonts["small_bold"], f"TY {int(guest['hp'])}/{int(guest['max_hp'])}", COLORS["green"], (38, 28))
        draw_text(surface, self.app.fonts["tiny_bold"], f"HOST {int(host['hp'])}/{int(host['max_hp'])}", COLORS["cyan"], (38, 55))
        elapsed = int(state.get("elapsed", 0)); draw_text(surface, self.app.fonts["large"], f"{elapsed//60:02d}:{elapsed%60:02d}", COLORS["white"], (WIDTH // 2, 28), "midtop")
        draw_text(surface, self.app.fonts["small_bold"], f"Lv.{state.get('level', 1)}  •  Kille {state.get('kills', 0)}  •  DNA {state.get('dna', 0)}", COLORS["muted"], (WIDTH - 38, 34), "topright")
        objective = pygame.Rect(330, 100, 620, 50); draw_panel(surface, objective, COLORS["panel"], COLORS["cyan"], 12, 220)
        draw_text(surface, self.app.fonts["small_bold"], str(state.get("objective", "")), COLORS["text"], (objective.centerx, objective.centery), "center")
        xp = pygame.Rect(20, HEIGHT - 18, WIDTH - 40, 8); draw_progress(surface, xp, float(state.get("xp", 0)), float(state.get("xp_needed", 1)), COLORS["purple"])
        draw_text(surface, self.app.fonts["tiny_bold"], f"CO-OP GOŚĆ • {self.room} • {self.network.latency_ms:.0f} ms • SPACJA: fala wsparcia", COLORS["green"], (WIDTH - 20, HEIGHT - 42), "bottomright")

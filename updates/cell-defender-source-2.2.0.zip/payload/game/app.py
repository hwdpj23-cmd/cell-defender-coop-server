from __future__ import annotations

import math
import os
import sys
from pathlib import Path
from typing import Any

import pygame

from .data import CHAPTERS, COLORS, FPS, HEIGHT, LAB_UPGRADES, TITLE, WIDTH
from .gameplay import GameplayScene
from .content_expansion import CELL_CLASSES, CHALLENGES, content_counts
from .save_manager import SaveManager
from .ui import Button, Toast, draw_progress
from .updater import UpdateManager
from .version import GAME_VERSION
from .utils import draw_panel, draw_text, format_number, glow_circle


class AudioManager:
    def __init__(self, root: Path, settings: dict[str, Any]):
        self.root = root
        self.settings = settings
        self.enabled = False
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            self.enabled = True
            for key in ("shoot", "needle", "bubble", "laser", "pulse", "chain", "hurt", "level", "boss", "boss_down", "start", "victory", "defeat", "click"):
                path = root / "assets" / f"{key}.wav"
                if path.exists():
                    self.sounds[key] = pygame.mixer.Sound(str(path))
            music_path = root / "assets" / "music.wav"
            if music_path.exists():
                pygame.mixer.music.load(str(music_path))
                pygame.mixer.music.set_volume(float(settings.get("music", .35)))
                pygame.mixer.music.play(-1)
        except pygame.error:
            self.enabled = False

    def play(self, key: str) -> None:
        if not self.enabled:
            return
        sound = self.sounds.get(key)
        if sound:
            sound.set_volume(float(self.settings.get("sfx", .55)))
            sound.play()

    def refresh(self) -> None:
        if self.enabled:
            pygame.mixer.music.set_volume(float(self.settings.get("music", .35)))


class Scene:
    def __init__(self, app: "App"):
        self.app = app
        self.buttons: list[Button] = []

    def handle_event(self, event: pygame.event.Event) -> None:
        for button in self.buttons:
            if button.handle(event):
                self.app.audio.play("click")
                return

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface) -> None:
        raise NotImplementedError


class MenuScene(Scene):
    """Nowe centrum dowodzenia z sześcioma rozdziałami kampanii."""

    CARD_W = 264
    CARD_H = 202
    CARD_GAP_X = 18
    CARD_GAP_Y = 18
    GRID_X = 410
    GRID_Y = 150

    def __init__(self, app: "App"):
        super().__init__(app)
        self.selected = min(max(1, int(app.save.data["unlocked_chapter"])), len(CHAPTERS))
        self.rebuild_buttons()

    def rebuild_buttons(self) -> None:
        update_label = "NOWA WERSJA!" if self.app.updater.update_available else "AKTUALIZACJE"
        self.update_button = Button(
            pygame.Rect(204, 600, 158, 42),
            update_label,
            self.app.show_updates,
            secondary=not self.app.updater.update_available,
            accent=COLORS["yellow"] if self.app.updater.update_available else COLORS["purple"],
            small=True,
        )
        self.buttons = [
            Button(pygame.Rect(50, 430, 312, 52), "ROZPOCZNIJ EKSPEDYCJĘ", lambda: self.app.start_run(self.selected)),
            Button(pygame.Rect(50, 492, 151, 48), "ONLINE CO-OP", self.app.show_multiplayer, secondary=True, small=True),
            Button(pygame.Rect(211, 492, 151, 48), "CHAT GLOBALNY", self.app.show_global_chat, accent=COLORS["teal"], small=True),
            Button(pygame.Rect(50, 550, 151, 42), "LABORATORIUM", self.app.show_lab, secondary=True, small=True),
            Button(pygame.Rect(211, 550, 151, 42), "STATYSTYKI", self.app.show_stats, secondary=True, small=True),
            Button(pygame.Rect(50, 600, 142, 42), "USTAWIENIA", self.app.show_settings, secondary=True, small=True),
            self.update_button,
            Button(pygame.Rect(50, 654, 112, 34), "WYJŚCIE", self.app.quit, secondary=True, small=True),
        ]

    def chapter_rect(self, chapter_id: int) -> pygame.Rect:
        index = chapter_id - 1
        col = index % 3
        row = index // 3
        return pygame.Rect(
            self.GRID_X + col * (self.CARD_W + self.CARD_GAP_X),
            self.GRID_Y + row * (self.CARD_H + self.CARD_GAP_Y),
            self.CARD_W,
            self.CARD_H,
        )

    def _move_selection(self, delta: int) -> None:
        unlocked = min(int(self.app.save.data["unlocked_chapter"]), len(CHAPTERS))
        self.selected = max(1, min(unlocked, self.selected + delta))

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_LEFT, pygame.K_a):
                self._move_selection(-1)
            elif event.key in (pygame.K_RIGHT, pygame.K_d):
                self._move_selection(1)
            elif event.key in (pygame.K_UP, pygame.K_w):
                self._move_selection(-3)
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self._move_selection(3)
            elif event.key == pygame.K_RETURN:
                self.app.start_run(self.selected)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for chapter in CHAPTERS:
                if self.chapter_rect(chapter["id"]).collidepoint(event.pos):
                    if chapter["id"] <= int(self.app.save.data["unlocked_chapter"]):
                        self.selected = chapter["id"]
                        self.app.audio.play("click")
                    else:
                        self.app.toast("Ukończ wcześniejszy rozdział, aby odblokować tę strefę.", COLORS["red"])
                    return
        super().handle_event(event)

    def update(self, dt: float) -> None:
        del dt
        wanted = "NOWA WERSJA!" if self.app.updater.update_available else "AKTUALIZACJE"
        if self.update_button.text != wanted:
            self.rebuild_buttons()

    def draw_profile(self, surface: pygame.Surface) -> None:
        panel = pygame.Rect(48, 144, 316, 112)
        draw_panel(surface, panel, COLORS["panel"], COLORS["line"], 18, 242)
        draw_text(surface, self.app.fonts["tiny_bold"], "PROFIL ODPORNOŚCI", COLORS["teal"], (68, 162))
        stats = [
            ("DNA", format_number(self.app.save.data["dna"]), COLORS["purple"]),
            ("MONETY", format_number(self.app.save.data["coins"]), COLORS["yellow"]),
            ("MAX LV", str(self.app.save.data["highest_level"]), COLORS["cyan"]),
        ]
        for i, (label, value, color) in enumerate(stats):
            x = 68 + i * 96
            draw_text(surface, self.app.fonts["tiny"], label, COLORS["muted"], (x, 194))
            draw_text(surface, self.app.fonts["small_bold"], value, color, (x, 218))

    def draw_selected_info(self, surface: pygame.Surface) -> None:
        chapter = CHAPTERS[self.selected - 1]
        accent = tuple(chapter.get("accent", COLORS["cyan"]))
        panel = pygame.Rect(48, 270, 316, 142)
        draw_panel(surface, panel, COLORS["panel2"], accent, 18, 246)
        draw_text(surface, self.app.fonts["tiny_bold"], f"AKTYWNA STREFA  {chapter['id']}/{len(CHAPTERS)}", accent, (68, 288))
        draw_text(surface, self.app.fonts["medium"], chapter["name"], COLORS["white"], (68, 314))
        lines = self.app.wrap_text(chapter["description"], self.app.fonts["tiny"], 274)[:2]
        for i, line in enumerate(lines):
            draw_text(surface, self.app.fonts["tiny"], line, COLORS["muted"], (68, 349 + i * 19))
        draw_text(
            surface,
            self.app.fonts["tiny_bold"],
            f"{chapter['duration']//60} MIN  •  +{chapter['reward']} DNA  •  TRUDNOŚĆ x{chapter['enemy_mul']:.2f}",
            accent,
            (68, 391),
            "bottomleft",
        )

    def draw_chapter_card(self, surface: pygame.Surface, chapter: dict[str, Any]) -> None:
        rect = self.chapter_rect(int(chapter["id"]))
        locked = int(chapter["id"]) > int(self.app.save.data["unlocked_chapter"])
        selected = int(chapter["id"]) == self.selected
        accent = COLORS["muted"] if locked else tuple(chapter.get("accent", COLORS["cyan"]))
        fill = COLORS["panel2"] if selected else COLORS["panel"]
        draw_panel(surface, rect, fill, accent if selected else COLORS["line"], 18, 246)

        badge = pygame.Rect(rect.x + 16, rect.y + 15, 44, 34)
        pygame.draw.rect(surface, (*accent, 45), badge, border_radius=10)
        pygame.draw.rect(surface, accent, badge, width=1, border_radius=10)
        draw_text(surface, self.app.fonts["small_bold"], f"{chapter['id']:02d}", accent, badge.center, "center")
        draw_text(surface, self.app.fonts["tiny_bold"], chapter["subtitle"].upper(), accent, (rect.right - 16, rect.y + 21), "topright")
        draw_text(surface, self.app.fonts["medium"], chapter["name"], COLORS["text"] if not locked else COLORS["muted"], (rect.x + 16, rect.y + 61))
        lines = self.app.wrap_text(chapter["description"], self.app.fonts["tiny"], rect.width - 32)[:2]
        for i, line in enumerate(lines):
            draw_text(surface, self.app.fonts["tiny"], line, COLORS["muted"], (rect.x + 16, rect.y + 99 + i * 19))
        pygame.draw.line(surface, COLORS["line"], (rect.x + 16, rect.bottom - 44), (rect.right - 16, rect.bottom - 44), 1)
        draw_text(surface, self.app.fonts["tiny_bold"], f"{chapter['duration']//60} MIN", COLORS["muted"], (rect.x + 16, rect.bottom - 29), "midleft")
        draw_text(surface, self.app.fonts["tiny_bold"], f"+{chapter['reward']} DNA", accent, (rect.right - 16, rect.bottom - 29), "midright")
        if locked:
            overlay = pygame.Surface(rect.size, pygame.SRCALPHA)
            overlay.fill((3, 7, 18, 178))
            surface.blit(overlay, rect)
            draw_text(surface, self.app.fonts["small_bold"], "ZABLOKOWANA", COLORS["red"], rect.center, "center")
        elif selected:
            pygame.draw.rect(surface, accent, rect, width=3, border_radius=18)

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["logo"], "CELL DEFENDER", COLORS["white"], (48, 32))
        draw_text(surface, self.app.fonts["small_bold"], "EVOLUTION NETWORK", COLORS["teal"], (52, 101))
        draw_text(surface, self.app.fonts["large"], "KAMPANIA BIOLOGICZNA", COLORS["text"], (410, 56))
        draw_text(surface, self.app.fonts["tiny"], "6 rozdziałów • rozwój broni do 8 poziomu • globalna społeczność", COLORS["muted"], (412, 103))
        self.draw_profile(surface)
        self.draw_selected_info(surface)
        for chapter in CHAPTERS:
            self.draw_chapter_card(surface, chapter)
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"] if not button.small else self.app.fonts["tiny_bold"])
        draw_text(surface, self.app.fonts["tiny"], f"Wersja {GAME_VERSION}", COLORS["muted"], (176, 671), "midleft")
        draw_text(surface, self.app.fonts["tiny"], "WASD / strzałki: wybór • ENTER: start", COLORS["muted"], (WIDTH - 28, HEIGHT - 18), "bottomright")


class LabScene(Scene):
    def __init__(self, app: "App"):
        super().__init__(app)
        self.buttons = [
            Button(pygame.Rect(52, 642, 180, 48), "← MENU", app.show_menu, secondary=True),
            Button(pygame.Rect(250, 642, 250, 48), "KLASY I WYZWANIA", app.show_evolution, secondary=True),
        ]

    def cost(self, key: str) -> int:
        level = int(self.app.save.data["lab"][key])
        return int(LAB_UPGRADES[key]["base_cost"] * (1.48 ** level) + level * 2)

    def buy(self, key: str) -> None:
        data = LAB_UPGRADES[key]
        level = int(self.app.save.data["lab"][key])
        if level >= data["max"]:
            self.app.toast("Ulepszenie ma maksymalny poziom.", COLORS["muted"])
            return
        cost = self.cost(key)
        if self.app.save.data["dna"] < cost:
            self.app.toast("Za mało DNA.", COLORS["red"])
            return
        self.app.save.data["dna"] -= cost
        self.app.save.data["lab"][key] += 1
        self.app.save.save()
        self.app.toast(f"Kupiono: {data['name']}", COLORS["green"])
        self.app.audio.play("level")

    def card_rect(self, index: int) -> pygame.Rect:
        col = index % 2
        row = index // 2
        return pygame.Rect(286 + col * 480, 158 + row * 126, 448, 108)

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.app.show_menu()
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, key in enumerate(LAB_UPGRADES):
                rect = self.card_rect(i)
                buy_rect = pygame.Rect(rect.right - 124, rect.y + 28, 104, 52)
                if buy_rect.collidepoint(event.pos):
                    self.buy(key)
                    return
        super().handle_event(event)

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["huge"], "LABORATORIUM", COLORS["white"], (52, 48))
        draw_text(surface, self.app.fonts["small"], "Trwałe modyfikacje działające podczas każdej ekspedycji.", COLORS["muted"], (54, 112))
        wallet = pygame.Rect(WIDTH - 264, 44, 210, 64)
        draw_panel(surface, wallet, COLORS["panel"], COLORS["purple"], 16, 245)
        draw_text(surface, self.app.fonts["tiny"], "DOSTĘPNE DNA", COLORS["muted"], (wallet.x + 18, wallet.y + 10))
        draw_text(surface, self.app.fonts["medium"], format_number(self.app.save.data["dna"]), COLORS["purple"], (wallet.right - 18, wallet.y + 28), "topright")
        for i, (key, data) in enumerate(LAB_UPGRADES.items()):
            rect = self.card_rect(i)
            level = int(self.app.save.data["lab"][key])
            maximum = int(data["max"])
            maxed = level >= maximum
            draw_panel(surface, rect, COLORS["panel"], COLORS["line"], 16, 242)
            accent = [COLORS["cyan"], COLORS["purple"], COLORS["yellow"], COLORS["green"]][i % 4]
            pygame.draw.circle(surface, accent, (rect.x + 43, rect.centery), 22)
            draw_text(surface, self.app.fonts["tiny_bold"], "DNA", COLORS["white"], (rect.x + 43, rect.centery), "center")
            draw_text(surface, self.app.fonts["small_bold"], data["name"], COLORS["text"], (rect.x + 78, rect.y + 16))
            draw_text(surface, self.app.fonts["tiny"], data["description"], COLORS["muted"], (rect.x + 78, rect.y + 45))
            draw_progress(surface, pygame.Rect(rect.x + 78, rect.y + 78, 220, 7), level, maximum, accent)
            draw_text(surface, self.app.fonts["tiny"], f"{level}/{maximum}", COLORS["muted"], (rect.x + 307, rect.y + 72))
            buy_rect = pygame.Rect(rect.right - 124, rect.y + 28, 104, 52)
            affordable = self.app.save.data["dna"] >= self.cost(key)
            fill = COLORS["purple"] if affordable and not maxed else (52, 56, 76)
            pygame.draw.rect(surface, fill, buy_rect, border_radius=10)
            pygame.draw.rect(surface, accent if not maxed else COLORS["line"], buy_rect, width=1, border_radius=10)
            text = "MAX" if maxed else f"{self.cost(key)} DNA"
            draw_text(surface, self.app.fonts["tiny_bold"], text, COLORS["white"] if affordable or maxed else COLORS["muted"], buy_rect.center, "center")
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"])


class StatsScene(Scene):
    def __init__(self, app: "App"):
        super().__init__(app)
        self.buttons = [Button(pygame.Rect(52, 642, 180, 48), "← MENU", app.show_menu, secondary=True)]

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.app.show_menu(); return
        super().handle_event(event)

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["huge"], "ARCHIWUM ODPORNOŚCI", COLORS["white"], (52, 48))
        save = self.app.save.data
        best = float(save["best_time"])
        stats = [
            ("Łączna liczba ekspedycji", save["runs"], COLORS["cyan"]),
            ("Zwycięstwa", save["wins"], COLORS["green"]),
            ("Wyeliminowane zarazki", save["total_kills"], COLORS["pink"]),
            ("Najwyższy poziom", save["highest_level"], COLORS["yellow"]),
            ("Najdłuższe przetrwanie", f"{int(best)//60:02d}:{int(best)%60:02d}", COLORS["purple"]),
            ("Odblokowany rozdział", f"{save['unlocked_chapter']}/{len(CHAPTERS)}", COLORS["orange"]),
            ("Zgromadzone DNA", save["dna"], COLORS["purple"]),
            ("Monety laboratorium", save["coins"], COLORS["yellow"]),
        ]
        for i, (label, value, color) in enumerate(stats):
            col, row = i % 4, i // 4
            rect = pygame.Rect(52 + col * 300, 165 + row * 170, 270, 142)
            draw_panel(surface, rect, COLORS["panel"], color, 18, 243)
            glow_circle(surface, (rect.x + 42, rect.y + 42), 14, color, 2)
            draw_text(surface, self.app.fonts["tiny"], label, COLORS["muted"], (rect.x + 20, rect.y + 74))
            draw_text(surface, self.app.fonts["large"], format_number(value) if isinstance(value, (int, float)) else str(value), COLORS["text"], (rect.x + 20, rect.y + 96))
        # Lab completion
        total_levels = sum(int(v) for v in save["lab"].values())
        max_levels = sum(int(v["max"]) for v in LAB_UPGRADES.values())
        rect = pygame.Rect(52, 532, 1176, 82)
        draw_panel(surface, rect, COLORS["panel"], COLORS["line"], 16, 243)
        draw_text(surface, self.app.fonts["small_bold"], "ROZWÓJ LABORATORIUM", COLORS["text"], (rect.x + 22, rect.y + 16))
        draw_progress(surface, pygame.Rect(rect.x + 22, rect.y + 49, rect.width - 44, 12), total_levels, max_levels, COLORS["purple"])
        draw_text(surface, self.app.fonts["tiny"], f"{total_levels}/{max_levels} poziomów", COLORS["muted"], (rect.right - 24, rect.y + 15), "topright")
        expansion = save.get("expansion", {})
        extra = f"Relikty: {len(expansion.get('discovered_relics', []))}/80   •   Osiągnięcia: {len(expansion.get('unlocked_achievements', []))}/32   •   Kontrakty: {expansion.get('completed_contracts', 0)}   •   Wygrane online: {expansion.get('online_wins', 0)}"
        draw_text(surface, self.app.fonts["tiny"], extra, COLORS["cyan"], (rect.x + 22, rect.bottom - 10), "bottomleft")
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"])


class EvolutionScene(Scene):
    def __init__(self, app: "App"):
        super().__init__(app)
        self.class_keys = list(CELL_CLASSES)
        self.challenge_keys = ["none", *CHALLENGES.keys()]
        settings = app.save.data["settings"]
        selected_class = str(settings.get("selected_class", "class_01"))
        selected_challenge = str(settings.get("selected_challenge", "none"))
        self.class_index = self.class_keys.index(selected_class) if selected_class in self.class_keys else 0
        self.challenge_index = self.challenge_keys.index(selected_challenge) if selected_challenge in self.challenge_keys else 0
        self.buttons = [
            Button(pygame.Rect(52, 642, 180, 48), "← LAB", app.show_lab, secondary=True),
            Button(pygame.Rect(1018, 642, 210, 48), "ZAPISZ WYBÓR", self.save_choice),
        ]

    def save_choice(self) -> None:
        settings = self.app.save.data["settings"]
        settings["selected_class"] = self.class_keys[self.class_index]
        settings["selected_challenge"] = self.challenge_keys[self.challenge_index]
        self.app.save.save()
        self.app.toast("Zapisano klasę i wyzwanie.", COLORS["green"])

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.app.show_lab(); return
            if event.key in (pygame.K_a, pygame.K_LEFT):
                self.class_index = (self.class_index - 1) % len(self.class_keys)
            elif event.key in (pygame.K_d, pygame.K_RIGHT):
                self.class_index = (self.class_index + 1) % len(self.class_keys)
            elif event.key in (pygame.K_w, pygame.K_UP):
                self.challenge_index = (self.challenge_index - 1) % len(self.challenge_keys)
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                self.challenge_index = (self.challenge_index + 1) % len(self.challenge_keys)
            elif event.key == pygame.K_RETURN:
                self.save_choice()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            x, y = event.pos
            if pygame.Rect(72, 310, 70, 70).collidepoint((x, y)):
                self.class_index = (self.class_index - 1) % len(self.class_keys); return
            if pygame.Rect(1138, 310, 70, 70).collidepoint((x, y)):
                self.class_index = (self.class_index + 1) % len(self.class_keys); return
            if pygame.Rect(72, 500, 70, 70).collidepoint((x, y)):
                self.challenge_index = (self.challenge_index - 1) % len(self.challenge_keys); return
            if pygame.Rect(1138, 500, 70, 70).collidepoint((x, y)):
                self.challenge_index = (self.challenge_index + 1) % len(self.challenge_keys); return
        super().handle_event(event)

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        counts = content_counts()
        draw_text(surface, self.app.fonts["huge"], "EWOLUCJA 2.0", COLORS["white"], (52, 48))
        draw_text(surface, self.app.fonts["small"], f"Pakiet zawiera {counts['total']} elementy: geny, relikty, synergie, kontrakty, anomalie i inne.", COLORS["muted"], (54, 112))
        class_key = self.class_keys[self.class_index]
        cls = CELL_CLASSES[class_key]
        class_rect = pygame.Rect(160, 220, 960, 220)
        draw_panel(surface, class_rect, COLORS["panel"], cls["color"], 22, 245)
        draw_text(surface, self.app.fonts["tiny_bold"], f"KLASA KOMÓRKI  {self.class_index + 1}/{len(self.class_keys)}", cls["color"], (class_rect.centerx, class_rect.y + 22), "midtop")
        draw_text(surface, self.app.fonts["large"], cls["name"], COLORS["text"], (class_rect.centerx, class_rect.y + 62), "midtop")
        draw_text(surface, self.app.fonts["small"], cls["description"], COLORS["muted"], (class_rect.centerx, class_rect.y + 112), "midtop")
        draw_text(surface, self.app.fonts["small_bold"], f"Startowa broń: {cls['starting_weapon']}  •  efekt: {cls['effect']} × {cls['value']}", COLORS["cyan"], (class_rect.centerx, class_rect.y + 158), "midtop")
        challenge_key = self.challenge_keys[self.challenge_index]
        challenge_rect = pygame.Rect(160, 466, 960, 148)
        color = COLORS["green"] if challenge_key == "none" else CHALLENGES[challenge_key]["color"]
        draw_panel(surface, challenge_rect, COLORS["panel"], color, 20, 245)
        if challenge_key == "none":
            name, desc, reward = "Bez wyzwania", "Standardowa ekspedycja bez dodatkowych utrudnień.", "x1.00"
        else:
            data = CHALLENGES[challenge_key]
            name, desc, reward = data["name"], data["description"], f"x{data['reward_mul']:.2f}"
        draw_text(surface, self.app.fonts["tiny_bold"], f"WYZWANIE  {self.challenge_index + 1}/{len(self.challenge_keys)}", color, (challenge_rect.centerx, challenge_rect.y + 15), "midtop")
        draw_text(surface, self.app.fonts["medium"], name, COLORS["text"], (challenge_rect.centerx, challenge_rect.y + 48), "midtop")
        draw_text(surface, self.app.fonts["tiny"], f"{desc}  Nagrody: {reward}", COLORS["muted"], (challenge_rect.centerx, challenge_rect.y + 91), "midtop")
        for rect, glyph in ((pygame.Rect(72, 310, 70, 70), "‹"), (pygame.Rect(1138, 310, 70, 70), "›"), (pygame.Rect(72, 500, 70, 70), "▲"), (pygame.Rect(1138, 500, 70, 70), "▼")):
            draw_panel(surface, rect, COLORS["panel2"], COLORS["purple"], 14, 245)
            draw_text(surface, self.app.fonts["large"], glyph, COLORS["text"], rect.center, "center")
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"])


class SettingsScene(Scene):
    def __init__(self, app: "App"):
        super().__init__(app)
        self.buttons = [Button(pygame.Rect(52, 642, 180, 48), "← MENU", app.show_menu, secondary=True)]

    def setting_rect(self, index: int) -> pygame.Rect:
        return pygame.Rect(242, 150 + index * 72, 796, 58)

    def change_volume(self, key: str, delta: float) -> None:
        settings = self.app.save.data["settings"]
        settings[key] = max(0.0, min(1.0, round(float(settings[key]) + delta, 2)))
        self.app.audio.refresh(); self.app.save.save()

    def toggle(self, key: str) -> None:
        settings = self.app.save.data["settings"]
        settings[key] = not bool(settings[key])
        self.app.save.save()
        if key == "fullscreen":
            self.app.apply_display_mode()

    def cycle_particles(self) -> None:
        settings = self.app.save.data["settings"]
        settings["particles"] = (int(settings.get("particles", 2)) + 1) % 4
        self.app.save.save()

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.app.show_menu(); return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            x, y = event.pos
            for i, key in enumerate(("music", "sfx")):
                rect = self.setting_rect(i)
                if pygame.Rect(rect.right - 150, rect.y + 10, 44, 38).collidepoint((x, y)):
                    self.change_volume(key, -.1); return
                if pygame.Rect(rect.right - 52, rect.y + 10, 44, 38).collidepoint((x, y)):
                    self.change_volume(key, .1); return
            if self.setting_rect(2).collidepoint((x, y)):
                self.toggle("fullscreen"); return
            if self.setting_rect(3).collidepoint((x, y)):
                self.cycle_particles(); return
            if self.setting_rect(4).collidepoint((x, y)):
                self.toggle("screenshake"); return
            if self.setting_rect(5).collidepoint((x, y)):
                self.toggle("show_damage"); return
        super().handle_event(event)

    def draw(self, surface: pygame.Surface) -> None:
        self.app.draw_menu_background(surface)
        draw_text(surface, self.app.fonts["huge"], "USTAWIENIA", COLORS["white"], (52, 48))
        settings = self.app.save.data["settings"]
        rows = [
            ("Głośność muzyki", f"{int(settings['music'] * 100)}%"),
            ("Głośność efektów", f"{int(settings['sfx'] * 100)}%"),
            ("Pełny ekran", "WŁĄCZONY" if settings["fullscreen"] else "WYŁĄCZONY"),
            ("Cząsteczki", ["WYŁĄCZONE", "NISKIE", "ŚREDNIE", "WYSOKIE"][int(settings.get("particles", 2))]),
            ("Trzęsienie ekranu", "WŁĄCZONE" if settings["screenshake"] else "WYŁĄCZONE"),
            ("Liczby obrażeń", "WŁĄCZONE" if settings["show_damage"] else "WYŁĄCZONE"),
        ]
        for i, (label, value) in enumerate(rows):
            rect = self.setting_rect(i)
            draw_panel(surface, rect, COLORS["panel"], COLORS["line"], 14, 244)
            draw_text(surface, self.app.fonts["small_bold"], label, COLORS["text"], (rect.x + 20, rect.y + 18))
            if i < 2:
                minus = pygame.Rect(rect.right - 150, rect.y + 10, 44, 38)
                plus = pygame.Rect(rect.right - 52, rect.y + 10, 44, 38)
                for box, text in ((minus, "−"), (plus, "+")):
                    pygame.draw.rect(surface, COLORS["panel2"], box, border_radius=9)
                    pygame.draw.rect(surface, COLORS["purple"], box, width=1, border_radius=9)
                    draw_text(surface, self.app.fonts["medium"], text, COLORS["text"], box.center, "center")
                draw_text(surface, self.app.fonts["small_bold"], value, COLORS["purple"], (rect.right - 78, rect.centery), "center")
            else:
                color = COLORS["green"] if "WŁĄCZ" in value or value in ("ŚREDNIE", "WYSOKIE") else COLORS["yellow"] if value == "NISKIE" else COLORS["muted"]
                draw_text(surface, self.app.fonts["small_bold"], value, color, (rect.right - 22, rect.y + 18), "topright")
        draw_text(surface, self.app.fonts["tiny"], "Kliknij ustawienie, aby je zmienić. F11 również przełącza pełny ekran.", COLORS["muted"], (WIDTH // 2, 606), "midtop")
        for button in self.buttons:
            button.draw(surface, self.app.fonts["small_bold"])


class App:
    def __init__(self, root: Path, resources: Path | None = None):
        os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.root = root
        self.resources = resources or root
        self.save = SaveManager(root)
        settings = self.save.data["settings"]
        self.updater = UpdateManager(root, str(settings.get("update_server_url", settings.get("server_url", ""))))
        self.screen: pygame.Surface
        self.apply_display_mode()
        self.clock = pygame.time.Clock()
        self.fonts = self.load_fonts()
        self.audio = AudioManager(self.resources, settings)
        self.scene: Scene | GameplayScene = MenuScene(self)
        self.running = True
        self.toasts: list[Toast] = []
        self.menu_time = 0.0
        if settings.get("auto_check_updates", True):
            self.updater.check_async(silent=True)

    def apply_display_mode(self) -> None:
        settings = self.save.data["settings"]
        flags = pygame.SCALED
        if settings.get("fullscreen", False):
            flags |= pygame.FULLSCREEN
        else:
            flags |= pygame.RESIZABLE
        try:
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags, vsync=1)
        except (pygame.error, TypeError):
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)

    def load_fonts(self) -> dict[str, pygame.font.Font]:
        preferred = ["segoeui", "arial", "dejavusans"]
        def f(size: int, bold: bool = False) -> pygame.font.Font:
            path = pygame.font.match_font(",".join(preferred), bold=bold)
            return pygame.font.Font(path, size) if path else pygame.font.Font(None, size)
        return {
            "tiny": f(16), "tiny_bold": f(16, True), "small": f(19), "small_bold": f(19, True),
            "medium": f(26, True), "large": f(34, True), "huge": f(44, True), "logo": f(58, True),
        }

    def wrap_text(self, text: str, font: pygame.font.Font, width: int) -> list[str]:
        result: list[str] = []
        for paragraph in text.splitlines():
            words = paragraph.split()
            current = ""
            for word in words:
                test = word if not current else current + " " + word
                if font.size(test)[0] <= width:
                    current = test
                else:
                    if current:
                        result.append(current)
                    current = word
            if current:
                result.append(current)
        return result

    def toast(self, text: str, color: tuple[int, int, int] = COLORS["cyan"]) -> None:
        self.toasts.insert(0, Toast(text, color))
        self.toasts = self.toasts[:5]

    def show_menu(self) -> None:
        self.scene = MenuScene(self)

    def show_lab(self) -> None:
        self.scene = LabScene(self)

    def show_stats(self) -> None:
        self.scene = StatsScene(self)

    def show_settings(self) -> None:
        self.scene = SettingsScene(self)

    def show_evolution(self) -> None:
        self.scene = EvolutionScene(self)

    def show_multiplayer(self) -> None:
        from .online import MultiplayerScene
        self.scene = MultiplayerScene(self)

    def show_global_chat(self) -> None:
        from .global_chat import GlobalChatScene
        self.scene = GlobalChatScene(self)

    def show_updates(self) -> None:
        from .update_ui import UpdateScene
        self.scene = UpdateScene(self)

    def start_coop_host(self, chapter_id: int, network: Any, room: str, peer_name: str) -> None:
        from .online import CoopHostGameplayScene
        self.scene = CoopHostGameplayScene(self, chapter_id, network, room, peer_name)

    def start_coop_guest(self, chapter_id: int, network: Any, room: str, host_name: str) -> None:
        from .online import CoopGuestGameplayScene
        self.scene = CoopGuestGameplayScene(self, chapter_id, network, room, host_name)

    def start_run(self, chapter_id: int) -> None:
        if chapter_id > int(self.save.data["unlocked_chapter"]):
            self.toast("Ten rozdział jest jeszcze zablokowany.", COLORS["red"])
            return
        self.scene = GameplayScene(self, chapter_id)

    def quit(self) -> None:
        self.running = False

    def draw_menu_background(self, surface: pygame.Surface) -> None:
        self.menu_time += 1 / FPS
        surface.fill(COLORS["bg"])
        # Głęboki gradient laboratoryjny.
        for y in range(0, HEIGHT, 6):
            t = y / HEIGHT
            pulse = (math.sin(self.menu_time * .45 + t * 5) + 1) * .5
            color = (
                int(4 + 6 * t),
                int(8 + 14 * t + pulse * 2),
                int(20 + 25 * t + pulse * 4),
            )
            pygame.draw.rect(surface, color, (0, y, WIDTH, 6))
        # Siatka przepływu danych.
        offset = int(self.menu_time * 13) % 72
        grid_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for x in range(-72 + offset, WIDTH + 72, 72):
            pygame.draw.line(grid_layer, (57, 225, 255, 12), (x, 0), (x - 210, HEIGHT), 1)
        for y in range(-72 + offset, HEIGHT + 72, 72):
            pygame.draw.line(grid_layer, (164, 92, 255, 10), (0, y), (WIDTH, y + 80), 1)
        surface.blit(grid_layer, (0, 0))
        # Pulsujące komórki i połączenia przypominające sieć neuronową.
        nodes: list[tuple[int, int, int]] = []
        for i in range(24):
            x = int((i * 149 + math.sin(self.menu_time * .34 + i * .8) * 84) % (WIDTH + 160) - 80)
            y = int((i * 83 + self.menu_time * (5 + i % 4 * 2)) % (HEIGHT + 120) - 60)
            r = 4 + i % 4 * 3
            nodes.append((x, y, r))
        net = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i, (x, y, r) in enumerate(nodes):
            if i % 3 == 0:
                x2, y2, _ = nodes[(i + 5) % len(nodes)]
                pygame.draw.line(net, (65, 238, 158, 14), (x, y), (x2, y2), 1)
            pygame.draw.circle(net, (57, 225, 255, 25), (x, y), r + 5, width=1)
            pygame.draw.circle(net, (164, 92, 255, 38), (x, y), r)
        surface.blit(net, (0, 0))
        # Kolorystyczne obszary głębi.
        haze = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        pygame.draw.circle(haze, (164, 92, 255, 24), (1090, 80), 360)
        pygame.draw.circle(haze, (34, 205, 190, 20), (1160, 690), 300)
        pygame.draw.circle(haze, (57, 225, 255, 12), (300, 650), 260)
        surface.blit(haze, (0, 0))


    def handle_global_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.QUIT:
            self.running = False
            return True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
            self.save.data["settings"]["fullscreen"] = not bool(self.save.data["settings"]["fullscreen"])
            self.save.save(); self.apply_display_mode()
            return True
        return False

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            for event in pygame.event.get():
                if self.handle_global_event(event):
                    continue
                self.scene.handle_event(event)
            self.scene.update(dt)
            for toast in self.toasts:
                toast.update(dt)
            self.toasts = [t for t in self.toasts if not t.dead]
            self.scene.draw(self.screen)
            for i, toast in enumerate(self.toasts):
                toast.draw(self.screen, self.fonts["small_bold"], i)
            pygame.display.flip()
        self.save.save()
        pygame.quit()


def run_game() -> None:
    if getattr(sys, "frozen", False):
        root = Path(sys.executable).resolve().parent
        resources = Path(getattr(sys, "_MEIPASS", root))
    else:
        root = Path(__file__).resolve().parent.parent
        resources = root
    app = App(root, resources)
    app.run()

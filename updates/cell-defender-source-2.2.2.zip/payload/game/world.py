from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING

import pygame

from .data import COLORS, MAP_POWERS
from .ui import draw_progress
from .utils import draw_panel, draw_text, glow_circle

if TYPE_CHECKING:
    from .gameplay import GameplayScene


@dataclass
class ObjectiveCore:
    pos: pygame.Vector2
    index: int
    collected: bool = False
    age: float = 0.0
    radius: float = 24.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.collected:
            return
        if scene.any_player_near(self.pos, self.radius + 32):
            self.collected = True
            scene.collect_objective_core(self)

    def draw(self, surface: pygame.Surface, font: pygame.font.Font) -> None:
        if self.collected:
            return
        pulse = 1.0 + math.sin(self.age * 4.0) * 0.12
        radius = int(self.radius * pulse)
        glow_circle(surface, self.pos, radius, COLORS["cyan"], 4)
        pygame.draw.circle(surface, (14, 42, 62), self.pos, max(8, radius - 7))
        pygame.draw.circle(surface, COLORS["white"], self.pos, 5)
        draw_text(surface, font, "RDZEŃ", COLORS["cyan"], (int(self.pos.x), int(self.pos.y - 42)), "midbottom")


@dataclass
class ObjectiveBeacon:
    pos: pygame.Vector2
    index: int
    required: float
    charge: float = 0.0
    activated: bool = False
    age: float = 0.0
    wave_timer: float = 0.0
    radius: float = 78.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.activated or scene.objective_phase != "beacons":
            return
        inside = scene.any_player_near(self.pos, self.radius + 28)
        if inside:
            self.charge = min(self.required, self.charge + dt)
            self.wave_timer -= dt
            if self.wave_timer <= 0.0:
                scene.spawn_objective_wave(self.pos, 3 + self.index)
                self.wave_timer = 1.6
            if self.charge >= self.required:
                self.activated = True
                scene.activate_beacon(self)
        else:
            self.charge = max(0.0, self.charge - dt * 0.3)

    def draw(self, surface: pygame.Surface, small_font: pygame.font.Font, tiny_font: pygame.font.Font) -> None:
        color = COLORS["green"] if self.activated else COLORS["purple"]
        pulse = 1 + math.sin(self.age * 3.2 + self.index) * .08
        ring = int(self.radius * pulse)
        pygame.draw.circle(surface, (*color,), self.pos, ring, width=3)
        glow_circle(surface, self.pos, 25, color, 4)
        pygame.draw.circle(surface, COLORS["white"], self.pos, 6)
        draw_text(surface, small_font, f"WĘZEŁ {self.index}", color, (int(self.pos.x), int(self.pos.y - 55)), "midbottom")
        if not self.activated and self.charge > 0:
            rect = pygame.Rect(int(self.pos.x - 65), int(self.pos.y + 46), 130, 9)
            draw_progress(surface, rect, self.charge, self.required, COLORS["green"])
            draw_text(surface, tiny_font, f"{self.charge:.1f}/{self.required:.0f}s", COLORS["text"], (rect.centerx, rect.bottom + 4), "midtop")
        elif self.activated:
            draw_text(surface, tiny_font, "AKTYWNY", COLORS["green"], (int(self.pos.x), int(self.pos.y + 46)), "midtop")


@dataclass
class WorldPower:
    pos: pygame.Vector2
    key: str
    collected: bool = False
    age: float = 0.0
    radius: float = 22.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.collected:
            return
        if scene.any_player_near(self.pos, self.radius + 28):
            self.collected = True
            scene.collect_map_power(self)

    def draw(self, surface: pygame.Surface, small_font: pygame.font.Font, tiny_font: pygame.font.Font) -> None:
        if self.collected:
            return
        data = MAP_POWERS[self.key]
        color = data["color"]
        bob = math.sin(self.age * 3.8) * 5
        pos = pygame.Vector2(self.pos.x, self.pos.y + bob)
        glow_circle(surface, pos, self.radius, color, 4)
        pygame.draw.circle(surface, (18, 25, 45), pos, int(self.radius - 5))
        draw_text(surface, tiny_font, data["icon"], COLORS["white"], (int(pos.x), int(pos.y)), "center")
        draw_text(surface, small_font, data["name"], color, (int(pos.x), int(pos.y - 39)), "midbottom")


@dataclass
class WorldChest:
    pos: pygame.Vector2
    index: int
    opened: bool = False
    age: float = 0.0
    radius: float = 25.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.opened:
            return
        if scene.any_player_near(self.pos, self.radius + 32):
            self.opened = True
            scene.open_world_chest(self)

    def draw(self, surface: pygame.Surface, font: pygame.font.Font) -> None:
        if self.opened:
            return
        pulse = 1 + math.sin(self.age * 4 + self.index) * .05
        rect = pygame.Rect(0, 0, int(44 * pulse), int(34 * pulse))
        rect.center = (int(self.pos.x), int(self.pos.y))
        draw_panel(surface, rect, (55, 31, 12), COLORS["yellow"], 8, 245)
        pygame.draw.line(surface, COLORS["yellow"], (rect.x + 4, rect.centery), (rect.right - 4, rect.centery), 3)
        pygame.draw.circle(surface, COLORS["white"], rect.center, 3)
        draw_text(surface, font, "SKRZYNIA", COLORS["yellow"], (rect.centerx, rect.y - 8), "midbottom")


@dataclass
class ExtractionPortal:
    pos: pygame.Vector2
    unlocked: bool = False
    boss_started: bool = False
    extraction_progress: float = 0.0
    age: float = 0.0
    radius: float = 92.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if not self.unlocked:
            return
        inside = scene.any_player_near(self.pos, self.radius + 24)
        if not self.boss_started and inside:
            self.boss_started = True
            scene.start_final_boss(self.pos)
            return
        if self.boss_started and scene.final_boss_dead:
            if inside:
                self.extraction_progress = min(scene.extraction_time, self.extraction_progress + dt)
                if self.extraction_progress >= scene.extraction_time:
                    scene.end_run(True)
            else:
                self.extraction_progress = max(0.0, self.extraction_progress - dt * .6)

    def draw(self, surface: pygame.Surface, large_font: pygame.font.Font, tiny_font: pygame.font.Font, extraction_time: float) -> None:
        color = COLORS["green"] if self.unlocked else COLORS["line"]
        if self.boss_started and not self.unlocked:
            color = COLORS["red"]
        for i in range(3):
            angle = self.age * (.5 + i * .2) * (-1 if i % 2 else 1)
            points = []
            count = 12
            rr = self.radius - i * 17
            for step in range(count):
                a = angle + step * math.tau / count
                points.append((self.pos.x + math.cos(a) * rr, self.pos.y + math.sin(a) * rr * .62))
            pygame.draw.lines(surface, color, True, points, 3 if i == 0 else 2)
        glow_circle(surface, self.pos, 25, color, 4)
        label = "PORTAL ZABLOKOWANY"
        if self.unlocked and not self.boss_started:
            label = "WEJDŹ DO PORTALU"
        elif self.boss_started and not self.extraction_progress:
            label = "RDZEŃ INFEKCJI"
        elif self.extraction_progress > 0:
            label = "EKSTRAKCJA"
        draw_text(surface, large_font, label, color, (int(self.pos.x), int(self.pos.y - 122)), "midbottom")
        if self.extraction_progress > 0:
            rect = pygame.Rect(int(self.pos.x - 90), int(self.pos.y + 90), 180, 10)
            draw_progress(surface, rect, self.extraction_progress, extraction_time, COLORS["green"])
            draw_text(surface, tiny_font, f"Utrzymaj pozycję {self.extraction_progress:.1f}/{extraction_time:.0f}s", COLORS["text"], (rect.centerx, rect.bottom + 4), "midtop")


@dataclass
class RelicPickup:
    pos: pygame.Vector2
    key: str
    collected: bool = False
    age: float = 0.0
    radius: float = 24.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.collected:
            return
        if scene.any_player_near(self.pos, self.radius + 18):
            self.collected = True
            scene.collect_relic(self)

    def draw(self, surface: pygame.Surface, small_font: pygame.font.Font, tiny_font: pygame.font.Font) -> None:
        if self.collected:
            return
        from .content_expansion import RELICS
        data = RELICS[self.key]
        color = data["color"]
        bob = math.sin(self.age * 3.2) * 5
        pos = pygame.Vector2(self.pos.x, self.pos.y + bob)
        glow_circle(surface, pos, self.radius, color, 4)
        pygame.draw.polygon(surface, color, [
            (pos.x, pos.y - 17), (pos.x + 15, pos.y), (pos.x, pos.y + 17), (pos.x - 15, pos.y)
        ])
        pygame.draw.circle(surface, COLORS["white"], pos, 4)
        draw_text(surface, tiny_font, "RELIKT", color, (int(pos.x), int(pos.y - 39)), "midbottom")


@dataclass
class AnomalyNode:
    pos: pygame.Vector2
    key: str
    activated: bool = False
    age: float = 0.0
    radius: float = 48.0

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.activated:
            return
        if scene.any_player_near(self.pos, self.radius + 18):
            self.activated = True
            scene.trigger_anomaly(self)

    def draw(self, surface: pygame.Surface, small_font: pygame.font.Font, tiny_font: pygame.font.Font) -> None:
        if self.activated:
            return
        from .content_expansion import ANOMALIES
        data = ANOMALIES[self.key]
        color = data["color"]
        pulse = 1.0 + math.sin(self.age * 4.5) * .12
        r = int(self.radius * pulse)
        pygame.draw.circle(surface, color, self.pos, r, width=2)
        pygame.draw.circle(surface, (*color,), self.pos, max(8, r // 3), width=3)
        draw_text(surface, tiny_font, "ANOMALIA", color, (int(self.pos.x), int(self.pos.y - r - 8)), "midbottom")

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


async def protocol_test() -> None:
    from websockets.asyncio.client import connect
    async with connect("ws://127.0.0.1:9877") as host, connect("ws://127.0.0.1:9877") as guest:
        await host.send(json.dumps({"type": "create", "nickname": "Host"}))
        created = json.loads(await host.recv())
        assert created["type"] == "room_created"
        code = created["room"]
        await guest.send(json.dumps({"type": "join", "nickname": "Guest", "room": code}))
        joined = json.loads(await guest.recv())
        notice = json.loads(await host.recv())
        assert joined["type"] == "room_joined" and notice["type"] == "peer_joined"
        await host.send(json.dumps({"type": "start", "chapter": 1}))
        start = json.loads(await guest.recv())
        assert start["type"] == "start"
        await guest.send(json.dumps({"type": "input", "move": [1, 0]}))
        movement = json.loads(await host.recv())
        assert movement["type"] == "input" and movement["move"] == [1, 0]


def main() -> None:
    root = Path(__file__).resolve().parent
    proc = subprocess.Popen(
        [sys.executable, str(root / "server" / "relay_server.py"), "--host", "127.0.0.1", "--port", "9877"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        last_error = None
        for _ in range(30):
            try:
                with urllib.request.urlopen("http://127.0.0.1:9877/healthz", timeout=1) as response:
                    assert response.status == 200
                break
            except Exception as exc:
                last_error = exc
                time.sleep(0.2)
        else:
            raise RuntimeError(f"Serwer testowy nie wystartował: {last_error}")
        asyncio.run(protocol_test())
        print("[OK] HTTP, tworzenie pokoju, dołączanie, start i przesyłanie ruchu działają.")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()

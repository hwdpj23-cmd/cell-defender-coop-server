from __future__ import annotations

import asyncio
import json
import queue
import threading
import time
from dataclasses import dataclass
from typing import Any


@dataclass
class NetworkEvent:
    type: str
    data: dict[str, Any]


class NetworkClient:
    """Nieblokujący klient WebSocket zoptymalizowany pod rozgrywkę czasu rzeczywistego.

    Wiadomości czasu rzeczywistego (``input`` i ``snapshot``) nie mogą ustawiać się
    w kolejce. Przechowywana jest wyłącznie ich najnowsza wersja. Dzięki temu przy
    chwilowym skoku pingu klient nie odtwarza później starych klatek świata.
    Wiadomości niezawodne, np. utworzenie pokoju, start i umiejętność, pozostają w
    zwykłej kolejce FIFO.
    """

    COALESCED_TYPES = frozenset({"input", "snapshot"})

    def __init__(self, url: str):
        self.url = url.strip()
        self.incoming: queue.Queue[NetworkEvent] = queue.Queue(maxsize=600)
        self.outgoing: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=180)
        self.thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.connected = False
        self.last_error = ""
        self.latency_ms = 0.0
        self._ping_sent: dict[str, float] = {}

        self._latest_outgoing: dict[str, dict[str, Any]] = {}
        self._latest_incoming: dict[str, NetworkEvent] = {}
        self._outgoing_lock = threading.Lock()
        self._incoming_lock = threading.Lock()

        self.dropped_outgoing = 0
        self.dropped_incoming = 0
        self.bytes_sent = 0
        self.bytes_received = 0
        self.snapshot_rate = 0.0
        self._snapshot_count = 0
        self._snapshot_rate_started = time.monotonic()

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._thread_main, name="cell-defender-network", daemon=True)
        self.thread.start()

    def _thread_main(self) -> None:
        try:
            asyncio.run(self._run())
        except Exception as exc:  # pragma: no cover - zależy od sieci
            self.last_error = str(exc)
            self._put_reliable_incoming(NetworkEvent("error", {"message": str(exc)}))
        finally:
            self.connected = False
            self._put_reliable_incoming(NetworkEvent("disconnected", {}))

    def _put_reliable_incoming(self, event: NetworkEvent) -> None:
        try:
            self.incoming.put_nowait(event)
        except queue.Full:
            # Nie blokujemy wątku odbierającego. Najstarszy komunikat UI może zostać
            # pominięty, ale zdarzenia czasu rzeczywistego i tak są w osobnym slocie.
            try:
                self.incoming.get_nowait()
            except queue.Empty:
                pass
            try:
                self.incoming.put_nowait(event)
            except queue.Full:
                self.dropped_incoming += 1

    def _store_latest_incoming(self, event: NetworkEvent) -> None:
        with self._incoming_lock:
            if event.type in self._latest_incoming:
                self.dropped_incoming += 1
            self._latest_incoming[event.type] = event

    def _take_latest_outgoing(self) -> dict[str, Any] | None:
        # Input ma pierwszeństwo przed snapshotem, bo bezpośrednio wpływa na
        # responsywność sterowania drugiego gracza.
        with self._outgoing_lock:
            for message_type in ("input", "snapshot"):
                payload = self._latest_outgoing.pop(message_type, None)
                if payload is not None:
                    return payload
        return None

    async def _run(self) -> None:
        try:
            from websockets.asyncio.client import connect
        except ModuleNotFoundError as exc:
            raise RuntimeError("Brakuje biblioteki websockets. Uruchom ponownie START_GRY.cmd.") from exc

        async with connect(
            self.url,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=4,
            max_size=3_000_000,
            compression="deflate",
            max_queue=8,
        ) as websocket:
            self.connected = True
            self._put_reliable_incoming(NetworkEvent("connected", {}))

            async def sender() -> None:
                while not self.stop_event.is_set():
                    item: dict[str, Any] | None = None
                    try:
                        queued = self.outgoing.get_nowait()
                        if queued is None:
                            return
                        item = queued
                    except queue.Empty:
                        item = self._take_latest_outgoing()

                    if item is None:
                        await asyncio.sleep(0.0025)
                        continue

                    raw = json.dumps(item, separators=(",", ":"), ensure_ascii=False)
                    await websocket.send(raw)
                    self.bytes_sent += len(raw.encode("utf-8"))

            async def receiver() -> None:
                async for raw in websocket:
                    self.bytes_received += len(raw.encode("utf-8")) if isinstance(raw, str) else len(raw)
                    try:
                        payload = json.loads(raw)
                    except (TypeError, json.JSONDecodeError):
                        continue
                    message_type = str(payload.get("type", "message"))
                    if message_type == "pong":
                        token = str(payload.get("token", ""))
                        sent = self._ping_sent.pop(token, None)
                        if sent is not None:
                            sample = (time.monotonic() - sent) * 1000
                            # Lekko wygładzony ping nie skacze co kilka sekund.
                            self.latency_ms = sample if self.latency_ms <= 0 else self.latency_ms * .72 + sample * .28
                    event = NetworkEvent(message_type, payload)
                    if message_type in self.COALESCED_TYPES:
                        self._store_latest_incoming(event)
                        if message_type == "snapshot":
                            self._snapshot_count += 1
                            now = time.monotonic()
                            elapsed = now - self._snapshot_rate_started
                            if elapsed >= 1.0:
                                rate = self._snapshot_count / elapsed
                                self.snapshot_rate = rate if self.snapshot_rate <= 0 else self.snapshot_rate * .65 + rate * .35
                                self._snapshot_count = 0
                                self._snapshot_rate_started = now
                    else:
                        self._put_reliable_incoming(event)

            send_task = asyncio.create_task(sender())
            receive_task = asyncio.create_task(receiver())
            done, pending = await asyncio.wait(
                {send_task, receive_task}, return_when=asyncio.FIRST_COMPLETED
            )
            for task in pending:
                task.cancel()
            for task in done:
                if not task.cancelled():
                    task.result()

    def send(self, message_type: str, **data: Any) -> bool:
        if self.stop_event.is_set():
            return False
        payload = {"type": message_type, **data}
        if message_type in self.COALESCED_TYPES:
            with self._outgoing_lock:
                if message_type in self._latest_outgoing:
                    self.dropped_outgoing += 1
                self._latest_outgoing[message_type] = payload
            return True
        try:
            self.outgoing.put_nowait(payload)
            return True
        except queue.Full:
            return False

    def ping(self) -> None:
        token = f"{time.monotonic_ns()}"
        self._ping_sent[token] = time.monotonic()
        self.send("ping", token=token)

    def poll(self, limit: int = 100) -> list[NetworkEvent]:
        events: list[NetworkEvent] = []
        for _ in range(limit):
            try:
                events.append(self.incoming.get_nowait())
            except queue.Empty:
                break
        # W każdej klatce zwracamy co najwyżej jeden, zawsze najświeższy input i
        # snapshot. To jest główne zabezpieczenie przed narastającym opóźnieniem.
        with self._incoming_lock:
            for message_type in ("input", "snapshot"):
                event = self._latest_incoming.pop(message_type, None)
                if event is not None:
                    events.append(event)
        return events

    def close(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        with self._outgoing_lock:
            self._latest_outgoing.clear()
        try:
            self.outgoing.put_nowait(None)
        except queue.Full:
            try:
                self.outgoing.get_nowait()
                self.outgoing.put_nowait(None)
            except (queue.Empty, queue.Full):
                pass

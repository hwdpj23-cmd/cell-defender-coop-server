from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path

RATE = 44100
ROOT = Path(__file__).resolve().parent / "assets"
ROOT.mkdir(parents=True, exist_ok=True)


def write_wav(name: str, samples: list[float], stereo: bool = False) -> None:
    path = ROOT / name
    with wave.open(str(path), "wb") as out:
        out.setnchannels(2 if stereo else 1)
        out.setsampwidth(2)
        out.setframerate(RATE)
        frames = bytearray()
        for value in samples:
            v = max(-1.0, min(1.0, value))
            packed = struct.pack("<h", int(v * 32767))
            frames += packed + packed if stereo else packed
        out.writeframes(frames)


def tone(freq: float, duration: float, volume: float = .3, end_freq: float | None = None, noise: float = 0.0) -> list[float]:
    total = int(RATE * duration)
    result: list[float] = []
    for i in range(total):
        t = i / RATE
        p = i / max(1, total - 1)
        f = freq if end_freq is None else freq + (end_freq - freq) * p
        env = min(1.0, t / .012) * max(0.0, 1 - p) ** 1.8
        value = math.sin(math.tau * f * t) * volume
        value += math.sin(math.tau * f * .5 * t) * volume * .25
        value += random.uniform(-1, 1) * noise
        result.append(value * env)
    return result


def chord(freqs: list[float], duration: float, volume: float = .22) -> list[float]:
    total = int(RATE * duration)
    result = [0.0] * total
    for i in range(total):
        t = i / RATE
        p = i / max(1, total - 1)
        env = min(1.0, t / .025) * max(0.0, 1 - p) ** .8
        result[i] = sum(math.sin(math.tau * f * t) for f in freqs) / len(freqs) * volume * env
    return result


SFX = {
    "shoot.wav": tone(780, .08, .25, 340),
    "needle.wav": tone(1200, .09, .22, 780, .01),
    "bubble.wav": tone(190, .22, .28, 440),
    "laser.wav": tone(900, .16, .20, 1350),
    "pulse.wav": tone(145, .30, .30, 70, .015),
    "chain.wav": tone(1050, .22, .22, 260, .03),
    "hurt.wav": tone(170, .22, .32, 90, .04),
    "level.wav": chord([523.25, 659.25, 783.99], .62, .30),
    "boss.wav": chord([82.41, 103.83, 123.47], .78, .34),
    "boss_down.wav": chord([196, 246.94, 293.66, 392], .95, .34),
    "start.wav": chord([261.63, 329.63, 392], .72, .26),
    "victory.wav": chord([261.63, 329.63, 392, 523.25], 1.35, .32),
    "defeat.wav": chord([220, 207.65, 174.61], 1.1, .27),
    "click.wav": tone(650, .05, .18, 820),
}
for filename, samples in SFX.items():
    write_wav(filename, samples)

# Original, minimal ambient loop generated from simple oscillators.
seconds = 24
steps = [110.00, 130.81, 146.83, 164.81, 146.83, 130.81, 123.47, 98.00]
notes = [220.00, 261.63, 293.66, 329.63, 293.66, 261.63, 246.94, 196.00]
total = RATE * seconds
music: list[float] = [0.0] * total
beat = .375
for i in range(total):
    t = i / RATE
    step = int(t / beat) % len(steps)
    phase = (t % beat) / beat
    bass = math.sin(math.tau * steps[step] * t) * .09
    lead = math.sin(math.tau * notes[step] * t) * .035 * (1 - phase) ** .45
    pad = math.sin(math.tau * steps[step] * .5 * t) * .035
    kick_phase = t % (beat * 2)
    kick = math.sin(math.tau * (70 - 35 * min(1, kick_phase / .18)) * t) * .10 * max(0, 1 - kick_phase / .15)
    music[i] = (bass + lead + pad + kick) * .72
write_wav("music.wav", music, stereo=True)
print(f"Generated audio in {ROOT}")

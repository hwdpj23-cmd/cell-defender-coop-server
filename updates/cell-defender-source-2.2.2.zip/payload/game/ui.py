from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pygame

from .data import COLORS
from .utils import draw_panel, draw_text


_mouse_position_provider: Callable[[], tuple[int, int]] = pygame.mouse.get_pos


def set_mouse_position_provider(provider: Callable[[], tuple[int, int]]) -> None:
    """Ustawia dostawcę pozycji myszy w logicznych współrzędnych 1280x720."""
    global _mouse_position_provider
    _mouse_position_provider = provider


def get_mouse_position() -> tuple[int, int]:
    try:
        return _mouse_position_provider()
    except Exception:
        return (-10_000, -10_000)


@dataclass
class Button:
    rect: pygame.Rect
    text: str
    action: Callable[[], None]
    enabled: bool = True
    accent: tuple[int, int, int] = COLORS["purple"]
    secondary: bool = False
    small: bool = False

    def handle(self, event: pygame.event.Event) -> bool:
        if not self.enabled:
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.rect.collidepoint(event.pos):
            self.action()
            return True
        return False

    def draw(self, surface: pygame.Surface, font: pygame.font.Font) -> None:
        hovered = self.enabled and self.rect.collidepoint(get_mouse_position())
        if not self.enabled:
            fill = (45, 49, 66)
            border = (65, 70, 88)
            text_color = (120, 128, 150)
        elif self.secondary:
            fill = (30, 35, 58) if not hovered else (40, 47, 75)
            border = self.accent if hovered else (73, 83, 115)
            text_color = COLORS["text"]
        else:
            factor = 1.12 if hovered else 1.0
            fill = tuple(min(255, int(c * factor)) for c in self.accent)
            border = tuple(min(255, int(c * 1.15)) for c in self.accent)
            text_color = COLORS["white"]
        pygame.draw.rect(surface, fill, self.rect, border_radius=12)
        pygame.draw.rect(surface, border, self.rect, width=2, border_radius=12)
        draw_text(surface, font, self.text, text_color, self.rect.center, "center")


class Toast:
    def __init__(self, text: str, color: tuple[int, int, int], duration: float = 2.4):
        self.text = text
        self.color = color
        self.duration = duration
        self.age = 0.0

    @property
    def dead(self) -> bool:
        return self.age >= self.duration

    def update(self, dt: float) -> None:
        self.age += dt

    def draw(self, surface: pygame.Surface, font: pygame.font.Font, index: int) -> None:
        alpha = 255
        if self.age < 0.2:
            alpha = int(255 * self.age / 0.2)
        elif self.duration - self.age < 0.35:
            alpha = int(255 * max(0, self.duration - self.age) / 0.35)
        image = font.render(self.text, True, self.color)
        pad_x, pad_y = 18, 11
        rect = image.get_rect()
        box = pygame.Rect(0, 0, rect.width + pad_x * 2, rect.height + pad_y * 2)
        box.topright = (surface.get_width() - 24, 24 + index * 54)
        panel = pygame.Surface(box.size, pygame.SRCALPHA)
        pygame.draw.rect(panel, (*COLORS["panel2"], int(alpha * 0.94)), panel.get_rect(), border_radius=13)
        pygame.draw.rect(panel, (*self.color, alpha), panel.get_rect(), width=1, border_radius=13)
        image.set_alpha(alpha)
        panel.blit(image, (pad_x, pad_y))
        surface.blit(panel, box)


def draw_progress(surface: pygame.Surface, rect: pygame.Rect, value: float, maximum: float, color: tuple[int, int, int], background: tuple[int, int, int] = (31, 37, 59), border: tuple[int, int, int] = (64, 73, 105)) -> None:
    maximum = max(1e-6, maximum)
    ratio = max(0.0, min(1.0, value / maximum))
    pygame.draw.rect(surface, background, rect, border_radius=max(2, rect.height // 2))
    fill = rect.copy()
    fill.width = max(0, int(rect.width * ratio))
    if fill.width > 0:
        pygame.draw.rect(surface, color, fill, border_radius=max(2, rect.height // 2))
    pygame.draw.rect(surface, border, rect, width=1, border_radius=max(2, rect.height // 2))

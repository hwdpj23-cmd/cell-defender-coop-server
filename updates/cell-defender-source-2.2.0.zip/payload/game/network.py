from __future__ import annotations

import asyncio
import json
import queue
import threading
import time
from dataclasses import dataclass
from typing import Any


@dataclass
class NetworkEvent:
    type: str
    data: dict[str, Any]


class NetworkClient:
    """Klient WebSocket działający w osobnym wątku.

    Pygame pozostaje w głównym wątku, a komunikacja sieciowa nie blokuje FPS.
    """

    def __init__(self, url: str):
        self.url = url.strip()
        self.incoming: queue.Queue[NetworkEvent] = queue.Queue()
        self.outgoing: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=300)
        self.thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.connected = False
        self.last_error = ""
        self.latency_ms = 0.0
        self._ping_sent: dict[str, float] = {}

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._thread_main, name="cell-defender-network", daemon=True)
        self.thread.start()

    def _thread_main(self) -> None:
        try:
            asyncio.run(self._run())
        except Exception as exc:  # pragma: no cover - zależy od sieci
            self.last_error = str(exc)
            self.incoming.put(NetworkEvent("error", {"message": str(exc)}))
        finally:
            self.connected = False
            self.incoming.put(NetworkEvent("disconnected", {}))

    async def _run(self) -> None:
        try:
            from websockets.asyncio.client import connect
        except ModuleNotFoundError as exc:
            raise RuntimeError("Brakuje biblioteki websockets. Uruchom ponownie START_GRY.cmd.") from exc

        async with connect(
            self.url,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=4,
            max_size=2_000_000,
            compression="deflate",
        ) as websocket:
            self.connected = True
            self.incoming.put(NetworkEvent("connected", {}))

            async def sender() -> None:
                while not self.stop_event.is_set():
                    item = await asyncio.to_thread(self.outgoing.get)
                    if item is None:
                        return
                    await websocket.send(json.dumps(item, separators=(",", ":"), ensure_ascii=False))

            async def receiver() -> None:
                async for raw in websocket:
                    try:
                        payload = json.loads(raw)
                    except (TypeError, json.JSONDecodeError):
                        continue
                    if payload.get("type") == "pong":
                        token = str(payload.get("token", ""))
                        sent = self._ping_sent.pop(token, None)
                        if sent is not None:
                            self.latency_ms = (time.monotonic() - sent) * 1000
                    self.incoming.put(NetworkEvent(str(payload.get("type", "message")), payload))

            send_task = asyncio.create_task(sender())
            receive_task = asyncio.create_task(receiver())
            done, pending = await asyncio.wait(
                {send_task, receive_task}, return_when=asyncio.FIRST_COMPLETED
            )
            for task in pending:
                task.cancel()
            for task in done:
                if not task.cancelled():
                    task.result()

    def send(self, message_type: str, **data: Any) -> bool:
        if self.stop_event.is_set():
            return False
        payload = {"type": message_type, **data}
        try:
            self.outgoing.put_nowait(payload)
            return True
        except queue.Full:
            # Snapshoty mogą być pominięte; najnowszy stan zaraz je zastąpi.
            return False

    def ping(self) -> None:
        token = f"{time.monotonic_ns()}"
        self._ping_sent[token] = time.monotonic()
        self.send("ping", token=token)

    def poll(self, limit: int = 100) -> list[NetworkEvent]:
        events: list[NetworkEvent] = []
        for _ in range(limit):
            try:
                events.append(self.incoming.get_nowait())
            except queue.Empty:
                break
        return events

    def close(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        try:
            self.outgoing.put_nowait(None)
        except queue.Full:
            pass

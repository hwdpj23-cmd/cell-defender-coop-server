@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender 2.2.1 - Responsive UI Fix
color 0B

echo ============================================================
echo   CELL DEFENDER 2.2.1 - RESPONSIVE UI FIX
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Najpierw uruchom START_GRY.cmd, aby zainstalowac biblioteki.
    pause
    exit /b 1
)

echo [1/3] Budowanie nowego EXE...
call "%~dp0ZBUDUJ_EXE.cmd"
if errorlevel 1 goto :fail

echo [2/3] Tworzenie pakietow SOURCE i WINDOWS...
".venv\Scripts\python.exe" "release_tools\build_update.py" --version "2.2.1" --notes "Naprawiono skalowanie interfejsu, zachowanie proporcji, obsluge DPI 125/150 procent oraz nachodzace na siebie elementy menu."
if errorlevel 1 goto :fail

echo [3/3] Gotowe pliki do GitHuba.
echo Wgraj CALA zawartosc folderu DO_WGRANIA_NA_GITHUB.
start "" "%CD%\DO_WGRANIA_NA_GITHUB"
pause
exit /b 0

:fail
echo.
echo [BLAD] Budowanie aktualizacji nie powiodlo sie.
pause
exit /b 1

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender - Uruchamianie
color 0B

echo ============================================================
echo       CELL DEFENDER 2.1: CO-OP + AUTO UPDATE - START
echo ============================================================
echo.

set "PYTHON_CMD="
where py >nul 2>nul && set "PYTHON_CMD=py"
if not defined PYTHON_CMD where python >nul 2>nul && set "PYTHON_CMD=python"

if not defined PYTHON_CMD (
    echo [BLAD] Nie znaleziono Pythona.
    echo.
    echo Zainstaluj Python 3.11 lub nowszy z:
    echo https://www.python.org/downloads/windows/
    echo.
    echo Podczas instalacji zaznacz: Add Python to PATH
    echo.
    where winget >nul 2>nul
    if not errorlevel 1 (
        choice /C TN /M "Czy sprobowac zainstalowac Python automatycznie przez winget"
        if errorlevel 2 goto :fail
        winget install -e --id Python.Python.3.12
        echo.
        echo Po instalacji zamknij to okno i uruchom START_GRY.cmd ponownie.
    )
    goto :fail
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Tworzenie srodowiska gry...
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto :fail
)

set "VPY=.venv\Scripts\python.exe"

echo [2/3] Sprawdzanie bibliotek pygame i websockets...
%VPY% -c "import pygame, websockets" >nul 2>nul
if errorlevel 1 (
    echo Instalowanie wymaganych bibliotek. To moze chwile potrwac...
    %VPY% -m pip install --upgrade pip
    if errorlevel 1 goto :fail
    %VPY% -m pip install -r requirements.txt
    if errorlevel 1 goto :fail
)

echo [3/3] Uruchamianie gry...
echo.
%VPY% main.py
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo.
    echo [BLAD] Gra zakonczyla dzialanie z kodem %EXITCODE%.
    echo Sprawdz plik error.log w folderze gry.
    goto :fail
)
exit /b 0

:fail
echo.
echo Instalacja lub uruchomienie nie powiodlo sie.
echo Okno pozostanie otwarte, abys mogl zrobic zdjecie bledu.
pause
exit /b 1

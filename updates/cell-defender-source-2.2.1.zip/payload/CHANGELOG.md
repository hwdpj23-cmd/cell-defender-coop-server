# 2.2.1 — Responsive UI Fix

- Nowy system logicznego ekranu 1280×720 z zachowaniem proporcji.
- Koniec rozciągania UI przy zmianie rozmiaru okna i skalowaniu Windows 125/150%.
- Poprawione współrzędne myszy po przeskalowaniu.
- Przebudowany ekran kampanii bez nachodzących na siebie nagłówków.
- Większe odstępy w panelu aktywnej strefy i kartach rozdziałów.
- Zapamiętywanie rozmiaru okna oraz czarne pasy zamiast deformowania obrazu.

# Cell Defender — historia zmian

## 2.2.0 — Global Network Update

- Dodano publiczny chat globalny z historią wiadomości, licznikiem graczy online i zabezpieczeniem przed spamem.
- Przebudowano menu główne na nowe Centrum Dowodzenia z układem 3×2.
- Dodano 3 nowe rozdziały: Płuco skażenia, Synapsa burzy i Serce patogenu.
- Kampania ma teraz łącznie 6 rozdziałów.
- Maksymalny poziom każdej broni zwiększono z 6 do 8.
- Maksymalny poziom pasywnych mutacji zwiększono z 5 do 7.
- Rozszerzono listę bossów i odświeżono paletę interfejsu.
- Serwer Render obsługuje teraz CO-OP, aktualizacje i globalny chat jednocześnie.

# Changelog

## 2.0 — CO-OP Evolution

- dodano 432 elementy rozszerzenia zapisane w `CONTENT_MANIFEST.json`,
- dodano 120 genów, 80 reliktów i 48 synergii,
- dodano kontrakty, anomalie, klasy, wyzwania, biomy, mutacje bossów i osiągnięcia,
- dodano ekran wyboru klasy komórki i wyzwania,
- dodano dwuosobowy tryb online host-autorytatywny,
- dodano pokoje z sześci znakowym kodem,
- dodano osobny serwer relay WebSocket,
- dodano uruchamianie serwera na Windows, Dockerze i VPS,
- dodano synchronizację graczy, wrogów, pocisków, celów i stanu rozgrywki,
- dodano automatyczny atak partnera oraz aktywną falę wsparcia,
- dodano system odtwarzania pokonanego partnera,
- dodano osobne statystyki rozgrywek i zwycięstw online,
- rozszerzono testy o manifest zawartości i protokół sieciowy.

## 1.1 — Expedition Update

- duża przewijana mapa,
- główne cele ekspedycji,
- moce mapy, skrzynie i mini-mapa,
- wykładnicze skalowanie postaci i przeciwników.

## 2.1.0 — Prosty CO-OP i aktualizacje online

- publiczny adres Render ustawiony domyślnie,
- tworzenie pokoju jednym kliknięciem,
- automatyczne kopiowanie kodu pokoju,
- przyciski wklejania kodu i adresu oraz obsługa Ctrl+V/prawego przycisku,
- automatyczne ponawianie połączenia podczas budzenia darmowego serwera,
- serwer aiohttp obsługujący jednocześnie HTTP, WebSocket i pliki aktualizacji,
- ekran aktualizacji w grze,
- pobieranie z paskiem postępu i kontrolą SHA-256,
- kopia zapasowa starej wersji, zachowanie zapisów i automatyczny restart,
- kreator publikowania aktualizacji na GitHub/Render.

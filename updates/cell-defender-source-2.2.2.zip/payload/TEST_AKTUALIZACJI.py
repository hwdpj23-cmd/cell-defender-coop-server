from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent
    manifest_path = root / "server" / "updates" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest.get("version"), "Brak wersji w manifest.json"
    packages = manifest.get("packages", {})
    assert "source" in packages, "Brak pakietu source"
    for name, info in packages.items():
        path = root / "server" / str(info["url"]).lstrip("/")
        assert path.exists(), f"Brak pliku pakietu: {path}"
        assert path.stat().st_size == int(info["size"]), f"Zły rozmiar pakietu {name}"
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == info["sha256"], f"Zła suma SHA-256 pakietu {name}"
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            assert names and all(".." not in Path(item).parts for item in names)
            assert any(item.startswith("payload/game/") for item in names)
            assert not any(item.startswith("payload/data/") for item in names)
    print("[OK] Manifest, rozmiary, SHA-256 i struktura pakietów aktualizacji są poprawne.")


if __name__ == "__main__":
    main()

from __future__ import annotations

"""Duży, data-driven pakiet zawartości dla Cell Defender 2.0.

Większość wpisów korzysta z wspólnego systemu efektów. Dzięki temu każdy wpis
jest faktycznie używalny w grze, a projekt nie wymaga setek prawie identycznych
funkcji. Manifest na końcu modułu pozwala łatwo sprawdzić liczbę dodatków.
"""

from dataclasses import dataclass
from typing import Any


COLORS = [
    (67, 226, 255), (174, 85, 255), (255, 80, 190), (79, 235, 143),
    (255, 214, 91), (255, 142, 66), (67, 123, 255), (255, 82, 103),
]

EFFECT_FAMILIES: list[tuple[str, str, str, float, float]] = [
    ("damage_mul", "Siła", "obrażeń", 1.05, 0.014),
    ("fire_rate_mul", "Tempo", "szybkości ataku", 1.04, 0.012),
    ("speed_mul", "Napęd", "szybkości ruchu", 1.025, 0.009),
    ("max_hp_mul", "Błona", "maksymalnego HP", 1.06, 0.016),
    ("pickup_mul", "Chemotaksja", "zasięgu zbierania", 1.07, 0.018),
    ("xp_mul", "Pamięć", "zdobywanego XP", 1.08, 0.022),
    ("regen_add", "Autofagia", "regeneracji HP/s", 0.20, 0.07),
    ("armor_add", "Lipid", "pancerza", 0.015, 0.004),
    ("luck_add", "Adaptacja", "szczęścia", 0.012, 0.004),
    ("crit_damage_mul", "Pęknięcie", "obrażeń krytycznych", 1.08, 0.025),
    ("boss_damage_mul", "Egzekutor", "obrażeń bossom", 1.08, 0.022),
    ("elite_damage_mul", "Łowca", "obrażeń elitom", 1.08, 0.022),
]

PREFIXES = [
    "Neonowa", "Kwantowa", "Omega", "Nadaktywna", "Krystaliczna",
    "Symbiotyczna", "Pradawna", "Rezonansowa", "Plazmowa", "Kosmiczna",
]


def _make_augments() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for family_index, (effect, noun, subject, base, step) in enumerate(EFFECT_FAMILIES):
        for tier, prefix in enumerate(PREFIXES, start=1):
            idx += 1
            key = f"gene_{idx:03d}"
            value = base + step * (tier - 1)
            if effect.endswith("_mul"):
                desc_value = f"+{(value - 1) * 100:.0f}%"
            elif effect in {"armor_add", "luck_add"}:
                desc_value = f"+{value * 100:.1f} pp"
            else:
                desc_value = f"+{value:.2f}"
            result[key] = {
                "name": f"{prefix} {noun}",
                "description": f"{desc_value} {subject}.",
                "effect": effect,
                "value": round(value, 5),
                "tier": tier,
                "color": COLORS[(family_index + tier) % len(COLORS)],
            }
    return result


GENE_AUGMENTS = _make_augments()  # 120

RELIC_NOUNS = [
    "Jądro Pulsaru", "Pieczęć Makrofaga", "Ząb Wirusa", "Kropla Limfy",
    "Rdzeń Enzymu", "Węzeł Chromatyny", "Igła Sygnałowa", "Pancerz Archeona",
    "Oko Cytokiny", "Kryształ ATP", "Fragment Telomeru", "Serce Organeli",
    "Korona Receptora", "Echo Mitozy", "Przekaźnik Nerwowy", "Kokon Lipidowy",
]
RELIC_PREFIXES = ["Stabilny", "Nasycony", "Żarłoczny", "Wieczny", "Dziki"]
RELIC_EFFECTS = [
    ("damage_mul", 1.12), ("fire_rate_mul", 1.10), ("speed_mul", 1.08),
    ("max_hp_mul", 1.15), ("pickup_mul", 1.20), ("xp_mul", 1.18),
    ("regen_add", 0.75), ("armor_add", 0.035), ("luck_add", 0.03),
    ("crit_damage_mul", 1.18), ("boss_damage_mul", 1.22), ("elite_damage_mul", 1.22),
    ("extra_projectiles", 1), ("lifesteal", 0.006), ("cooldown_mul", 0.93),
    ("projectile_size_mul", 1.16),
]


def _make_relics() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for prefix_index, prefix in enumerate(RELIC_PREFIXES):
        for noun_index, noun in enumerate(RELIC_NOUNS):
            idx += 1
            effect, base = RELIC_EFFECTS[noun_index % len(RELIC_EFFECTS)]
            scale = 1 + prefix_index * 0.18
            value = base
            if effect.endswith("_mul"):
                value = 1 + (base - 1) * scale
            elif effect == "extra_projectiles":
                value = 1 if prefix_index < 4 else 2
            else:
                value = base * scale
            result[f"relic_{idx:03d}"] = {
                "name": f"{prefix} {noun}",
                "description": f"Relikt wzmacnia parametr: {effect.replace('_', ' ')}.",
                "effect": effect,
                "value": round(value, 5),
                "rarity": 1 + prefix_index,
                "color": COLORS[(noun_index + prefix_index) % len(COLORS)],
            }
    return result


RELICS = _make_relics()  # 80

WEAPON_KEYS = ["capsule", "needles", "bubble", "enzyme", "drone", "pulse", "chain", "mine"]
PASSIVE_KEYS = ["power", "haste", "vitality", "speed", "magnet", "armor", "regen", "luck"]
SYNERGY_NAMES = [
    "Burza Cytokin", "Pętla ATP", "Reaktor Przeciwciał", "Kaskada Enzymów",
    "Szczepionka Omega", "Rój Leukocytów", "Próżnia Osmotyczna", "Fala Mitozy",
]


def _make_synergies() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for w_i, weapon in enumerate(WEAPON_KEYS):
        for p_i in range(6):
            passive = PASSIVE_KEYS[(w_i + p_i) % len(PASSIVE_KEYS)]
            idx += 1
            effect = ["damage_mul", "fire_rate_mul", "projectile_size_mul", "boss_damage_mul"][p_i % 4]
            value = [1.25, 1.18, 1.22, 1.35][p_i % 4]
            result[f"synergy_{idx:03d}"] = {
                "name": f"{SYNERGY_NAMES[w_i]}: {p_i + 1}",
                "weapon": weapon,
                "passive": passive,
                "required_weapon": 3 + (p_i % 3),
                "required_passive": 2 + (p_i % 2),
                "effect": effect,
                "value": value,
                "description": "Automatyczna ewolucja odblokowana przez połączenie broni i mutacji.",
                "color": COLORS[(w_i + p_i) % len(COLORS)],
            }
    return result


SYNERGIES = _make_synergies()  # 48

CONTRACT_TYPES = ["kill", "elite", "dna", "survive", "travel", "boss_damage", "chests", "powers"]
CONTRACT_NAMES = [
    "Czystka", "Polowanie Alfa", "Zbiór Genomu", "Próba Wytrzymałości",
    "Długi Marsz", "Rozbicie Tytana", "Łupieżca Organelli", "Badacz Anomalii",
]


def _make_contracts() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for type_index, ctype in enumerate(CONTRACT_TYPES):
        for tier in range(1, 6):
            idx += 1
            base_targets = {"kill": 75, "elite": 4, "dna": 6, "survive": 45, "travel": 1600,
                            "boss_damage": 700, "chests": 2, "powers": 2}
            target = int(base_targets[ctype] * (1 + (tier - 1) * .65))
            result[f"contract_{idx:03d}"] = {
                "name": f"{CONTRACT_NAMES[type_index]} {['I','II','III','IV','V'][tier-1]}",
                "type": ctype,
                "target": target,
                "reward_dna": 2 + tier * 2,
                "reward_xp": 30 + tier * 35,
                "description": f"Wykonaj cel typu {ctype} na poziomie trudności {tier}.",
                "tier": tier,
            }
    return result


CONTRACTS = _make_contracts()  # 40

ANOMALY_NAMES = [
    "Deszcz ATP", "Cisza Cytoplazmy", "Krwawe Echo", "Nadmiar Tlenu",
    "Wybuch Mitozy", "Migotanie Błony", "Skażony Gradient", "Złoty Genom",
]
ANOMALY_EFFECTS = ["xp_burst", "heal", "enemy_wave", "speed_boost", "damage_boost", "dna_burst", "time_slow", "relic"]


def _make_anomalies() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for effect_index, effect in enumerate(ANOMALY_EFFECTS):
        for tier in range(1, 5):
            idx += 1
            result[f"anomaly_{idx:03d}"] = {
                "name": f"{ANOMALY_NAMES[effect_index]} {tier}",
                "effect": effect,
                "power": tier,
                "description": f"Jednorazowe wydarzenie mapy: {effect.replace('_', ' ')}.",
                "color": COLORS[(effect_index + tier) % len(COLORS)],
            }
    return result


ANOMALIES = _make_anomalies()  # 32

CLASS_ARCHETYPES = [
    ("Strażnik", "max_hp_mul", 1.22, "pulse"),
    ("Łowca", "damage_mul", 1.18, "capsule"),
    ("Przekaźnik", "fire_rate_mul", 1.16, "chain"),
    ("Kurierz", "speed_mul", 1.15, "needles"),
    ("Zbieracz", "xp_mul", 1.22, "bubble"),
    ("Regenerator", "regen_add", 1.0, "enzyme"),
]
CLASS_PREFIXES = ["Neonowy", "Omega", "Kwantowy", "Pradawny"]


def _make_classes() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for prefix_index, prefix in enumerate(CLASS_PREFIXES):
        for archetype_index, (name, effect, value, weapon) in enumerate(CLASS_ARCHETYPES):
            idx += 1
            scaled = value
            if effect.endswith("_mul"):
                scaled = 1 + (value - 1) * (1 + prefix_index * .18)
            else:
                scaled = value * (1 + prefix_index * .2)
            result[f"class_{idx:02d}"] = {
                "name": f"{prefix} {name}",
                "effect": effect,
                "value": round(scaled, 5),
                "starting_weapon": WEAPON_KEYS[(WEAPON_KEYS.index(weapon) + prefix_index) % len(WEAPON_KEYS)],
                "description": "Specjalizacja startowa z własnym bonusem i bronią.",
                "color": COLORS[(prefix_index + archetype_index) % len(COLORS)],
            }
    return result


CELL_CLASSES = _make_classes()  # 24

CHALLENGE_BASE = [
    ("Szklana Błona", "player_hp_mul", .65, 1.35),
    ("Hiperinfekcja", "enemy_count_mul", 1.45, 1.30),
    ("Twarde Zarazki", "enemy_hp_mul", 1.40, 1.30),
    ("Pośpiech", "enemy_speed_mul", 1.25, 1.22),
    ("Głód DNA", "drop_mul", .65, 1.32),
    ("Mutacja Bossów", "boss_hp_mul", 1.55, 1.35),
]
CHALLENGE_PREFIXES = ["I", "II", "III", "OMEGA"]


def _make_challenges() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for tier, suffix in enumerate(CHALLENGE_PREFIXES, start=1):
        for base_index, (name, effect, value, reward) in enumerate(CHALLENGE_BASE):
            idx += 1
            if value >= 1:
                scaled = 1 + (value - 1) * (1 + (tier - 1) * .35)
            else:
                scaled = max(.25, value - (tier - 1) * .08)
            result[f"challenge_{idx:02d}"] = {
                "name": f"{name} {suffix}",
                "effect": effect,
                "value": round(scaled, 4),
                "reward_mul": round(reward + (tier - 1) * .18, 3),
                "description": "Opcjonalny modyfikator ekspedycji zwiększający nagrody.",
                "color": COLORS[(base_index + tier) % len(COLORS)],
            }
    return result


CHALLENGES = _make_challenges()  # 24

BIOME_NAMES = [
    "Arteria Rubinowa", "Morze Limfy", "Pole Synaps", "Jaskinia Szpiku",
    "Las Rzęsek", "Pustynia Lipidowa", "Komora Serca", "Strefa Nekrozy",
    "Labirynt Chromatyny", "Zatoka Enzymów", "Próg Mitozy", "Mgławica ATP",
    "Korytarz Receptorów", "Ogród Organeli", "Szczelina Osmotyczna", "Rdzeń Omega",
]


def _make_biomes() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for idx, name in enumerate(BIOME_NAMES, start=1):
        result[f"biome_{idx:02d}"] = {
            "name": name,
            "enemy_hp_mul": round(0.92 + (idx % 5) * .06, 3),
            "enemy_speed_mul": round(0.94 + (idx % 4) * .045, 3),
            "xp_mul": round(1.0 + (idx % 6) * .035, 3),
            "color": COLORS[idx % len(COLORS)],
            "description": "Proceduralna strefa mapy z własnym balansem i atmosferą.",
        }
    return result


BIOMES = _make_biomes()  # 16

BOSS_MUTATION_NAMES = [
    "Kolczasty", "Wampiryczny", "Teleportujący", "Rozszczepiony", "Pancerny",
    "Przyspieszony", "Toksyczny", "Regenerujący", "Mroźny", "Łańcuchowy",
    "Eksplozywny", "Cieniowy", "Kwantowy", "Rojowy", "Odbijający", "Omega",
]


def _make_boss_mutations() -> dict[str, dict[str, Any]]:
    effects = ["hp", "lifesteal", "teleport", "split", "armor", "speed", "poison", "regen",
               "slow", "chain", "explode", "clone", "phase", "summon", "reflect", "all"]
    result: dict[str, dict[str, Any]] = {}
    for idx, (name, effect) in enumerate(zip(BOSS_MUTATION_NAMES, effects), start=1):
        result[f"boss_mut_{idx:02d}"] = {
            "name": name,
            "effect": effect,
            "power": 1 + idx / 16,
            "description": "Losowa mutacja zmieniająca zachowanie i statystyki bossa.",
            "color": COLORS[idx % len(COLORS)],
        }
    return result


BOSS_MUTATIONS = _make_boss_mutations()  # 16

ACHIEVEMENT_VERBS = ["Pokonaj", "Zbierz", "Przetrwaj", "Odkryj", "Ulepsz", "Aktywuj", "Ocal", "Zdominuj"]
ACHIEVEMENT_TARGETS = ["wirusy", "DNA", "sekundy", "relikty"]


def _make_achievements() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    idx = 0
    for verb_index, verb in enumerate(ACHIEVEMENT_VERBS):
        for target_index, target in enumerate(ACHIEVEMENT_TARGETS):
            idx += 1
            threshold = (verb_index + 1) * (target_index + 2) * 25
            result[f"achievement_{idx:03d}"] = {
                "name": f"{verb} {target} {idx}",
                "metric": ["kills", "dna", "seconds", "relics"][target_index],
                "threshold": threshold,
                "reward_dna": 1 + idx // 8,
                "description": "Osiągnięcie ekspedycyjne zapisywane w profilu.",
            }
    return result


ACHIEVEMENTS = _make_achievements()  # 32

CONTENT_GROUPS: dict[str, dict[str, dict[str, Any]]] = {
    "gene_augments": GENE_AUGMENTS,
    "relics": RELICS,
    "synergies": SYNERGIES,
    "contracts": CONTRACTS,
    "anomalies": ANOMALIES,
    "cell_classes": CELL_CLASSES,
    "challenges": CHALLENGES,
    "biomes": BIOMES,
    "boss_mutations": BOSS_MUTATIONS,
    "achievements": ACHIEVEMENTS,
}


def content_counts() -> dict[str, int]:
    counts = {name: len(items) for name, items in CONTENT_GROUPS.items()}
    counts["total"] = sum(counts.values())
    return counts


def serializable_manifest() -> dict[str, Any]:
    return {
        "version": "2.0",
        "counts": content_counts(),
        "groups": {
            name: [
                {"id": key, **{k: v for k, v in data.items() if k != "color"}}
                for key, data in items.items()
            ]
            for name, items in CONTENT_GROUPS.items()
        },
    }

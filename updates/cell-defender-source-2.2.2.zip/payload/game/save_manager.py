from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

from .data import DEFAULT_SAVE, SAVE_VERSION


def _merge_defaults(default: Any, loaded: Any) -> Any:
    if isinstance(default, dict):
        result = copy.deepcopy(default)
        if isinstance(loaded, dict):
            for key, value in loaded.items():
                if key in result:
                    result[key] = _merge_defaults(result[key], value)
                else:
                    result[key] = value
        return result
    return loaded if loaded is not None else copy.deepcopy(default)


class SaveManager:
    def __init__(self, root: Path):
        self.root = root
        self.data_dir = root / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / "save.json"
        self.data = self.load()

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return copy.deepcopy(DEFAULT_SAVE)
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            data = _merge_defaults(DEFAULT_SAVE, loaded)
            data["version"] = SAVE_VERSION
            return data
        except (OSError, json.JSONDecodeError, TypeError):
            try:
                backup = self.path.with_suffix(".broken.json")
                self.path.replace(backup)
            except OSError:
                pass
            return copy.deepcopy(DEFAULT_SAVE)

    def save(self) -> None:
        self.data["version"] = SAVE_VERSION
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def reset(self) -> None:
        self.data = copy.deepcopy(DEFAULT_SAVE)
        self.save()

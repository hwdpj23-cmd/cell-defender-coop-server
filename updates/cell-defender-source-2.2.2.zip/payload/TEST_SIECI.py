from __future__ import annotations

import asyncio
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


async def recv_json(ws, timeout: float = 2.0) -> dict:
    return json.loads(await asyncio.wait_for(ws.recv(), timeout))


async def collect_messages(ws, duration: float = .35) -> list[dict]:
    result: list[dict] = []
    end = asyncio.get_running_loop().time() + duration
    while True:
        remaining = end - asyncio.get_running_loop().time()
        if remaining <= 0:
            return result
        try:
            result.append(json.loads(await asyncio.wait_for(ws.recv(), min(.08, remaining))))
        except asyncio.TimeoutError:
            pass


async def protocol_test() -> None:
    from websockets.asyncio.client import connect
    async with connect("ws://127.0.0.1:9877") as host, connect("ws://127.0.0.1:9877") as guest:
        await host.send(json.dumps({"type": "create", "nickname": "Host"}))
        created = await recv_json(host)
        assert created["type"] == "room_created"
        code = created["room"]
        await guest.send(json.dumps({"type": "join", "nickname": "Guest", "room": code}))
        joined = await recv_json(guest)
        notice = await recv_json(host)
        assert joined["type"] == "room_joined" and notice["type"] == "peer_joined"
        await host.send(json.dumps({"type": "start", "chapter": 1}))
        start = await recv_json(guest)
        assert start["type"] == "start"

        # 100 stanów wysłanych naraz nie może później odtwarzać się przez kilka
        # sekund u gościa. Serwer powinien dostarczyć niewiele paczek i zakończyć
        # na najnowszym numerze 100.
        for seq in range(1, 101):
            await host.send(json.dumps({"type": "snapshot", "state": {"seq": seq}}))
        snapshots = [m for m in await collect_messages(guest) if m.get("type") == "snapshot"]
        assert snapshots and snapshots[-1]["state"]["seq"] == 100
        assert len(snapshots) < 20

        # Tak samo dla sterowania: host potrzebuje najnowszego kierunku, a nie
        # kolejki starych poleceń.
        for seq in range(1, 101):
            await guest.send(json.dumps({"type": "input", "seq": seq, "move": [1, 0]}))
        inputs = [m for m in await collect_messages(host) if m.get("type") == "input"]
        assert inputs and inputs[-1]["seq"] == 100
        assert len(inputs) < 20


def main() -> None:
    root = Path(__file__).resolve().parent
    proc = subprocess.Popen(
        [sys.executable, str(root / "server" / "relay_server.py"), "--host", "127.0.0.1", "--port", "9877"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        last_error = None
        for _ in range(30):
            try:
                with urllib.request.urlopen("http://127.0.0.1:9877/healthz", timeout=1) as response:
                    assert response.status == 200
                break
            except Exception as exc:
                last_error = exc
                time.sleep(0.2)
        else:
            raise RuntimeError(f"Serwer testowy nie wystartował: {last_error}")
        asyncio.run(protocol_test())
        print("[OK] Pokój, start oraz usuwanie zaległych snapshotów i inputów działają.")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()

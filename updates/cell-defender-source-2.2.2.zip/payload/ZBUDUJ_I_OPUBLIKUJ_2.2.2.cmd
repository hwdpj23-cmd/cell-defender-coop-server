@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cell Defender 2.2.2 - CO-OP Lag Fix
color 0B

echo ============================================================
echo   CELL DEFENDER 2.2.2 - CO-OP SMOOTH NETWORK FIX
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Najpierw uruchom START_GRY.cmd, aby zainstalowac biblioteki.
    pause
    exit /b 1
)

echo [1/3] Budowanie nowego EXE...
call "%~dp0ZBUDUJ_EXE.cmd"
if errorlevel 1 goto :fail

echo [2/3] Tworzenie paczek aktualizacji...
".venv\Scripts\python.exe" "release_tools\build_update.py" --version "2.2.2" --notes "Naprawiono opoznienia CO-OP: przewidywanie ruchu goscia, interpolacja, odrzucanie starych snapshotow, mniejsze paczki i szybsza synchronizacja." --windows-release-url "https://github.com/hwdpj23-cmd/cell-defender-coop-server/releases/download/v2.2.2/cell-defender-windows-2.2.2.zip" --exclude-windows-from-export
if errorlevel 1 goto :fail

echo [3/3] Gotowe.
echo.
echo 1. Folder DO_WGRANIA_NA_GITHUB wgraj do repozytorium serwera.
echo 2. Plik z DO_WGRANIA_NA_RELEASE wgraj jako Asset w Release v2.2.2.
start "" "%CD%\DO_WGRANIA_NA_GITHUB"
start "" "%CD%\DO_WGRANIA_NA_RELEASE"
pause
exit /b 0

:fail
echo.
echo [BLAD] Budowanie aktualizacji nie powiodlo sie.
pause
exit /b 1

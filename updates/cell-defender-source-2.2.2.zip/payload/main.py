from __future__ import annotations

import sys
import traceback
from pathlib import Path


def main() -> int:
    try:
        from game.app import run_game
        run_game()
        return 0
    except ModuleNotFoundError as exc:
        if exc.name in {"pygame", "websockets"}:
            print(f"Brakuje biblioteki {exc.name}. Uruchom START_GRY.cmd, aby ją zainstalować.")
            return 2
        raise
    except Exception:
        root = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
        log = root / "error.log"
        details = traceback.format_exc()
        try:
            log.write_text(details, encoding="utf-8")
        except OSError:
            pass
        print("Gra napotkała błąd. Szczegóły zapisano w error.log")
        print(details)
        return 1


if __name__ == "__main__":
    sys.exit(main())

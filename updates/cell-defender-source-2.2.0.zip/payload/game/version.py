from __future__ import annotations

GAME_VERSION = "2.2.0"
DEFAULT_WS_SERVER = "wss://cell-defender-coop.onrender.com"
DEFAULT_HTTP_SERVER = "https://cell-defender-coop.onrender.com"
UPDATE_API_PATH = "/api/update"

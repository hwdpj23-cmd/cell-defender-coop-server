from __future__ import annotations

import math
import random
from typing import Iterable

import pygame


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def vec_from_angle(angle: float) -> pygame.Vector2:
    return pygame.Vector2(math.cos(angle), math.sin(angle))


def angle_between(a: pygame.Vector2, b: pygame.Vector2) -> float:
    return math.atan2(b.y - a.y, b.x - a.x)


def format_number(value: float) -> str:
    negative = value < 0
    value = abs(value)
    units = ["", "K", "M", "B", "T", "Qa", "Qi"]
    index = 0
    while value >= 1000 and index < len(units) - 1:
        value /= 1000.0
        index += 1
    if index == 0:
        text = f"{int(value)}"
    elif value >= 100:
        text = f"{value:.0f}{units[index]}"
    elif value >= 10:
        text = f"{value:.1f}{units[index]}"
    else:
        text = f"{value:.2f}{units[index]}"
    return f"-{text}" if negative else text


def draw_text(surface: pygame.Surface, font: pygame.font.Font, text: str, color: tuple[int, int, int], pos: tuple[float, float], anchor: str = "topleft") -> pygame.Rect:
    image = font.render(text, True, color)
    rect = image.get_rect()
    setattr(rect, anchor, (int(pos[0]), int(pos[1])))
    surface.blit(image, rect)
    return rect


def draw_panel(surface: pygame.Surface, rect: pygame.Rect, color: tuple[int, int, int], border: tuple[int, int, int], radius: int = 18, alpha: int = 245) -> None:
    panel = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(panel, (*color, alpha), panel.get_rect(), border_radius=radius)
    pygame.draw.rect(panel, (*border, min(255, alpha + 10)), panel.get_rect(), width=1, border_radius=radius)
    surface.blit(panel, rect)


def glow_circle(surface: pygame.Surface, center: tuple[float, float], radius: float, color: tuple[int, int, int], strength: int = 4) -> None:
    r = max(2, int(radius))
    size = r * 4
    glow = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    for i in range(strength, 0, -1):
        rr = int(r * (1 + i * 0.35))
        alpha = int(18 * (strength - i + 1))
        pygame.draw.circle(glow, (*color, alpha), (c, c), rr)
    pygame.draw.circle(glow, (*color, 220), (c, c), r)
    surface.blit(glow, (center[0] - c, center[1] - c))


def weighted_choice(items: Iterable[tuple[object, float]]) -> object:
    pairs = list(items)
    total = sum(weight for _, weight in pairs)
    roll = random.random() * total
    cursor = 0.0
    for item, weight in pairs:
        cursor += weight
        if roll <= cursor:
            return item
    return pairs[-1][0]

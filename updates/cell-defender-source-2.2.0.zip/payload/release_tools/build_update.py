from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UPDATES = ROOT / "server" / "updates"
EXPORT = ROOT / "DO_WGRANIA_NA_GITHUB"
VERSION_FILE = ROOT / "game" / "version.py"

SKIP_DIRS = {
    ".venv", "data", "update_cache", "backups", "build", "dist",
    "__pycache__", ".git", "DO_WGRANIA_NA_GITHUB",
}
SKIP_SUFFIXES = {".pyc", ".pyo", ".log", ".part"}
SKIP_FILES = {"server_start_log.txt", "error.log"}


def update_version(version: str) -> None:
    text = VERSION_FILE.read_text(encoding="utf-8")
    lines = []
    changed = False
    for line in text.splitlines():
        if line.startswith("GAME_VERSION ="):
            lines.append(f'GAME_VERSION = "{version}"')
            changed = True
        else:
            lines.append(line)
    if not changed:
        raise RuntimeError("Nie znaleziono GAME_VERSION w game/version.py")
    VERSION_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def should_include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if len(rel.parts) >= 2 and rel.parts[0] == "server" and rel.parts[1] == "updates":
        return False
    if path.name in SKIP_FILES or path.suffix.lower() in SKIP_SUFFIXES:
        return False
    return path.is_file()


def zip_source(version: str) -> Path:
    target = UPDATES / f"cell-defender-source-{version}.zip"
    target.unlink(missing_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for path in sorted(ROOT.rglob("*")):
            if should_include(path):
                rel = path.relative_to(ROOT).as_posix()
                archive.write(path, f"payload/{rel}")
    return target


def zip_windows(version: str) -> Path | None:
    dist = ROOT / "dist" / "Cell_Defender"
    if not (dist / "Cell_Defender.exe").exists():
        return None
    target = UPDATES / f"cell-defender-windows-{version}.zip"
    target.unlink(missing_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for path in sorted(dist.rglob("*")):
            if path.is_file():
                archive.write(path, f"payload/{path.relative_to(dist).as_posix()}")
    return target


def metadata(path: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "url": f"/updates/{path.name}",
        "sha256": digest.hexdigest(),
        "size": path.stat().st_size,
    }


def export_server_files() -> None:
    if EXPORT.exists():
        shutil.rmtree(EXPORT)
    (EXPORT / "updates").mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "server" / "relay_server.py", EXPORT / "relay_server.py")
    shutil.copy2(ROOT / "server" / "requirements.txt", EXPORT / "requirements.txt")
    for path in UPDATES.iterdir():
        if path.is_file() and path.suffix.lower() in {".zip", ".json"}:
            shutil.copy2(path, EXPORT / "updates" / path.name)
    (EXPORT / "README_UPLOAD.txt").write_text(
        "Wgraj relay_server.py, requirements.txt i caly folder updates do glownego katalogu repozytorium GitHub.\n"
        "Render wykona automatyczny deploy. Nie usuwaj starszych ZIP-ow, dopoki gracze moga z nich korzystac.\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Buduje bezpieczny pakiet aktualizacji Cell Defender")
    parser.add_argument("--version", required=True, help="np. 2.2.0")
    parser.add_argument("--notes", default="Nowa aktualizacja Cell Defender.")
    parser.add_argument("--mandatory", action="store_true")
    args = parser.parse_args()

    version = args.version.strip()
    if not version or any(ch not in "0123456789." for ch in version):
        raise SystemExit("Wersja może zawierać tylko cyfry i kropki, np. 2.2.0")

    UPDATES.mkdir(parents=True, exist_ok=True)
    update_version(version)
    source = zip_source(version)
    windows = zip_windows(version)
    packages: dict[str, object] = {"source": metadata(source)}
    if windows:
        packages["windows"] = metadata(windows)

    manifest = {
        "version": version,
        "published_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "notes": args.notes.strip() or "Nowa aktualizacja Cell Defender.",
        "mandatory": bool(args.mandatory),
        "packages": packages,
    }
    (UPDATES / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    export_server_files()

    print("\n[OK] Aktualizacja została przygotowana.")
    print(f"Wersja: {version}")
    print(f"Pakiet SOURCE: {source.name} ({source.stat().st_size / 1024 / 1024:.2f} MB)")
    if windows:
        print(f"Pakiet WINDOWS: {windows.name} ({windows.stat().st_size / 1024 / 1024:.2f} MB)")
    else:
        print("Pakiet WINDOWS: pominięty — najpierw uruchom ZBUDUJ_EXE.cmd, jeśli rozdajesz grę jako EXE.")
    print(f"Wgraj zawartość folderu: {EXPORT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

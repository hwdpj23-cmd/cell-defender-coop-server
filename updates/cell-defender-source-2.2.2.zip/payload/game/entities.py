from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import pygame

from .data import COLORS, ENEMY_TYPES
from .utils import clamp, glow_circle, vec_from_angle

if TYPE_CHECKING:
    from .gameplay import GameplayScene


@dataclass
class Particle:
    pos: pygame.Vector2
    vel: pygame.Vector2
    color: tuple[int, int, int]
    size: float
    life: float
    drag: float = 0.92
    age: float = 0.0

    @property
    def dead(self) -> bool:
        return self.age >= self.life or self.size <= 0.2

    def update(self, dt: float) -> None:
        self.age += dt
        self.pos += self.vel * dt
        self.vel *= self.drag ** (dt * 60)
        self.size *= 0.985 ** (dt * 60)

    def draw(self, surface: pygame.Surface) -> None:
        ratio = max(0.0, 1.0 - self.age / self.life)
        alpha = int(220 * ratio)
        r = max(1, int(self.size))
        dot = pygame.Surface((r * 4, r * 4), pygame.SRCALPHA)
        pygame.draw.circle(dot, (*self.color, alpha), (r * 2, r * 2), r)
        surface.blit(dot, (self.pos.x - r * 2, self.pos.y - r * 2))


@dataclass
class FloatingText:
    pos: pygame.Vector2
    text: str
    color: tuple[int, int, int]
    life: float = 0.8
    age: float = 0.0

    @property
    def dead(self) -> bool:
        return self.age >= self.life

    def update(self, dt: float) -> None:
        self.age += dt
        self.pos.y -= 28 * dt

    def draw(self, surface: pygame.Surface, font: pygame.font.Font) -> None:
        alpha = int(255 * max(0, 1 - self.age / self.life))
        img = font.render(self.text, True, self.color)
        img.set_alpha(alpha)
        surface.blit(img, img.get_rect(center=(int(self.pos.x), int(self.pos.y))))


@dataclass
class Pickup:
    pos: pygame.Vector2
    kind: str
    value: int
    radius: float = 7
    age: float = 0.0
    dead: bool = False

    def update(self, dt: float, player: "Player") -> None:
        self.age += dt
        delta = player.pos - self.pos
        dist = delta.length()
        if dist < player.pickup_radius and dist > 1:
            speed = 180 + (player.pickup_radius - dist) * 4.2
            self.pos += delta.normalize() * speed * dt
        if dist < self.radius + player.radius:
            if self.kind == "xp":
                player.scene.add_xp(self.value)
            elif self.kind == "dna":
                player.scene.run_dna += self.value
            elif self.kind == "heal":
                player.heal(self.value)
            if hasattr(player.scene, "on_pickup_collected"):
                player.scene.on_pickup_collected(self.kind, self.value)
            self.dead = True

    def draw(self, surface: pygame.Surface) -> None:
        bob = math.sin(self.age * 5.5) * 2
        color = COLORS["cyan"] if self.kind == "xp" else COLORS["purple"] if self.kind == "dna" else COLORS["green"]
        glow_circle(surface, (self.pos.x, self.pos.y + bob), self.radius, color, 2)
        if self.kind == "dna":
            pygame.draw.line(surface, COLORS["white"], (self.pos.x - 3, self.pos.y - 4 + bob), (self.pos.x + 3, self.pos.y + 4 + bob), 1)
            pygame.draw.line(surface, COLORS["white"], (self.pos.x + 3, self.pos.y - 4 + bob), (self.pos.x - 3, self.pos.y + 4 + bob), 1)


@dataclass
class Projectile:
    pos: pygame.Vector2
    vel: pygame.Vector2
    damage: float
    radius: float
    color: tuple[int, int, int]
    life: float = 3.0
    pierce: int = 1
    owner: str = "player"
    kind: str = "bullet"
    bounce: int = 0
    crit_chance: float = 0.0
    age: float = 0.0
    dead: bool = False
    hit_ids: set[int] = field(default_factory=set)

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.age >= self.life:
            self.dead = True
            return
        self.pos += self.vel * dt
        if self.bounce > 0:
            bounced = False
            if self.pos.x < self.radius or self.pos.x > scene.world_w - self.radius:
                self.vel.x *= -1
                self.pos.x = clamp(self.pos.x, self.radius, scene.world_w - self.radius)
                bounced = True
            if self.pos.y < self.radius or self.pos.y > scene.world_h - self.radius:
                self.vel.y *= -1
                self.pos.y = clamp(self.pos.y, self.radius, scene.world_h - self.radius)
                bounced = True
            if bounced:
                self.bounce -= 1
        elif self.pos.x < -80 or self.pos.x > scene.world_w + 80 or self.pos.y < -80 or self.pos.y > scene.world_h + 80:
            self.dead = True

        if self.owner == "player":
            for enemy in scene.enemies:
                if enemy.dead or id(enemy) in self.hit_ids:
                    continue
                if self.pos.distance_squared_to(enemy.pos) <= (self.radius + enemy.radius) ** 2:
                    crit = random.random() < self.crit_chance
                    dealt = self.damage * (scene.crit_damage_mul if crit else 1.0)
                    weak = enemy.is_weak_hit(self.pos)
                    if weak:
                        dealt *= 2.5
                    dealt = scene.damage_against(enemy, dealt)
                    enemy.take_damage(dealt, scene, crit=crit, weak=weak)
                    scene.on_damage_dealt(dealt, enemy)
                    self.hit_ids.add(id(enemy))
                    self.pierce -= 1
                    if self.pierce <= 0:
                        self.dead = True
                        break
        else:
            for player in scene.get_active_players():
                if self.pos.distance_squared_to(player.pos) <= (self.radius + player.radius) ** 2:
                    player.take_damage(self.damage)
                    self.dead = True
                    break

    def draw(self, surface: pygame.Surface) -> None:
        if self.kind == "needle":
            direction = self.vel.normalize() if self.vel.length_squared() else pygame.Vector2(1, 0)
            a = self.pos - direction * 8
            b = self.pos + direction * 8
            pygame.draw.line(surface, self.color, a, b, 4)
            pygame.draw.circle(surface, COLORS["white"], (int(b.x), int(b.y)), 2)
        elif self.kind == "bubble":
            halo = pygame.Surface((int(self.radius * 4), int(self.radius * 4)), pygame.SRCALPHA)
            c = int(self.radius * 2)
            pygame.draw.circle(halo, (*self.color, 45), (c, c), int(self.radius * 1.55))
            pygame.draw.circle(halo, (*self.color, 120), (c, c), int(self.radius), width=3)
            pygame.draw.circle(halo, (255, 255, 255, 130), (c - int(self.radius * .3), c - int(self.radius * .3)), max(2, int(self.radius * .18)))
            surface.blit(halo, (self.pos.x - c, self.pos.y - c))
        else:
            glow_circle(surface, self.pos, self.radius, self.color, 2)


@dataclass
class Mine:
    pos: pygame.Vector2
    damage: float
    radius: float
    trigger_radius: float
    life: float = 10.0
    age: float = 0.0
    dead: bool = False

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.age += dt
        if self.age > self.life:
            self.dead = True
            return
        for enemy in scene.enemies:
            if not enemy.dead and self.pos.distance_squared_to(enemy.pos) <= (self.trigger_radius + enemy.radius) ** 2:
                scene.explode(self.pos, self.radius, self.damage, COLORS["orange"])
                self.dead = True
                return

    def draw(self, surface: pygame.Surface) -> None:
        pulse = 1 + math.sin(self.age * 8) * .12
        r = int(10 * pulse)
        pygame.draw.circle(surface, COLORS["orange"], self.pos, r)
        pygame.draw.circle(surface, COLORS["yellow"], self.pos, max(2, r // 3))
        pygame.draw.circle(surface, (*COLORS["orange"],), self.pos, int(self.trigger_radius), width=1)


class Player:
    def __init__(self, scene: "GameplayScene", player_id: str = "host", remote: bool = False):
        self.scene = scene
        self.player_id = player_id
        self.remote = remote
        self.input_vector = pygame.Vector2()
        self.display_name = "Gracz 1" if player_id == "host" else "Gracz 2"
        self.tint = COLORS["cyan"] if player_id == "host" else COLORS["green"]
        lab = scene.app.save.data["lab"]
        self.pos = pygame.Vector2(scene.world_w / 2, scene.world_h / 2)
        self.radius = 24
        # Laboratorium rośnie geometrycznie: każdy poziom wzmacnia poprzedni,
        # zamiast dodawać zawsze tę samą płaską wartość.
        self.base_max_hp = 100.0 * (1.055 ** int(lab["max_hp"]))
        self.max_hp = float(self.base_max_hp)
        self.hp = self.max_hp
        self.base_speed = 235.0 * (1.025 ** int(lab["move_speed"]))
        self.speed = self.base_speed
        self.damage_mul = 1.055 ** int(lab["damage"])
        self.fire_rate_mul = 1.045 ** int(lab["fire_rate"])
        self.pickup_radius = 95.0 * (1.08 ** int(lab["magnet"]))
        self.armor = min(.42, 1.0 - (0.985 ** int(lab["armor"])))
        self.regen = .10 * ((1.22 ** int(lab["regen"])) - 1.0) / .22
        self.luck = min(.45, 1.0 - (0.975 ** int(lab["luck"])))
        self.invuln = 0.0
        self.flash = 0.0
        self.angle = 0.0

    def update(self, dt: float) -> None:
        if self.hp <= 0:
            self.input_vector.xy = 0, 0
            return
        if self.remote:
            move = pygame.Vector2(self.input_vector)
        else:
            keys = pygame.key.get_pressed()
            move = pygame.Vector2(
                float(keys[pygame.K_d] or keys[pygame.K_RIGHT]) - float(keys[pygame.K_a] or keys[pygame.K_LEFT]),
                float(keys[pygame.K_s] or keys[pygame.K_DOWN]) - float(keys[pygame.K_w] or keys[pygame.K_UP]),
            )
        if move.length_squared() > 0:
            move = move.normalize()
            self.pos += move * self.speed * dt
            self.angle = math.atan2(move.y, move.x)
        margin = self.radius + 8
        self.pos.x = clamp(self.pos.x, margin, self.scene.world_w - margin)
        self.pos.y = clamp(self.pos.y, margin, self.scene.world_h - margin)
        self.invuln = max(0.0, self.invuln - dt)
        self.flash = max(0.0, self.flash - dt)
        if self.regen > 0 and self.hp > 0:
            self.hp = min(self.max_hp, self.hp + self.regen * dt)

    def take_damage(self, amount: float) -> None:
        if self.invuln > 0 or self.scene.game_over:
            return
        amount *= max(.25, 1 - self.armor)
        self.hp -= amount
        self.invuln = .55
        self.flash = .18
        self.scene.camera_shake = min(18, self.scene.camera_shake + 7)
        self.scene.spawn_burst(self.pos, COLORS["red"], 10)
        self.scene.add_text(self.pos, f"-{int(amount)}", COLORS["red"])
        self.scene.play_sound("hurt")
        if self.hp <= 0:
            self.hp = 0
            living = [p for p in self.scene.get_active_players() if p is not self and p.hp > 0]
            if not living:
                self.scene.end_run(False)
            else:
                self.scene.app.toast(f"{self.display_name} został pokonany — partner nadal walczy!", COLORS["red"])

    def heal(self, amount: float) -> None:
        old = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        gained = int(self.hp - old)
        if gained > 0:
            self.scene.add_text(self.pos, f"+{gained} HP", COLORS["green"])

    def draw(self, surface: pygame.Surface) -> None:
        pulse = math.sin(pygame.time.get_ticks() * .004) * 2
        color = COLORS["white"] if self.flash > 0 else self.tint
        glow_circle(surface, self.pos, self.radius + pulse, color, 4)
        body = (18, 67, 100) if self.player_id == "host" else (18, 92, 65)
        pygame.draw.circle(surface, body, self.pos, int(self.radius - 4))
        pygame.draw.circle(surface, self.tint, self.pos, int(self.radius - 4), width=3)
        nucleus = self.pos + vec_from_angle(self.angle) * 6
        pygame.draw.circle(surface, COLORS["purple"], nucleus, 8)
        pygame.draw.circle(surface, COLORS["pink"], nucleus, 3)
        if self.invuln > 0:
            pygame.draw.circle(surface, COLORS["white"], self.pos, self.radius + 7, width=2)


class Enemy:
    def __init__(self, kind: str, pos: pygame.Vector2, scale: float, elite: bool = False):
        base = ENEMY_TYPES[kind]
        self.kind = kind
        self.pos = pygame.Vector2(pos)
        self.radius = float(base["radius"] * (1.2 if elite else 1.0))
        self.max_hp = float(base["hp"] * scale * (2.2 if elite else 1.0))
        self.hp = self.max_hp
        self.speed = float(base["speed"] * (1 + (scale - 1) * .08) * (.92 if elite else 1.0))
        self.damage = float(base["damage"] * (1 + (scale - 1) * .18) * (1.5 if elite else 1.0))
        self.xp = int(base["xp"] * (1.7 if elite else 1.0))
        self.color = base["color"]
        self.elite = elite
        self.dead = False
        self.hit_flash = 0.0
        self.contact_cd = 0.0
        self.shoot_cd = random.uniform(1.0, 2.5)
        self.angle = random.random() * math.tau
        self.anim = random.random() * 10

    def is_weak_hit(self, point: pygame.Vector2) -> bool:
        return False

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.anim += dt
        self.hit_flash = max(0, self.hit_flash - dt)
        self.contact_cd = max(0, self.contact_cd - dt)
        target_player = scene.closest_player(self.pos)
        to_player = target_player.pos - self.pos
        distance = max(1, to_player.length())
        direction = to_player / distance

        if self.kind == "parasite" and distance < 320:
            tangent = pygame.Vector2(-direction.y, direction.x)
            self.pos += (tangent * math.sin(self.anim * 2.4) * .65 - direction * .2) * self.speed * dt
            self.shoot_cd -= dt
            if self.shoot_cd <= 0:
                scene.enemy_shoot(self.pos, direction, self.damage * .65)
                self.shoot_cd = max(.8, 2.3 - scene.elapsed * .002)
        else:
            jitter = pygame.Vector2(math.sin(self.anim * 3.1 + self.pos.x * .01), math.cos(self.anim * 2.7 + self.pos.y * .01)) * .11
            travel = direction + jitter
            if travel.length_squared() > 0:
                self.pos += travel.normalize() * self.speed * dt

        if distance <= self.radius + target_player.radius and self.contact_cd <= 0:
            target_player.take_damage(self.damage)
            self.contact_cd = .75
            self.pos -= direction * 18

    def take_damage(self, amount: float, scene: "GameplayScene", crit: bool = False, weak: bool = False) -> None:
        if self.dead:
            return
        reduction = float(getattr(self, "damage_reduction", 0.0))
        amount *= max(.1, 1.0 - reduction)
        self.hp -= amount
        if getattr(self, "reflect_chance", 0.0) > 0 and random.random() < float(self.reflect_chance):
            scene.player.take_damage(amount * .06)
        self.hit_flash = .08
        if scene.show_damage:
            color = COLORS["yellow"] if crit else COLORS["pink"] if weak else COLORS["text"]
            label = f"{int(amount)}" + ("!" if crit else "") + (" SŁABY" if weak else "")
            scene.add_text(self.pos + pygame.Vector2(random.uniform(-8, 8), -self.radius), label, color)
        if self.hp <= 0:
            self.die(scene)

    def die(self, scene: "GameplayScene") -> None:
        if self.dead:
            return
        self.dead = True
        scene.kills += 1
        if hasattr(scene, "on_enemy_killed"):
            scene.on_enemy_killed(self)
        scene.spawn_burst(self.pos, self.color, 10 if not self.elite else 20)
        scene.pickups.append(Pickup(self.pos.copy(), "xp", self.xp, 7 if not self.elite else 10))
        if self.elite and random.random() < .35:
            scene.pickups.append(Pickup(self.pos + pygame.Vector2(10, 0), "dna", 1, 8))
        if random.random() < .025 + scene.player.luck * .02:
            scene.pickups.append(Pickup(self.pos + pygame.Vector2(-8, 4), "heal", 12, 8))
        if self.kind == "splitter" and self.radius > 12:
            for direction in (-1, 1):
                child = Enemy("bacteria", self.pos + pygame.Vector2(direction * 12, 0), max(1, scene.difficulty * .75))
                child.radius = 9
                child.max_hp *= .7
                child.hp = child.max_hp
                child.xp = max(1, child.xp // 2)
                scene.enemies.append(child)

    def draw(self, surface: pygame.Surface) -> None:
        color = COLORS["white"] if self.hit_flash > 0 else self.color
        x, y = int(self.pos.x), int(self.pos.y)
        if self.kind in ("virus", "elite"):
            points = []
            count = 12
            for i in range(count * 2):
                angle = i * math.pi / count + self.anim * .25
                radius = self.radius * (1.35 if i % 2 == 0 else .82)
                points.append((x + math.cos(angle) * radius, y + math.sin(angle) * radius))
            pygame.draw.polygon(surface, color, points)
            pygame.draw.circle(surface, (72, 12, 45), (x, y), int(self.radius * .7))
            for i in range(3):
                a = self.anim + i * math.tau / 3
                pygame.draw.circle(surface, COLORS["pink"], (x + int(math.cos(a) * self.radius * .35), y + int(math.sin(a) * self.radius * .35)), 2)
        elif self.kind == "bacteria":
            body = pygame.Rect(0, 0, int(self.radius * 2.2), int(self.radius * 1.25))
            body.center = (x, y)
            pygame.draw.ellipse(surface, color, body)
            pygame.draw.ellipse(surface, (90, 34, 20), body.inflate(-8, -5))
        elif self.kind == "spore":
            glow_circle(surface, self.pos, self.radius, color, 2)
            pygame.draw.circle(surface, (45, 21, 70), (x, y), int(self.radius * .72))
            for i in range(7):
                a = i * math.tau / 7 + self.anim * .1
                pygame.draw.circle(surface, COLORS["purple"], (x + int(math.cos(a) * self.radius * .48), y + int(math.sin(a) * self.radius * .48)), 3)
        elif self.kind == "parasite":
            pts = []
            for i in range(8):
                a = i * math.tau / 8 + self.anim * .4
                rr = self.radius * (1.15 if i % 2 == 0 else .65)
                pts.append((x + math.cos(a) * rr, y + math.sin(a) * rr))
            pygame.draw.polygon(surface, color, pts)
            pygame.draw.circle(surface, (10, 60, 45), (x, y), int(self.radius * .45))
        elif self.kind == "splitter":
            pygame.draw.circle(surface, color, (x - int(self.radius * .28), y), int(self.radius * .72))
            pygame.draw.circle(surface, color, (x + int(self.radius * .28), y), int(self.radius * .72))
            pygame.draw.line(surface, COLORS["cyan"], (x, y - int(self.radius * .7)), (x, y + int(self.radius * .7)), 2)
        if self.elite:
            pygame.draw.circle(surface, COLORS["yellow"], (x, y), int(self.radius + 5), width=2)
        if self.hp < self.max_hp:
            w = int(self.radius * 2.2)
            rect = pygame.Rect(x - w // 2, y - int(self.radius + 10), w, 4)
            pygame.draw.rect(surface, (50, 20, 35), rect, border_radius=2)
            fill = rect.copy(); fill.width = int(rect.width * max(0, self.hp / self.max_hp))
            pygame.draw.rect(surface, COLORS["red"], fill, border_radius=2)


class Boss(Enemy):
    def __init__(self, pos: pygame.Vector2, scale: float, name: str, phase_count: int = 2):
        super().__init__("elite", pos, scale, elite=True)
        self.name = name
        self.radius = 58
        self.max_hp = 1500 * scale
        self.hp = self.max_hp
        self.speed = 48 + scale * 2
        self.damage = 24 * (1 + scale * .1)
        self.xp = 120
        self.weak_angle = random.random() * math.tau
        self.weak_radius = 10
        self.attack_cd = 2.0
        self.summon_cd = 6.0
        self.phase_count = phase_count
        self.phase = 1
        self.kind = "boss"
        self.color = COLORS["red"]
        self.damage_reduction = 0.0
        self.regen_rate = 0.0
        self.teleport_cd = 999.0
        self.reflect_chance = 0.0
        self.death_explosion = False
        self.split_on_death = False
        self.special_attack = ""

    def weak_pos(self) -> pygame.Vector2:
        return self.pos + vec_from_angle(self.weak_angle) * self.radius * .72

    def is_weak_hit(self, point: pygame.Vector2) -> bool:
        return point.distance_squared_to(self.weak_pos()) <= (self.weak_radius + 8) ** 2

    def update(self, dt: float, scene: "GameplayScene") -> None:
        self.anim += dt
        self.hit_flash = max(0, self.hit_flash - dt)
        self.contact_cd = max(0, self.contact_cd - dt)
        if self.regen_rate > 0 and self.hp > 0:
            self.hp = min(self.max_hp, self.hp + self.regen_rate * dt)
        self.teleport_cd -= dt
        if self.teleport_cd <= 0 and getattr(self, "mutation_key", ""):
            target = scene.closest_player(self.pos)
            angle = random.random() * math.tau
            self.pos = target.pos + vec_from_angle(angle) * random.uniform(170, 300)
            self.pos.x = clamp(self.pos.x, self.radius, scene.world_w - self.radius)
            self.pos.y = clamp(self.pos.y, self.radius, scene.world_h - self.radius)
            self.teleport_cd = random.uniform(4.5, 7.5)
            scene.spawn_burst(self.pos, COLORS["purple"], 24)
        self.weak_angle += dt * (.8 + self.phase * .18)
        hp_ratio = self.hp / self.max_hp
        new_phase = min(self.phase_count, 1 + int((1 - hp_ratio) * self.phase_count))
        if new_phase > self.phase:
            self.phase = new_phase
            scene.add_text(self.pos, f"FAZA {self.phase}", COLORS["yellow"])
            scene.camera_shake += 12
            scene.spawn_burst(self.pos, COLORS["red"], 30)

        target_player = scene.closest_player(self.pos)
        to_player = target_player.pos - self.pos
        distance = max(1, to_player.length())
        direction = to_player / distance
        preferred = 210 - self.phase * 25
        if distance > preferred + 25:
            self.pos += direction * self.speed * dt
        elif distance < preferred - 45:
            self.pos -= direction * self.speed * .6 * dt
        else:
            tangent = pygame.Vector2(-direction.y, direction.x)
            self.pos += tangent * self.speed * .55 * dt

        self.attack_cd -= dt
        self.summon_cd -= dt
        if self.attack_cd <= 0:
            count = 8 + self.phase * 4
            for i in range(count):
                angle = i * math.tau / count + self.anim * .2
                scene.enemy_shoot(self.pos, vec_from_angle(angle), self.damage * .55, speed=175 + self.phase * 20, radius=7)
            self.attack_cd = max(1.15, 2.6 - self.phase * .35)
            scene.play_sound("boss")
        if self.summon_cd <= 0:
            for _ in range(2 + self.phase):
                angle = random.random() * math.tau
                spawn = self.pos + vec_from_angle(angle) * random.uniform(70, 120)
                kind = random.choice(["virus", "bacteria", "parasite", "splitter"])
                scene.enemies.append(Enemy(kind, spawn, scene.difficulty * .9))
            self.summon_cd = max(3.5, 7.5 - self.phase)

        if distance <= self.radius + target_player.radius and self.contact_cd <= 0:
            target_player.take_damage(self.damage)
            self.contact_cd = .8
            self.pos -= direction * 25

    def die(self, scene: "GameplayScene") -> None:
        if self.dead:
            return
        self.dead = True
        scene.kills += 1
        scene.bosses_killed += 1
        if getattr(self, "final_boss", False):
            scene.final_boss_dead = True
        scene.run_dna += 5 + self.phase_count * 2
        if self.death_explosion:
            scene.explode(self.pos, 260, self.damage * 4.0, COLORS["red"], knockback=70)
        if self.split_on_death:
            for i in range(4):
                child = Enemy("elite", self.pos + vec_from_angle(i * math.tau / 4) * 70, max(1.0, scene.difficulty * .8), elite=True)
                child.max_hp *= .55; child.hp = child.max_hp; child.radius *= .75
                scene.enemies.append(child)
        scene.spawn_burst(self.pos, COLORS["yellow"], 50)
        for i in range(18):
            angle = i * math.tau / 18
            scene.pickups.append(Pickup(self.pos + vec_from_angle(angle) * random.uniform(10, 45), "xp", 12, 8))
        scene.add_text(self.pos, "+ DNA BOSS", COLORS["purple"])
        scene.camera_shake += 22
        scene.play_sound("boss_down")

    def draw(self, surface: pygame.Surface) -> None:
        x, y = int(self.pos.x), int(self.pos.y)
        color = COLORS["white"] if self.hit_flash > 0 else self.color
        glow_circle(surface, self.pos, self.radius, color, 5)
        for ring in range(3):
            points = []
            count = 10 + ring * 2
            for i in range(count * 2):
                a = i * math.pi / count + self.anim * (.18 + ring * .08) * (-1 if ring % 2 else 1)
                rr = self.radius * (.95 - ring * .18) * (1.25 if i % 2 == 0 else .9)
                points.append((x + math.cos(a) * rr, y + math.sin(a) * rr))
            pygame.draw.polygon(surface, color if ring == 0 else (112, 20 + ring * 12, 76 + ring * 18), points)
        pygame.draw.circle(surface, (36, 9, 31), (x, y), int(self.radius * .45))
        weak = self.weak_pos()
        glow_circle(surface, weak, self.weak_radius, COLORS["yellow"], 3)
        pygame.draw.circle(surface, COLORS["white"], weak, 3)
